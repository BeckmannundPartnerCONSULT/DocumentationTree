lua_tree_output={ branchname="Lua", 
{ branchname="_", 
state="COLLAPSED",
{ branchname="_G", 
state="COLLAPSED",
},
{ branchname="_VERSION", 
state="COLLAPSED",
},
},
{ branchname="arg", 
state="COLLAPSED",
},
{ branchname="assert", 
state="COLLAPSED",
},
{ branchname="collectgarbage", 
state="COLLAPSED",
},
{ branchname="coroutine", 
state="COLLAPSED",
 "create", "isyieldable", 
 "resume", 
 "running", 
 "status", 
 "wrap", 
 "yield", 
},
{ branchname="debug", 
state="COLLAPSED",
 "debug", "gethook", 
 "getinfo", 
 "getlocal", 
 "getmetatable", 
 "getregistry", 
 "getupvalue", 
 "getuservalue", 
 "sethook", 
 "setlocal", 
 "setmetatable", 
 "setupvalue", 
 "setuservalue", 
 "traceback", 
 "upvaluejoin", 
},
{ branchname="dofile", 
state="COLLAPSED",
},
{ branchname="error", 
state="COLLAPSED",
},
 "getmetatable", 

{ branchname="io", 
state="COLLAPSED",
 "flush",
{ branchname="close", 
state="COLLAPSED",
},
{ branchname="input", 
state="COLLAPSED",
},
{ branchname="lines", 
state="COLLAPSED",
},
{ branchname="open", 
state="COLLAPSED",
},
{ branchname="output", 
state="COLLAPSED",
},
{ branchname="popen", 
state="COLLAPSED",
},
{ branchname="read", 
state="COLLAPSED",
},
 "stderr", 
 "stdin", 
 "stdout", 
 "tmpfile", 

{ branchname="type", 
state="COLLAPSED",
},
{ branchname="write", 
state="COLLAPSED",
},
},
{ branchname="ipairs", 
state="COLLAPSED",
},
 "load", 
 "loadfile", 

{ branchname="math", 
state="COLLAPSED",
{ branchname="abs", 
state="COLLAPSED",
},
{ branchname="acos", 
state="COLLAPSED",
},
{ branchname="asin", 
state="COLLAPSED",
},
{ branchname="atan", 
state="COLLAPSED",
},
{ branchname="atan2", 
state="COLLAPSED",
},
{ branchname="ceil", 
state="COLLAPSED",
},
{ branchname="cos", 
state="COLLAPSED",
},
{ branchname="cosh", 
state="COLLAPSED",
},
{ branchname="deg", 
state="COLLAPSED",
},
{ branchname="exp", 
state="COLLAPSED",
},
{ branchname="floor", 
state="COLLAPSED",
},
{ branchname="fmod", 
state="COLLAPSED",
},
{ branchname="frexp", 
state="COLLAPSED",
},
{ branchname="huge", 
state="COLLAPSED",
},
{ branchname="ldexp", 
state="COLLAPSED",
},
{ branchname="log", 
state="COLLAPSED",
},
{ branchname="log10", 
state="COLLAPSED",
},
{ branchname="max", 
state="COLLAPSED",
},
{ branchname="maxinteger", 
state="COLLAPSED",
},
{ branchname="min", 
state="COLLAPSED",
},
{ branchname="mininteger", 
state="COLLAPSED",
},
{ branchname="modf", 
state="COLLAPSED",
},
{ branchname="pi", 
state="COLLAPSED",
},
{ branchname="pow", 
state="COLLAPSED",
},
{ branchname="rad", 
state="COLLAPSED",
},
{ branchname="random", 
state="COLLAPSED",
},
{ branchname="randomseed", 
state="COLLAPSED",
},
{ branchname="sin", 
state="COLLAPSED",
},
{ branchname="sinh", 
state="COLLAPSED",
},
{ branchname="sqrt", 
state="COLLAPSED",
},
{ branchname="tan", 
state="COLLAPSED",
},
{ branchname="tanh", 
state="COLLAPSED",
},
{ branchname="tointeger", 
state="COLLAPSED",
},
{ branchname="type", 
state="COLLAPSED",
},
{ branchname="ult", 
state="COLLAPSED",
},
},
{ branchname="next", 
state="COLLAPSED",
},
{ branchname="os", 
state="COLLAPSED",
 "clock",
{ branchname="date", 
state="COLLAPSED",
},
{ branchname="difftime", 
state="COLLAPSED",
},
{ branchname="execute", 
state="COLLAPSED",
},
{ branchname="exit", 
state="COLLAPSED",
},
{ branchname="getenv", 
state="COLLAPSED",
},
{ branchname="remove", 
state="COLLAPSED",
},
{ branchname="rename", 
state="COLLAPSED",
},
 "setlocale", 

{ branchname="time", 
state="COLLAPSED",
},
 "tmpname", 
},
{ branchname="package", 
state="COLLAPSED",
 "config", "cpath", 
 "loaded", 
 "loadlib", 
 "path", 
 "preload", 
 "searchers", 
 "searchpath", 
},
{ branchname="pairs", 
state="COLLAPSED",
},
{ branchname="pcall", 
state="COLLAPSED",
},
{ branchname="print", 
state="COLLAPSED",
},
 "rawequal", 
 "rawget", 
 "rawlen", 
 "rawset", 

{ branchname="require", 
state="COLLAPSED",
},
{ branchname="select", 
state="COLLAPSED",
},
 "setmetatable", 

{ branchname="string", 
state="COLLAPSED",
{ branchname="byte", 
state="COLLAPSED",
},
{ branchname="char", 
state="COLLAPSED",
},
 "dump", 

{ branchname="find", 
state="COLLAPSED",
},
 "format", 

{ branchname="gmatch", 
state="COLLAPSED",
},
{ branchname="gsub", 
state="COLLAPSED",
},
{ branchname="len", 
state="COLLAPSED",
},
{ branchname="lower", 
state="COLLAPSED",
},
{ branchname="match", 
state="COLLAPSED",
},
 "pack", 
 "packsize", 

{ branchname="rep", 
state="COLLAPSED",
},
{ branchname="reverse", 
state="COLLAPSED",
},
{ branchname="sub", 
state="COLLAPSED",
},
 "unpack", 

{ branchname="upper", 
state="COLLAPSED",
},
},
{ branchname="table", 
{ branchname="concat", 
state="COLLAPSED",
},
{ branchname="insert", 
state="COLLAPSED",
},
 "move", 

{ branchname="pack", 
state="COLLAPSED",
},
{ branchname="remove", 
state="COLLAPSED",
},
{ branchname="sort", 
state="COLLAPSED",
},
{ branchname="unpack", 
state="COLLAPSED",
},
},
{ branchname="tonumber", 
state="COLLAPSED",
},
{ branchname="tostring", 
state="COLLAPSED",
},
{ branchname="type", 
state="COLLAPSED",
},
{ branchname="utf8", 
state="COLLAPSED",
 "char", "charpattern", 
 "codepoint", 
 "codes", 
 "len", 
 "offset", 
},
{ branchname="warn", 
state="COLLAPSED",
},
{ branchname="xpcall", 
state="COLLAPSED",
}}--lua_tree_output



TextHTMLtable={
[====[<!DOCTYPE html> <head></head><html> <body>
<h1>Lua documentation </h1>

This Lua documentation is written to help beginners and advanced teams of non IT professionals. It is organised by the tree of the global variables in Lua that can be got by recursive read of the table _G.

The content is taken from the Lua Manual (Lua 5.2 Reference Manual, Roberto Ierusalimschy, Luiz Henrique de Figueiredo and Waldemar Celes, PUC-Rio. 2011-2012, Freely available under the terms of Lua license) and www.lua.org pil contents.html.

If a function or table in the global variables is only useful for IT professionals it is not described but a comment is done about this.

<br>
<pre>
for k,v in pairs(_G) do print(k,v) end

seen={}

function tableReadrecursive(t,i_tab)
	seen[t]=true
	local s={}
	local n=0
	for k in pairs(t) do
		n=n+1 s[n]=k
	end --for k,v in pairs(t) do
	table.sort(s,function(a,b) at=tostring(a) bt=tostring(b) return at &lt; bt end)
	for k,v in ipairs(s) do 
		if type(v)~="table" and v~="seen" and v~="tableReadrecursive" then
			print(i_tab,v)
		end --if type(v)~="table" and v~="seen" then
		if v~="package" then 
			v=t[v]
			if type(v)=="table" and not seen[v] then  
				tableReadrecursive(v,i_tab .. "\t")
			end --if type(v)=="table" and not seen[v] then  
		else
			local tablePackage={}
			for k1,v1 in pairs(package) do tablePackage[#tablePackage+1]=i_tab .. "\t\t" .. k1 end
			table.sort(tablePackage,function(a,b) at=tostring(a) bt=tostring(b) return at &lt; bt end)
			for i1,v1 in ipairs(tablePackage) do print(v1) end
		end --if v~="package" then 
	end --for k,v in ipairs(s) do 
end --function tableReadrecursive(t,i)

tableReadrecursive(_G,"\t")


</pre>

<br>


</body></html> ]====],
[====[<!DOCTYPE html> <head></head><html> <body leftmargin="150">
<br><h1><!--font size="32"-->Presentation of the Lua language<!--/font--></h1>

<!--font size="25"-->

<ul><li>Branches are used to explain tables and functions of a Lua session.</li></ul>

<ul><li>Leafs are such tables or functions that considered reserved for IT professionals</li></ul>

<ul><li>The descriptions of the Lua syntax are taken from the Lua Manual, Lua 5.2 Reference Manual by Roberto Ierusalimschy, Luiz Henrique de Figueiredo and Waldemar Celes, Copyright 2011-2012 Lua.org, PUC-Rio. Download of the original document for free at http://www.dcc.ufrj.br/~fabiom/comp220142/lua52-refman.pdf with the licence http://www.lua.org/license.html

<br>

The Lua version 5.4 is treated in this document. So the manual is available at the site https://www.lua.org/manual/5.4/manual.html.

<br>
and
<br>
The book Programming in Lua, available on the site  https://www.lua.org/pil.

The citation of the book are taken from Programming in Lua 5.0 freely available on internet on the site https://www.lua.org/pil/contents.html.

</li></ul>
<!--/font-->

</body></html> ]====],
["flush"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>io.flush() function</h1>

This function writes the file before closing and is only for big operations necessary. This is for IT professionals.

</body></html> ]====],
["log"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.log() function</h1>

This is the log function in Lua. This function is the logarithm of the given base. The default for the base is <i>e</i>, so that the function returns the natural logarithm of the argument.
<pre>
> print(math.log(3))
1.0986122886681
> print(math.log(5,4))
1.1609640474437
> print(math.log(2.7))
0.99325177301028
> print(math.log(3,26))
0.3371945170585

</pre>

</body></html> 

</body></html> ]====],
["lower"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>string.lower() function</h1>

This function "receives a string and returns a copy of this string with all uppercase letters changed to lowercase. All other characters are left unchanged. The definition of what an uppercase letter is depends on the current locale." (Manual p. 41)

<pre>

> print(string.lower("Das ist ein Text mit Ma�nahmen."))
das ist ein text mit ma�nahmen.

</pre>


</body></html> ]====],
["dump"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>string.dump() function</h1>

This function is for IT professionals for later load of a function. 


</body></html> ]====],
["clock"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>os.clock() function</h1>

The os.clock function returns the number of seconds of CPU time for the program. Its typical use is to benchmark a piece of code. This is only useful for IT professionals.

<pre>
x = os.clock()
s = 0
    for i=1,100 do s = s + i end
    print(string.format("elapsed time: %.2f\n", os.clock() - x))

>     print(string.format("elapsed time: %.4f\n", os.clock() - x))
elapsed time: 180.5210

</pre>

</body></html> ]====],
["packsize"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>string.packsize() function</h1>

This function is only for IT professionals returning the length of a binary form of a string with string.pack.

</body></html> ]====],
["config"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>package.config() function</h1>

This function is only for IT professionals.

</body></html> ]====],
["floor"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.floor() function</h1>

This is the floor function in Lua. It gives the greatest integer number smaller or equal to the number in the argument.
<pre>
> a=-10.23
> print(math.floor(a))
-11
> a=12.2332
> print(math.floor(a))
12

</pre>

</body></html> ]====],
["unpack"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>string.unpack() function</h1>

This function is only for IT professionals returning the values packed in the argument.

<h1>table.unpack() function</h1>

This function returns the elements of a table, starting with the first element or with the number given by the second argument and ending with the last element or the number given by the third argument.

<br>

The keys not beeing indices from 1 to n in a sequence are not returned by the function.

<pre>

> aTable={123,4,test=3}
> print(table.unpack(aTable))
123     4
> a1,a2=table.unpack(aTable)
> print("a1: " .. a1)
a1: 123
> print("a2: " .. a2)
a2: 4

</pre>


</body></html> ]====],
["os"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>os table</h1>

The os table contains all the functions concernig the operating system. This is a very useful table for non IT professionals but some functions of this table are  not needed by non IT professionals.

</body></html> ]====],
["io"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>io table</h1>

The io table contains all the functions needed for input-/output operations. This is a very useful table for non IT professionals but some functions of this table are  not needed by non IT professionals.

</body></html> ]====],
["pow"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.pow() function</h1>

This is the power function in Lua. This function returns the value <i>x</i><sup><i>y</i></sup>.
<pre>
> print(math.pow(3,2))
9.0
> print(math.pow(2,3))
8.0

</pre>

You can also use the expresseion x^y to compute this value.
<pre>
> print(3^2)
9.0
> print(2^3)
8.0

</pre>

</body></html>]====],
["loadfile"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>loadfile() function</h1>

This function executes Lua code in a file, but is only for IT professionals.

</body></html> ]====],
["mininteger"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.mininteger constant</h1>

This is the constant in Lua for the minimum integer value.
<pre>
> print(math.mininteger)
-9223372036854775808

</pre>

</body></html> 
]====],
["sqrt"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.sqrt() function</h1>

This is the square root function in Lua. 
<br clear="all" /><table border="0" width="100%"><tr><td>
<table align="center" cellspacing="0"  cellpadding="2"><tr><td nowrap="nowrap" align="center">
&#8730;<i>x</i></td></tr></table>
</td><td width="1%"></td></tr></table>


<pre>
> print(math.sqrt(3))
1.7320508075689
> print(math.sqrt(9))
3.0

</pre>

You can also use the expresseion x^0.5 to compute this value.
<pre>
> print(3^0.5)
1.7320508075689
> print(9^0.5)
3.0


</pre>

</body></html>]====],
["find"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>string.find() function</h1>

This looks for the first pattern in second argument matching in the string in the first argument returning the index of the occurence start and the index of the occurence end. When the pattern is not in the string it returns <code>nil</code>. Optional a third argument specifies where to start with the search. A fourth argument with the start argument specifies to seach without pattern matching. This is for IT professionals.

<br>
"If the pattern has captures, then in a successful match the captured values are also returned, after the two indices" (Manual p. 40)

<pre>

> string.find("Hallo","a")
2       2
> string.find("Hallo","l")
3       3
> string.find("Hallo","l",4)
4       4

> string.find("Hallo%d1234","%d",4)
8       8
> string.find("Hallo%d1234","%d",4,true)
6       7

> string.find("Hallo%d1234","(%d)",4)
8       8       1
> string.find("Hallo%d1234","(%d+)",4)
8       11      1234

</pre>




<hr>
<h2>20.2 &ndash; Patterns with more explainations</h2>

<p>You can make patterns more useful with <em>character classes</em>.
A character class is an item in a pattern that can match any
character in a specific set.
For instance, the class <code>%d</code> matches any digit.
Therefore, you can search for a date in the format <code>dd/mm/yyyy</code>
with the pattern '<code>%d%d/%d%d/%d%d%d%d</code>':
<pre>
    s = "Deadline is 30/05/1999, firm"
    date = "%d%d/%d%d/%d%d%d%d"
    print(string.sub(s, string.find(s, date)))   --> 30/05/1999
</pre>
The following table lists all character classes:
<table align="center" border=1>

<tr><td><code><i>x</i></code></td><td>character <i>x</i> itself except all <i>magic characters</i> <code>( ) . % + - * ? [ ] ^ $</code> </td></tr>



<tr><td><code>.</code></td><td>all characters</td></tr>


<tr><td><code>%a</code></td><td>letters</td></tr>
<tr><td><code>%A</code></td><td>not letters</td></tr>

<tr><td><code>%c</code></td><td>control characters</td></tr>
<tr><td><code>%C</code></td><td>not control characters</td></tr>


<tr><td><code>%d</code></td><td>digits</td></tr>
<tr><td><code>%D</code></td><td>not digits</td></tr>


<tr><td><code>%g</code></td><td>printable characters except space</td></tr>
<tr><td><code>%G</code></td><td>space</td></tr>

<tr><td><code>%l</code></td><td>lower case letters</td></tr>
<tr><td><code>%L</code></td><td>not lower case letters</td></tr>


<tr><td><code>%p</code></td><td>punctuation characters</td></tr>
<tr><td><code>%P</code></td><td>not punctuation characters</td></tr>


<tr><td><code>%s</code></td><td>space characters</td></tr>
<tr><td><code>%S</code></td><td>not space characters</td></tr>

<tr><td><code>%u</code></td><td>upper case letters</td></tr>
<tr><td><code>%U</code></td><td>upper case letters</td></tr>

<tr><td><code>%w</code></td><td>alphanumeric characters</td></tr>
<tr><td><code>%W</code></td><td>not alphanumeric characters</td></tr>

<tr><td><code>%x</code></td><td>hexadecimal digits</td></tr>
<tr><td><code>%X</code></td><td>not hexadecimal digits</td></tr>

<tr><td><code>%z</code></td><td>the character with representation 0</td></tr>
<tr><td><code>%Z</code></td><td>not the character with representation 0</td></tr>

<tr><td><code>[char-set]</code></td><td>the union of all characters in char-set as shown afterwards</td></tr>
 
<tr><td><code>[^char-set]</code></td><td>the complement of char-set</td></tr>

<tr><td> </td><td><b>The definitions of letter, space, and other character groups depend on the current locale.  In particular, the class <code>[a-z]</code> may not be equivalent to <code>%l</code>.</b></td></tr>
</table><p>


An upper case version of any of those classes represents
the complement of the class.
For instance, '<code>%A</code>' represents all non-letter characters:
<pre>
    print(string.gsub("hello, up-down!", "%A", "."))
      --> hello..up.down. 4
</pre>
(The <code>4</code> is not part of the result string.
It is the second result of <code>gsub</code>,
the total number of substitutions.
Other examples that print the result of <code>gsub</code> will
omit this count.)

<p>Some characters, called <em>magic characters</em>,
have special meanings when used in a pattern.
The magic characters are
<pre>
    ( ) . % + - * ? [ ] ^ $
</pre>
The character `<code>%</code>&acute; works as an escape for those magic characters.
So, '<code>%.</code>' matches a dot; '<code>%%</code>' matches the character `<code>%</code>&acute; itself.
You can use the escape `<code>%</code>&acute; not only for the magic characters,
but also for all other non-alphanumeric characters.
When in doubt, play safe and put an escape.

<p>For Lua, patterns are regular strings.
They have no special treatment
and follow the same rules as other strings.
Only inside the functions are they interpreted as patterns
and only then does the `<code>%</code>&acute; work as an escape.
Therefore, if you need to put a quote inside a pattern,
you must use the same techniques that you
use to put a quote inside other strings;
for instance, you can escape the quote with a `<code>\</code>&acute;,
which is the escape character for Lua.

<p>A <em>char-set</em> allows you to create your own character classes,
combining different classes and single characters
between square brackets.
For instance,
the char-set '<code>[%w_]</code>' matches both alphanumeric characters
and underscores,
the char-set '<code>[01]</code>' matches binary digits,
and the char-set '<code>[%[%]]</code>' matches square brackets.
To count the number of vowels in a text,
you can write
<pre>
    _, nvow = string.gsub(text, "[AEIOUaeiou]", "")
</pre>
You can also include character ranges in a char-set,
by writing the first and the last characters of the range
separated by a hyphen.
You will seldom need this facility,
because most useful ranges are already predefined;
for instance, '<code>[0-9]</code>' is simpler when written as '<code>%d</code>',
'<code>[0-9a-fA-F]</code>' is the same as '<code>%x</code>'.
However, if you need to find an octal digit,
then you may prefer '<code>[0-7]</code>',
instead of an explicit enumeration ('<code>[01234567]</code>').
You can get the complement of a char-set by starting it with `<code>^</code>&acute;:
'<code>[^0-7]</code>' finds any character that is not an octal digit
and '<code>[^\n]</code>' matches any character different from newline.
But remember that you can negate simple
classes with its upper case version:
'<code>%S</code>' is simpler than '<code>[^%s]</code>'.

<p>Character classes follow the current locale set for Lua.
Therefore, the class '<code>[a-z]</code>' can be different from '<code>%l</code>'.
In a proper locale,
the latter form includes letters such as `<code>&ccedil;</code>&acute; and `<code>&atilde;</code>&acute;.
You should always use the latter form,
unless you have a strong reason to do otherwise:
It is simpler, more portable, and slightly more efficient.

<p>You can make patterns still more useful with modifiers for
repetitions and optional parts.
Patterns in Lua offer four modifiers:
<table align="center" border=1>
<tr><td><code>+</code></td><td>1 or more repetitions</td></tr>
<tr><td><code>*</code></td><td>0 or more repetitions</td></tr>
<tr><td><code>-</code></td><td>also 0 or more repetitions</td></tr>
<tr><td><code>?</code></td><td>optional (0 or 1 occurrence)</td></tr>
</table><p>
The `<code>+</code>&acute; modifier matches one or more
characters of the original class.
It will always get the longest sequence that matches the pattern.
For instance, the pattern '<code>%a+</code>' means one or more letters,
or a word:
<pre>
    print(string.gsub("one, and two; and three", "%a+", "word"))
      --> word, word word; word word
</pre>
The pattern '<code>%d+</code>' matches one or more digits (an integer):
<pre>
    i, j = string.find("the number 1298 is even", "%d+")
    print(i,j)   --> 12  15
</pre>

<p>The modifier `<code>*</code>&acute; is similar to `<code>+</code>&acute;,
but it also accepts zero occurrences of characters of the class.
A typical use is to match optional spaces between parts of a pattern.
For instance, to match an empty parenthesis pair,
such as <code>()</code> or <code>( )</code>,
you use the pattern '<code>%(%s*%)</code>'.
(The pattern '<code>%s*</code>' matches zero or more spaces.
Parentheses have a special meaning in a pattern,
so we must escape them with a `<code>%</code>&acute;.)
As another example, the pattern '<code>[_%a][_%w]*</code>'
matches identifiers in a Lua program:
a sequence that starts with a letter or an underscore,
followed by zero or more underscores or alphanumeric characters.

<p>Like `<code>*</code>&acute;,
the modifier `<code>-</code>&acute; also matches zero or more occurrences
of characters of the original class.
However, instead of matching the longest sequence,
it matches the shortest one.
Sometimes, there is no difference between `<code>*</code>&acute; or `<code>-</code>&acute;,
but usually they present rather different results.
For instance, if you try to find an identifier with the
pattern '<code>[_%a][_%w]-</code>',
you will find only the first letter,
because the '<code>[_%w]-</code>' will always match the empty sequence.
On the other hand,
suppose you want to find comments in a C program.
Many people would first try '<code>/%*.*%*/</code>'
(that is, a <code>"/*"</code> followed by a sequence of any
characters followed by <code>"*/"</code>,
written with the appropriate escapes).
However, because the '<code>.*</code>' expands as far as it can,
the first <code>"/*"</code> in the program would close only
with the last <code>"*/"</code>:
<pre>
    test = "int x; /* x */  int y; /* y */"
    print(string.gsub(test, "/%*.*%*/", "&lt;COMMENT>"))
      --> int x; &lt;COMMENT>
</pre>
The pattern '<code>.-</code>', instead,
will expand the least amount necessary to find the first <code>"*/"</code>,
so that you get your desired result:
<pre>
    test = "int x; /* x */  int y; /* y */"
    print(string.gsub(test, "/%*.-%*/", "&lt;COMMENT>"))
        --> int x; &lt;COMMENT>  int y; &lt;COMMENT>
</pre>

<p>The last modifier, `<code>?</code>&acute;, matches an optional character.
As an example, suppose we want to find an integer in a text,
where the number may contain an optional sign.
The pattern '<code>[+-]?%d+</code>' does the job,
matching numerals like <code>"-12"</code>,
<code>"23"</code> and <code>"+1009"</code>.
The '<code>[+-]</code>' is a character class that matches
both a `<code>+</code>&acute; or a `<code>-</code>&acute; sign;
the following `<code>?</code>&acute; makes that sign optional.

<p>Unlike some other systems, in Lua a modifier can only be
applied to a character class;
there is no way to group patterns under a modifier.
For instance, there is no pattern that matches an optional
word (unless the word has only one letter).
Usually you can circumvent this limitation using some of the
advanced techniques that we will see later.

<p>If a pattern begins with a `<code>^</code>&acute;,
it will match only at the beginning of the subject string.
Similarly, if it ends with a `<code>$</code>&acute;,
it will match only at the end of the subject string.
These marks can be used both to restrict the patterns that you find
and to anchor patterns.
For instance, the test
<pre>
    if string.find(s, "^%d") then ...
</pre>
checks whether the string <code>s</code> starts with a digit
and the test
<pre>
    if string.find(s, "^[+-]?%d+$") then ...
</pre>
checks whether that string represents an integer number,
without other leading or trailing characters.

<p>Another item in a pattern is the '<code>%b</code>',
that matches balanced strings.
Such item is written as '<code>%b<em>xy</em></code>',
where <em>x</em> and <em>y</em> are any two distinct characters;
the <em>x</em> acts as an opening character
and the <em>y</em> as the closing one.
For instance, the pattern '<code>%b()</code>' matches
parts of the string that start with a
`<code>(</code>&acute; and finish at the respective `<code>)</code>&acute;:
<pre>
    print(string.gsub("a (enclosed (in) parentheses) line",
                      "%b()", ""))
      --> a  line
</pre>
Typically, this pattern is used as
'<code>%b()</code>', '<code>%b[]</code>', '<code>%b%{%}</code>', or '<code>%b&lt;></code>',
but you can use any characters as delimiters.

<hr>
<table width="100%" class="nav">
<tr>
<td width="90%" align="left">
<small>
  Copyright &copy; 2003&ndash;2004 Roberto Ierusalimschy.  All rights reserved.
</small>
</td>

</tr>
</table>

<h2>20.3 Captures (and Manual p.42)</h2>

"A pattern can contain sub-patterns enclosed in parentheses; they describe <i>captures</i>. When a match succeeds, the substrings of the subject string that match captures are stored (captured) for future use. Captures are numbered according to their left parentheses. For instance, in the pattern <code>"(a*(.)%w(%s*))"</code>, the part of the string matchin <code>"a*(.)%w(%s*)"</code> is stored as the first capture (and therefore has number 1); the character matching <code>"."</code> is captured with number 2, and the part matching <code>"%s*"</code> has number 3. As a special case, the empty capture <code>"()"</code> captures the current string position (a number). For instance, if we apply the pattern <code>"()aa()"</code> on the string <code>"flaaap"</code>, there will be two captures: 3 and 5." (Manual p. 42)




</body></html> ]====],
["insert"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>table.insert() function</h1>

This function inserts an element as second argument at the end of the table as first argument. If there are three arguments this function inserts the third argument at the position from the second argument into the table as first argument.

<pre>
> aTable={"","is","a","text",".",""}
> table.insert(aTable,"This is the next element")
> textString=table.concat(aTable,"/")
> print(textString)
/is/a/text/.//This is the next element
> table.insert(aTable,3,"This is the next element")
> textString=table.concat(aTable," ")
> print(textString)
 is This is the next element a text .  This is the next element

</pre>


<hr>
<h2>19.2 &ndash; Insert and Remove</h2>

<p>The <code>table</code> library provides functions to insert
and to remove elements from arbitrary positions of a list.
The <code>table.insert</code> function inserts an element
in a given position of an array,
moving up other elements to open space.
Moreover, <code>insert</code> increments the size of the array
(using <code>setn</code>).
For instance,
if <code>a</code> is the array <code>{10, 20, 30}</code>,
after the call <code>table.insert(a, 1, 15)</code> <code>a</code> will
be <code>{15, 10, 20, 30}</code>.
As a special (and frequent) case,
if we call <code>insert</code> without a position,
it inserts the element in the last position of the array
(and, therefore, moves no elements).
As an example,
the following code reads the program input line by line,
storing all lines in an array:
<pre>
    a = {}
    for line in io.lines() do
      table.insert(a, line)
    end
    print(table.getn(a))         --> (number of lines read)
</pre>

<p>The <code>table.remove</code> function
removes (and returns) an element from a given position in an array,
moving down other elements to close space
and decrementing the size of the array.
When called without a position,
it removes the last element of the array.

<p>With those two functions,
it is straightforward to implement
stacks, queues, and double queues.
We can initialize such structures as <code>a = {}</code>.
A push operation is equivalent to <code>table.insert(a, x)</code>;
a pop operation is equivalent to <code>table.remove(a)</code>.
To insert at the other end of the structure
we use <code>table.insert(a, 1, x)</code>;
to remove from that end we use <code>table.remove(a, 1)</code>.
The last two operations are not particularly efficient,
as they must move elements up and down.
However, because the <code>table</code> library implements these functions in C,
these loops are not too expensive
and this implementation is good enough for small arrays
(up to some hundred elements, say).

<hr>
<table width="100%" class="nav">
<tr>
<td width="90%" align="left">
<small>
  Copyright &copy; 2003&ndash;2004 Roberto Ierusalimschy.  All rights reserved.
</small>
</td>
<td width="10%" align="right">
</table>
</body></html> ]====],
["searchpath"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>package.searchpath table</h1>

This table is only for IT professionals.

</body></html> ]====],
["exp"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.exp() function</h1>

This is the power of the base of the natural logarithm function in Lua. It returns the value <i>e</i><sup><i>x</i></sup>.
<pre>
> a=-1.57
> print(math.exp(a))
0.20804518235702
> a=3.14
> print(math.deg(a))
23.103866858722

</pre>

</body></html> ]====],
["input"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>io.input() function</h1>

A call like io.input(filename) opens the given file (in read mode) and sets it as the current input file. From this point on, all input will come from this file, until another call to io.input:

<br>
<pre>
inputfile=io.input("C:\\temp\\test.txt") 
Text=inputfile:read("*a") 
io.close(inputfile)
</pre>


<br>
<br>
The read function reads strings from the current input file. Its arguments control what is read: 
<br>
"*all" reads the whole file 
<br>
"*a" reads the whole file 
<br>
"*line" reads the next line 
<br>
"*number" reads a number 
<br>
num reads a string with up to num characters 
<br>
The call io.read("*all") reads the whole current input file, starting at its current position. If we are at the end of file, or if the file is empty, the call returns an empty string. 



</body></html> ]====],
["sin"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.sin() function</h1>

This is the sine function in Lua. It gives the result of an argument in radians.
<pre>
>  a=-10.23
> print(math.sin(a))
0.72098452311421
>  a=12.2332
> print(math.sin(a))
-0.32704093004026

</pre>

</body></html> ]====],
["Lua"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>Lua language </h1>

<hr>



<h3>24.3.2 &ndash; Error Handling in Library Code</h3>

<p>Lua is a <em>safe</em> language.
That means that, no matter what you write,
no matter how wrong it is,
you can always understand the behavior of a program
in terms of Lua itself.
Moreover, errors are detected and explained in terms of Lua, too.


<hr>
<h1>25 &ndash; Extending your Application</h1>

<p>An important use of Lua is as a <em>configuration</em> language.



</body></html> ]====],
["table"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>table table</h1>

This table contains the functions for table manipulation.

</body></html> ]====],
["pack"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>string.pack() function</h1>

This function is only for IT professionals returning a binary form of a string.

<h1>table.pack() function</h1>

This function "returns a new table with all parameters stored into keys 1,2, etc. and with a field "n" with the total number of parameters. Note that the resulting table may not be a sequence." (Manual p. 43) The length of the table is not the number of indices starting with 1 in a subsequent manner, but nil values are counted. So, it must be used very carfully or only by IT professionals.

<pre>

> bTable=table.pack("sdf","142")
> for i,v in ipairs(bTable) do print(i,v) end
1       sdf
2       142

> for i,v in pairs(bTable) do print(i,v) end
1       sdf
2       142
n       2


> bTable=table.pack("sdf","142",nil,"Test",123)
> for i,v in pairs(bTable) do print(i,v) end
1       sdf
2       142
4       Test
5       123
n       5
> for i,v in ipairs(bTable) do print(i,v) end
1       sdf
2       142

> bTable[#bTable+1]="0000"
> for i,v in ipairs(bTable) do print(i,v) end
1       sdf
2       142
> for i,v in pairs(bTable) do print(i,v) end
1       sdf
2       142
4       Test
5       123
6       0000
n       5
> print(#bTable)
6
> print(bTable[3])
nil
> cTable={"sdf","142",[4]="Test"}
> print(#cTable)
2
> bTable.n=nil
> print(#bTable)
6

</pre>

</body></html> ]====],
["cosh"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.cosh() function</h1>

This is the hyperbolic cosine function in Lua.
<pre>
> a=-10.23
> print(math.cosh(a))
13861.255052063
> a=12.2332
> print(math.cosh(a))
102749.86510015

</pre>

</body></html> ]====],
["write"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>io.write() function</h1>

The io.write function is needed to write in files after having opened them by io.output or io.open  or in the console without line breaks.
<br>
It can be used in this way:
<pre>
outputfile=io.output("C:\\temp\\test1.txt")
outputfile:write(Text)
io.close(outputfile)
</pre>
 
<br>
or in this way:
<br>
<pre>
outputfile=io.open("C:\\temp\\test1.txt","w")
outputfile:write(Text)
outputfile:close()

outputfile=io.open("C:\\temp\\test1.txt","a")
outputfile:write(Text)
outputfile:close()
</pre>
<br>

The use of : is equivalent to use the expression before : as first argument.

<br>
or in this way:
<br>
<pre>
io.write("This is ")
io.write("text in the ")
io.write("same line.")
<br>
</pre>

To write data that can afterwords be reused as a Lua code,  please see chapter 12.1 � Serialization for IT professionals.
</body></html> ]====],
["_G"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>_G </h1>

_G is the Lua table where all global variables of a Lua session are stored, inclusive also _G itself so that it can be indefinitly read.

</body></html> ]====],
["rawget"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>rawget() function</h1>

This function is only for IT professionals getting real value of a table index without invoking any metamethod. Metamethods are only for IT professionals.

</body></html> ]====],
["output"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>io.output() function</h1>

The io.output function is needed to open files for writing something in it.
<br>
It can be used in this way:
<br>
<pre>
outputfile=io.output("C:\\temp\\test1.txt")
outputfile:write("Text")
io.close(outputfile)
</pre>
</body></html> ]====],
["match"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>string.match() function </h1>


This function returns the first match in a string of a pattern or capture from the pattern as argument. With the optional third argument the start of match is specified.

<br><br>
If there is no match the function returns <code>nil</code>.



<pre>


> print(string.match("Das ist ein Text","Text"))
Text

> print(string.match("Das ist ein Text","e."))
ei
> print(string.match("Das ist ein Text","e.",12))
ex

> print(string.match("Das ist ein Text mit Zahlen 1234567","%d+"))
1234567


</pre>



<hr>
<h2>20.2 &ndash; Patterns with more explainations</h2>

<p>You can make patterns more useful with <em>character classes</em>.
A character class is an item in a pattern that can match any
character in a specific set.
For instance, the class <code>%d</code> matches any digit.
Therefore, you can search for a date in the format <code>dd/mm/yyyy</code>
with the pattern '<code>%d%d/%d%d/%d%d%d%d</code>':
<pre>
    s = "Deadline is 30/05/1999, firm"
    date = "%d%d/%d%d/%d%d%d%d"
    print(string.sub(s, string.find(s, date)))   --> 30/05/1999
</pre>
The following table lists all character classes:
<table align="center" border=1>

<tr><td><code><i>x</i></code></td><td>character <i>x</i> itself except all <i>magic characters</i> <code>( ) . % + - * ? [ ] ^ $</code> </td></tr>



<tr><td><code>.</code></td><td>all characters</td></tr>


<tr><td><code>%a</code></td><td>letters</td></tr>
<tr><td><code>%A</code></td><td>not letters</td></tr>

<tr><td><code>%c</code></td><td>control characters</td></tr>
<tr><td><code>%C</code></td><td>not control characters</td></tr>


<tr><td><code>%d</code></td><td>digits</td></tr>
<tr><td><code>%D</code></td><td>not digits</td></tr>


<tr><td><code>%g</code></td><td>printable characters except space</td></tr>
<tr><td><code>%G</code></td><td>space</td></tr>

<tr><td><code>%l</code></td><td>lower case letters</td></tr>
<tr><td><code>%L</code></td><td>not lower case letters</td></tr>


<tr><td><code>%p</code></td><td>punctuation characters</td></tr>
<tr><td><code>%P</code></td><td>not punctuation characters</td></tr>


<tr><td><code>%s</code></td><td>space characters</td></tr>
<tr><td><code>%S</code></td><td>not space characters</td></tr>

<tr><td><code>%u</code></td><td>upper case letters</td></tr>
<tr><td><code>%U</code></td><td>upper case letters</td></tr>

<tr><td><code>%w</code></td><td>alphanumeric characters</td></tr>
<tr><td><code>%W</code></td><td>not alphanumeric characters</td></tr>

<tr><td><code>%x</code></td><td>hexadecimal digits</td></tr>
<tr><td><code>%X</code></td><td>not hexadecimal digits</td></tr>

<tr><td><code>%z</code></td><td>the character with representation 0</td></tr>
<tr><td><code>%Z</code></td><td>not the character with representation 0</td></tr>

<tr><td><code>[char-set]</code></td><td>the union of all characters in char-set as shown afterwards</td></tr>
 
<tr><td><code>[^char-set]</code></td><td>the complement of char-set</td></tr>

<tr><td> </td><td><b>The definitions of letter, space, and other character groups depend on the current locale.  In particular, the class <code>[a-z]</code> may not be equivalent to <code>%l</code>.</b></td></tr>
</table><p>


An upper case version of any of those classes represents
the complement of the class.
For instance, '<code>%A</code>' represents all non-letter characters:
<pre>
    print(string.gsub("hello, up-down!", "%A", "."))
      --> hello..up.down. 4
</pre>
(The <code>4</code> is not part of the result string.
It is the second result of <code>gsub</code>,
the total number of substitutions.
Other examples that print the result of <code>gsub</code> will
omit this count.)

<p>Some characters, called <em>magic characters</em>,
have special meanings when used in a pattern.
The magic characters are
<pre>
    ( ) . % + - * ? [ ] ^ $
</pre>
The character `<code>%</code>&acute; works as an escape for those magic characters.
So, '<code>%.</code>' matches a dot; '<code>%%</code>' matches the character `<code>%</code>&acute; itself.
You can use the escape `<code>%</code>&acute; not only for the magic characters,
but also for all other non-alphanumeric characters.
When in doubt, play safe and put an escape.

<p>For Lua, patterns are regular strings.
They have no special treatment
and follow the same rules as other strings.
Only inside the functions are they interpreted as patterns
and only then does the `<code>%</code>&acute; work as an escape.
Therefore, if you need to put a quote inside a pattern,
you must use the same techniques that you
use to put a quote inside other strings;
for instance, you can escape the quote with a `<code>\</code>&acute;,
which is the escape character for Lua.

<p>A <em>char-set</em> allows you to create your own character classes,
combining different classes and single characters
between square brackets.
For instance,
the char-set '<code>[%w_]</code>' matches both alphanumeric characters
and underscores,
the char-set '<code>[01]</code>' matches binary digits,
and the char-set '<code>[%[%]]</code>' matches square brackets.
To count the number of vowels in a text,
you can write
<pre>
    _, nvow = string.gsub(text, "[AEIOUaeiou]", "")
</pre>
You can also include character ranges in a char-set,
by writing the first and the last characters of the range
separated by a hyphen.
You will seldom need this facility,
because most useful ranges are already predefined;
for instance, '<code>[0-9]</code>' is simpler when written as '<code>%d</code>',
'<code>[0-9a-fA-F]</code>' is the same as '<code>%x</code>'.
However, if you need to find an octal digit,
then you may prefer '<code>[0-7]</code>',
instead of an explicit enumeration ('<code>[01234567]</code>').
You can get the complement of a char-set by starting it with `<code>^</code>&acute;:
'<code>[^0-7]</code>' finds any character that is not an octal digit
and '<code>[^\n]</code>' matches any character different from newline.
But remember that you can negate simple
classes with its upper case version:
'<code>%S</code>' is simpler than '<code>[^%s]</code>'.

<p>Character classes follow the current locale set for Lua.
Therefore, the class '<code>[a-z]</code>' can be different from '<code>%l</code>'.
In a proper locale,
the latter form includes letters such as `<code>&ccedil;</code>&acute; and `<code>&atilde;</code>&acute;.
You should always use the latter form,
unless you have a strong reason to do otherwise:
It is simpler, more portable, and slightly more efficient.

<p>You can make patterns still more useful with modifiers for
repetitions and optional parts.
Patterns in Lua offer four modifiers:
<table align="center" border=1>
<tr><td><code>+</code></td><td>1 or more repetitions</td></tr>
<tr><td><code>*</code></td><td>0 or more repetitions</td></tr>
<tr><td><code>-</code></td><td>also 0 or more repetitions</td></tr>
<tr><td><code>?</code></td><td>optional (0 or 1 occurrence)</td></tr>
</table><p>
The `<code>+</code>&acute; modifier matches one or more
characters of the original class.
It will always get the longest sequence that matches the pattern.
For instance, the pattern '<code>%a+</code>' means one or more letters,
or a word:
<pre>
    print(string.gsub("one, and two; and three", "%a+", "word"))
      --> word, word word; word word
</pre>
The pattern '<code>%d+</code>' matches one or more digits (an integer):
<pre>
    i, j = string.find("the number 1298 is even", "%d+")
    print(i,j)   --> 12  15
</pre>

<p>The modifier `<code>*</code>&acute; is similar to `<code>+</code>&acute;,
but it also accepts zero occurrences of characters of the class.
A typical use is to match optional spaces between parts of a pattern.
For instance, to match an empty parenthesis pair,
such as <code>()</code> or <code>( )</code>,
you use the pattern '<code>%(%s*%)</code>'.
(The pattern '<code>%s*</code>' matches zero or more spaces.
Parentheses have a special meaning in a pattern,
so we must escape them with a `<code>%</code>&acute;.)
As another example, the pattern '<code>[_%a][_%w]*</code>'
matches identifiers in a Lua program:
a sequence that starts with a letter or an underscore,
followed by zero or more underscores or alphanumeric characters.

<p>Like `<code>*</code>&acute;,
the modifier `<code>-</code>&acute; also matches zero or more occurrences
of characters of the original class.
However, instead of matching the longest sequence,
it matches the shortest one.
Sometimes, there is no difference between `<code>*</code>&acute; or `<code>-</code>&acute;,
but usually they present rather different results.
For instance, if you try to find an identifier with the
pattern '<code>[_%a][_%w]-</code>',
you will find only the first letter,
because the '<code>[_%w]-</code>' will always match the empty sequence.
On the other hand,
suppose you want to find comments in a C program.
Many people would first try '<code>/%*.*%*/</code>'
(that is, a <code>"/*"</code> followed by a sequence of any
characters followed by <code>"*/"</code>,
written with the appropriate escapes).
However, because the '<code>.*</code>' expands as far as it can,
the first <code>"/*"</code> in the program would close only
with the last <code>"*/"</code>:
<pre>
    test = "int x; /* x */  int y; /* y */"
    print(string.gsub(test, "/%*.*%*/", "&lt;COMMENT>"))
      --> int x; &lt;COMMENT>
</pre>
The pattern '<code>.-</code>', instead,
will expand the least amount necessary to find the first <code>"*/"</code>,
so that you get your desired result:
<pre>
    test = "int x; /* x */  int y; /* y */"
    print(string.gsub(test, "/%*.-%*/", "&lt;COMMENT>"))
        --> int x; &lt;COMMENT>  int y; &lt;COMMENT>
</pre>

<p>The last modifier, `<code>?</code>&acute;, matches an optional character.
As an example, suppose we want to find an integer in a text,
where the number may contain an optional sign.
The pattern '<code>[+-]?%d+</code>' does the job,
matching numerals like <code>"-12"</code>,
<code>"23"</code> and <code>"+1009"</code>.
The '<code>[+-]</code>' is a character class that matches
both a `<code>+</code>&acute; or a `<code>-</code>&acute; sign;
the following `<code>?</code>&acute; makes that sign optional.

<p>Unlike some other systems, in Lua a modifier can only be
applied to a character class;
there is no way to group patterns under a modifier.
For instance, there is no pattern that matches an optional
word (unless the word has only one letter).
Usually you can circumvent this limitation using some of the
advanced techniques that we will see later.

<p>If a pattern begins with a `<code>^</code>&acute;,
it will match only at the beginning of the subject string.
Similarly, if it ends with a `<code>$</code>&acute;,
it will match only at the end of the subject string.
These marks can be used both to restrict the patterns that you find
and to anchor patterns.
For instance, the test
<pre>
    if string.find(s, "^%d") then ...
</pre>
checks whether the string <code>s</code> starts with a digit
and the test
<pre>
    if string.find(s, "^[+-]?%d+$") then ...
</pre>
checks whether that string represents an integer number,
without other leading or trailing characters.

<p>Another item in a pattern is the '<code>%b</code>',
that matches balanced strings.
Such item is written as '<code>%b<em>xy</em></code>',
where <em>x</em> and <em>y</em> are any two distinct characters;
the <em>x</em> acts as an opening character
and the <em>y</em> as the closing one.
For instance, the pattern '<code>%b()</code>' matches
parts of the string that start with a
`<code>(</code>&acute; and finish at the respective `<code>)</code>&acute;:
<pre>
    print(string.gsub("a (enclosed (in) parentheses) line",
                      "%b()", ""))
      --> a  line
</pre>
Typically, this pattern is used as
'<code>%b()</code>', '<code>%b[]</code>', '<code>%b%{%}</code>', or '<code>%b&lt;></code>',
but you can use any characters as delimiters.

<hr>
<table width="100%" class="nav">
<tr>
<td width="90%" align="left">
<small>
  Copyright &copy; 2003&ndash;2004 Roberto Ierusalimschy.  All rights reserved.
</small>
</td>

</tr>
</table>

<h2>20.3 Captures (and Manual p.42)</h2>

"A pattern can contain sub-patterns enclosed in parentheses; they describe <i>captures</i>. When a match succeeds, the substrings of the subject string that match captures are stored (captured) for future use. Captures are numbered according to their left parentheses. For instance, in the pattern <code>"(a*(.)%w(%s*))"</code>, the part of the string matchin <code>"a*(.)%w(%s*)"</code> is stored as the first capture (and therefore has number 1); the character matching <code>"."</code> is captured with number 2, and the part matching <code>"%s*"</code> has number 3. As a special case, the empty capture <code>"()"</code> captures the current string position (a number). For instance, if we apply the pattern <code>"()aa()"</code> on the string <code>"flaaap"</code>, there will be two captures: 3 and 5." (Manual p. 42)


</body></html> ]====],
["len"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>string.len() function</h1>

This function is equivalent to the #-operator. It returns the length of a string.

<pre>

> a="replace"
> print(#a)
7
> print(a:len())
7

</pre>



</body></html> ]====],
["ult"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.ult() function</h1>

This function returns false or true. It is true if the first argument is lower than the second one when compared as unsigned integers. It seems to be not usable.

<pre>
> print(math.ult(1,0))
false
> print(math.ult(231,-2340))
true
> print(math.ult(-31,230))
false
> print(math.ult(31,230))
true
> print(math.ult(231,2340))
true
> print(math.ult(-231,-2340))
false
> print(math.ult(-2340,-231))
true
> print(math.ult(-2340,-231.345))
stdin:1: bad argument #2 to 'ult' (number has no integer representation)
stack traceback:
        [C]: in function 'math.ult'
        stdin:1: in main chunk
        [C]: in ?
</pre>

</body></html> ]====],
["reverse"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>string.reverse() function</h1>

This function returns a string in which the characters are reversed.


<pre>

> print(string.reverse("Das ist ein Text"))
txeT nie tsi saD
> print(string.reverse("Aha"))
ahA
> print(string.reverse("Ein Esel"))
lesE niE

</pre>


</body></html> ]====],
["modf"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.modf() function</h1>

This is the function in Lua that gives two numbers, the integer part of the argument and the fractional part of its arguments.
<pre>
> print(math.modf(2))
2       0.0
> print(math.modf(2.4323))
2       0.4323
> print(math.modf(232.4323))
232     0.4323
> print(math.modf(232/4323))
0       0.053666435345825
> print(math.modf(232/23))
10      0.086956521739131

</pre>

</body></html> 

 ]====],
["concat"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>table.concat() function</h1>

This function returns a concatenation of all elements in a indexed list as a Lua table. This is usefull for larger concatenations. The repetition of concatenations with <code> .. </code> uses very much computer ressources because each time it is repeated the string is copied. For instance <code> a="a" for i=1,100 do a = a .. a end </code> results in 101 copies even if they are garbage collected after some repetitions. The last two strings have 100 times and 101 times "a". It is better to put strings in a table and then use table.concat to put them together.

The concatenation is effected with a seperator that is not used a the end of the string. A trick to bring it easily without much ressources is to put an empty string at the end of the table.

<pre>

> aTable={"This","is","a","text",".",""}
> textString=table.concat(aTable)
> print(textString)
Thisisatext.
> textString=table.concat(aTable," ")
> print(textString)
This is a text .
> textString=table.concat(aTable,"/")
> print(textString)
This/is/a/text/./
> textString=table.concat(aTable,"\n")
> print(textString)
This
is
a
text
.

> textString=table.concat(aTable,"/",2,3)
> print(textString)
is/a
> textString=table.concat(aTable,"/",2)
> print(textString)
is/a/text/./




</pre>



<hr>
<h2><a name="StringBuffer">11.6 &ndash; String Buffers</a></h2>

<p>Suppose you are building a string piecemeal,
for instance reading a file line by line.
Your typical code would look like this:
<pre>
    -- WARNING: bad code ahead!!
    local buff = ""
    for line in io.lines() do
    buff = buff .. line .. "\n"
    end
</pre>
Despite its innocent look,
that code in Lua can cause a huge performance penalty for large files:
For instance,
it takes almost a minute to read a 350 KB file.
(That is why Lua provides the <code>io.read("*all")</code> option,
which reads the whole file in 0.02 seconds.)

<p>Why is that?
Lua uses a true garbage-collection algorithm;
when it detects that the program is using too much memory,
it goes through all its data structures and frees
those structures that are not in use anymore (the garbage).
Usually this algorithm has a good performance
(it is not by chance that Lua is so fast),
but the above loop takes the worst of the algorithm.

<p>To understand what happens,
let us assume that we are in the middle of the read loop;
<code>buff</code> is already a string with 50 KB
and each line has 20 bytes.
When Lua concatenates <code>buff..line.."\n"</code>,
it creates a new string with 50,020 bytes
and copies 50 KB from <code>buff</code> into this new string.
That is, for each new line,
Lua moves 50 KB of memory, and growing.
After reading 100 new lines (only 2 KB),
Lua has already moved more than 5 MB of memory.
To make things worse,
after the assignment
<pre>
        buff = buff .. line .. "\n"
</pre>
the old string is now garbage.
After two loop cycles,
there are two old strings making a
total of more than 100 KB of garbage.
So, Lua decides, quite correctly,
that it is a good time to run its garbage collector
and so it frees those 100 KB.
The problem is that this will happen every two cycles
and so Lua will run its garbage collector
two thousand times before reading the whole file.
Even with all this work,
its memory usage will be approximately three times the file size.

<p>This problem is not peculiar to Lua:
Other languages with true garbage collection,
and where strings are immutable objects,
present a similar behavior,
Java being the most famous example.
(Java offers the structure <code>StringBuffer</code> to
ameliorate the problem.)

<p>Before we continue, we should remark that,
despite all I said, that situation is not a common problem.
For small strings, the above loop is OK.
To read a whole file, we use the <code>"*all"</code> option,
which reads it at once.
However, sometimes there are no simple solutions.
Then, the only solution is a more efficient algorithm.
Here we show one.

<p>Our original loop took a linear approach to the problem,
concatenating small strings one by one into the accumulator.
This new algorithm avoids this,
using a binary approach instead.
It concatenates several small strings among them
and, occasionally, it concatenates the resulting large strings
into larger ones.
The heart of the algorithm is a stack
that keeps the large strings already created in its bottom,
while small strings enter through the top.
The main invariant of this stack is similar to that of
the popular (among programmers, at least) <em>Tower of Hanoi</em>:
A string in the stack can never sit over a shorter string.
Whenever a new string is pushed over a shorter one,
then (and only then) the algorithm concatenates both.
This concatenation creates a larger string,
which now may be larger than its neighbor in the previous floor.
If that happens, they are joined too.
Those concatenations go down the stack until the loop reaches
a larger string or the stack bottom.
<pre>
    function newStack ()
      return {""}   -- starts with an empty string
    end
    
    function addString (stack, s)
      table.insert(stack, s)    -- push 's' into the the stack
      for i=table.getn(stack)-1, 1, -1 do
        if string.len(stack[i]) > string.len(stack[i+1]) then
          break
        end
        stack[i] = stack[i] .. table.remove(stack)
      end
    end
</pre>
To get the final contents of the buffer,
we just need to concatenate all strings down to the bottom.
The <code>table.concat</code> function does exactly that:
It concatenates all strings of a list.


<p>Using this new data structure,
we can rewrite our program as follows:
<pre>
    local s = newStack()
    for line in io.lines() do
      addString(s, line .. "\n")
    end
    s = toString(s)
</pre>
This new program reduces our original time
to read a 350 KB file from 40 seconds to 0.5 seconds.
The call <code>io.read("*all")</code> is still faster,
finishing the job in 0.02 seconds.

<p>Actually, when we call <code>io.read("*all")</code>,
<code>io.read</code> uses exactly the data structure that we presented here,
but implemented in C.
Several other functions in the Lua
libraries also use this C implementation.
One of these functions is <code>table.concat</code>.
With <code>concat</code>, we can simply collect all strings in a table
and then concatenate all of them at once.
Because <code>concat</code> uses the C implementation,
it is efficient even for huge strings.

<p>The <code>concat</code> function accepts an optional second argument,
which is a separator to be inserted between the strings.
Using this separator, we do not need to insert a newline after
each line:
<pre>
    local t = {}
    for line in io.lines() do
      table.insert(t, line)
    end
    s = table.concat(t, "\n") .. "\n"
</pre>
(The <code>io.lines</code> iterator returns each line without the newline.)
<code>concat</code> inserts the separator between the strings,
but not after the last one,
so we have to add the last newline.
This last concatenation duplicates the resulting string,
which can be quite big.
There is no option to make <code>concat</code> insert this extra separator,
but we can deceive it,
inserting an extra empty string in <code>t</code>:
<pre>
    table.insert(t, "")
    s = table.concat(t, "\n")
</pre>
The extra newline that <code>concat</code> adds before this empty string
is at the end of the resulting string, as we wanted.

<hr>
<table width="100%" class="nav">
<tr>
<td width="90%" align="left">
<small>
  Copyright &copy; 2003&ndash;2004 Roberto Ierusalimschy.  All rights reserved.
</small>
</td>
<td width="10%" align="right">
</table>

</body></html> ]====],
["print"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>print() function</h1>

This function prints the arguments separated with a tab to the console without formatting the output. It shows quickly the value of variables. After the print there is always a new line.

<pre>

> print("a",1,4,"Text")
a       1       4       Text

</pre>

</body></html> ]====],
["rename"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>os.rename() function</h1>


For file manipulation the 
<code>os.rename</code> function changes the name of a file.

<pre>

> os.execute('dir C:\\Temp\\test.lua')
 Le volume dans le lecteur C s'appelle Boot
 Le num�ro de s�rie du volume est 8254-5AFB

 R�pertoire de C:\Temp

20/12/2021  17:46               103 test.lua
               1 fichier(s)              103 octets
               0 R�p(s)  221�997�768�704 octets libres
true    exit    0
> os.rename('C:\\Temp\\test.lua','C:\\Temp\\test_renamed.lua')
true
> os.execute('rename C:\\Temp\\test_renamed.lua test.lua')
true    exit    0
> os.execute('copy C:\\Temp\\test.lua C:\\Temp\\test_copy.lua')
        1 fichier(s) copi�(s).
true    exit    0
> os.execute('del C:\\Temp\\test_copy.lua')
true    exit    0
> os.execute('copy C:\\Temp\\test.lua C:\\Temp\\test_copy.lua')
        1 fichier(s) copi�(s).
true    exit    0
> os.remove('C:\\Temp\\test_copy.lua')
true
> os.execute('dir C:\\Temp\\test.lua')
 Le volume dans le lecteur C s'appelle Boot
 Le num�ro de s�rie du volume est 8254-5AFB

 R�pertoire de C:\Temp

20/12/2021  17:46               103 test.lua
               1 fichier(s)              103 octets
               0 R�p(s)  221�997�244�416 octets libres
true    exit    0

</pre>

</body></html> ]====],
["maxinteger"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.maxinteger constant</h1>

This is the constant in Lua for the maximum integer value.
<pre>
> print(math.maxinteger)
9223372036854775807


</pre>

</body></html> 
]====],
["loaded"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>package.loaded table</h1>

This table is only for IT professionals.


</body></html> ]====],
["ipairs"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>ipairs() function</h1>

This function is used to make generic loops through table indices. To read all the indices i and corresponding values v use the function ipairs. 

<pre>
    -- print the indices i and corresponding values v
> a={1234,234,234}
> a[4]="fourth index"
>     for i,v in ipairs(a) do
>>       print(i,v)
>>     end
1       1234
2       234
3       234
4       fourth index


</pre>

The basic Lua library provides ipairs, a handy function that allows you to iterate over the elements of an array, following the convention that the array ends at its first nil element. 
<br>
<br>
Since you can index a table with any value, you can start the indices of an array with any number that pleases you. However, it is customary in Lua to start arrays with one (and not with zero, as in C) and the standard libraries stick to this convention. 




</body></html> ]====],
["rawset"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>rawset() function</h1>

This function is only for IT professionals setting the real value of a table index without invoking any metamethod. Metamethods are only for IT professionals.


</body></html> ]====],
["close"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>io.close() function</h1>

The close function is needed to close files after having opened them by io.input, io.output or io.open.
<br>
It can be used in this way:
<br>
<pre>
inputfile=io.input("C:\\temp\\test.txt")
Text=inputfile:read("*a")
io.close(inputfile)

outputfile=io.output("C:\\temp\\test1.txt")
outputfile:write(Text)
io.close(outputfile)
</pre>
 
<br>
or in this way:
<br>
<pre>
inputfile=io.open("C:\\temp\\test.txt","r")
Text=inputfile:read("*a")
inputfile:close()

outputfile=io.open("C:\\temp\\test1.txt","w")
outputfile:write(Text)
outputfile:close()

outputfile=io.open("C:\\temp\\test1.txt","a")
outputfile:write(Text)
outputfile:close()
</pre>
<br>
The use of : is equivalent to use the expression before : as first argument.
<br>
<br>
The read function reads strings from the current input file. Its arguments control what is read: 
<br>
"*all" reads the whole file 
<br>
"*a" reads the whole file 
<br>
"*line" reads the next line 
<br>
"*number" reads a number 
<br>
num reads a string with up to num characters 
<br>
The call io.read("*all") reads the whole current input file, starting at its current position. If we are at the end of file, or if the file is empty, the call returns an empty string. 

</body></html> ]====],
["min"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.min() function</h1>

This is the minimum function in Lua. This function gives the minimum value among its arguments.
<pre>
> print(math.min(1,2))
1
> print(math.min(1,2,23,2,-1,42,3,234,234,3))
-1

</pre>

</body></html> 

 ]====],
["loadlib"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>package.loadlib() function</h1>

This function is only for IT professionals.

</body></html> ]====],
["searchers"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>package.searchers table</h1>

This table is only for IT professionals.

</body></html> ]====],
["byte"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>string.byte() function</h1>

This function returns the internal numerical codes of the argument starting at a character position to another one. The default start is at the first position, the default end position is at the first position.

<pre>
> print(string.byte("Hallo"))
72

> print(string.byte("Hallo",1,5))
72      97      108     108     111
> print(string.byte("Hallo",3,5))
108     108     111
> print(string.byte("Hallo",-3))
108
> print(string.byte("Hallo",-3,-1))
108     108     111

</pre>


</body></html> ]====],
["ldexp"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.ldexp(m,x) function</h1>

This is the ldexp function in Lua. This function is the result of <i>m</i><sup><i>x</i></sup>. <i>x</i> should be an integer. I cannot understand the result.
<pre>
> print(math.ldexp(5,4))
80.0
> print(math.ldexp(3,4))
48.0
> print(math.ldexp(3,2))
12.0
> print(math.ldexp(3,26))
201326592.0

</pre>

</body></html> 

</body></html> ]====],
["atan2"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.atan2() function</h1>

This is the arc tangrent function of
<br clear="all" /><table border="0" width="100%"><tr><td>
<table align="center" cellspacing="0"  cellpadding="2"><tr><td nowrap="nowrap" align="center">
</td><td nowrap="nowrap" align="center">
<i>x</i>
<div class="hrcomp"><hr noshade="noshade" size="1"/></div><i>y</i><br /></td><td nowrap="nowrap" align="center">
</td></tr></table>

 in Lua. It gives the inverse tan function. It uses the sign of both parameters to find the quadrant of the result. It also handles correctly the case of <i>x</i> being zero.

<pre>
> a=-100 b=1
> print(math.atan2(a,b))
-1.5607966601082
> print(math.deg(math.atan2(a,b)))
-89.427061302317
> a=12 b=1
> print(math.atan2(a,b))
1.4876550949065
> a=-2 b=1
> print(math.atan2(a,b))
-1.1071487177941
</pre>

With <code>math.deg</code> the radiant is converted into degrees.

</body></html> ]====],
["package"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>package table</h1>

This table contains functions and tables related to the modules loaded. This is only for IT professionals.

</body></html> ]====],
["dofile"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>dofile() function </h1>

With the dofile function the file as the argument of the function is executed as if it were written in the place of the dofile expression.


<br>
If the file C:\temp\test.lua has the content <pre> print("Hello")</pre> then the expression 
<pre> 
dofile("C:\\temp\\test.lua") </pre>

<br>executes the print command and prints "Hello".

<br>
The dofile function is useful also when you are testing a piece of code. You can work with two windows: One of them is a text editor with your program (in a file prog.lua, say) and the other is a console running Lua in interactive mode. After saving a modification that you make to your program, you execute dofile("prog.lua") in the Lua console to load the new code; then you can exercise the new code, calling its functions and printing the results. 



</body></html> ]====],
["huge"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.huge constant</h1>

This is the constant in Lua for a float value greater than any other numeric value.
<pre>
> print(math.huge)
inf
>
> print(math.huge<234)
false
> print(math.huge*math.huge)
inf
> print(math.huge-math.huge)
-nan(ind)
> print(math.huge+math.huge)
inf
> print(math.huge*(-1))
-inf

</pre>

</body></html> 

</body></html> ]====],
["tmpfile"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>io.tmpfile() function</h1>

This function is a temporary file name. This is for IT professionals.



</body></html> ]====],
["preload"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>package.preload table</h1>

This table is only for IT professionals.

</body></html> ]====],
["rawlen"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>rawlen() function</h1>

This function is only for IT professionals giving the length of an table or string argument without invoking any metamethod. Metamethods are only for IT professionals. 

</body></html> ]====],
["read"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>io.read() function</h1>

The io.read function is needed to read files after having opened them by io.input or io.open.
<br>
It can be used in this way:
<br>
<pre>
inputfile=io.input("C:\\temp\\test.txt")
Text=inputfile:read("*a")
io.close(inputfile)
</pre>
 
<br>
or in this way:
<br>
<pre>
inputfile=io.open("C:\\temp\\test.txt","r")
Text=inputfile:read("*a")
inputfile:close()
</pre>
<br>

The use of : is equivalent to use the expression before : as first argument.

<br>
<br>
The read function reads strings from the current input file. Its arguments control what is read: 
<br>
"*all" reads the whole file 
<br>
"*a" reads the whole file 
<br>
"*line" reads the next line 
<br>
"*number" reads a number 
<br>
num reads a string with up to num characters 
<br>
The call io.read("*all") reads the whole current input file, starting at its current position. If we are at the end of file, or if the file is empty, the call returns an empty string. 

<br>
<br>
At chapter 21.2.1 - a small performance trick is shown. There is the possibility to have two arguments for read:
<br>
<br>
<pre>
lines, rest = f:read(BUFSIZE, "*line")
</pre>
<br>
<br>
This reads a chunk of length BUFSIZE and the rest of the line.

You can also read for instance three columns of numbers:
<pre>
    6.0       -3.23     15e12
    4.3       234       1000001

n1, n2, n3 = io.read("*number", "*number","*number")
</pre>



<br>
Instead of writing a loop through the file:
<br>
<pre>
inputfile=io.open("C:\\temp\\test.txt","r")
while true do
    if Text then break end
    Text=inputfile:read("*line")
end --while true do
inputfile:close()
</pre>

<br>
it is easier to read the file with a for loop:
<br>
<pre>
for line in io.lines("C:\\temp\\test.txt") do
     print(line)
end --for line in io.lines("C:\\temp\\test.txt") do
</pre>
<br>
This temporary file is closed automatically at the end of the for loop.

</body></html> ]====],
["stdin"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>io.stdin() function</h1>

This function is the file for the standard input. This is for IT professionals.


</body></html> ]====],
["execute"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>os.execute() function</h1>

This function is equivalent to the C function <code> system </code>. It passes <code> command </code> to be executed by an operating system shell. The help of Windows commands is to by using <code> os.execute('help')</code>.

<br><br>
The first result is <code> true </code> if the command terminated successfully or <code> nil </code> otherwise. 
<br><br>
The second result is a string with <code>"exit"</code> if the command exits normally or <code> "signal"</code> if the command is terminated by a signal.

<br><br>
The third result is a number as exit status number or signal number.

<br><br>
The <code>os.execute</code> function is powerful,
but it is also highly system dependent.

<pre>

> a,b,c=os.execute('dir c:\\Temp\\test.lua') print(a,b,c)
 Le volume dans le lecteur C s'appelle Boot
 Le num�ro de s�rie du volume est 8254-5AFB

 R�pertoire de c:\Temp

20/12/2021  17:46               103 test.lua
               1 fichier(s)              103 octets
               0 R�p(s)  222�001�283�072 octets libres
true    exit    0
> a,b,c=os.execute() print(a,b,c)
true    nil     nil
> a,b,c=os.execute('help') print(a,b,c)
Pour plus d'informations sur une commande sp�cifique, entrez HELP
suivi de la commande.
ASSOC          Affiche ou modifie les applications associ�es aux extensions de
               fichiers.
ATTRIB         Affiche ou modifie les attributs d'un fichier.
BREAK          Active ou d�sactive le contr�le �tendu de CTRL+C.
BCDEDIT        D�finit les propri�t�s dans la base de donn�es de d�marrage pour
               le contr�le du chargement d'amor�age.
CACLS          Affiche ou modifie les listes de contr�les d'acc�s aux fichiers.
CALL           Appelle un fichier de commandes � partir d'un autre fichier de
               commandes.
CD             Modifie le r�pertoire ou affiche le r�pertoire actif.
CHCP           Modifie ou affiche le num�ro de la page de code active.
CHDIR          Modifie le r�pertoire ou affiche le nom du r�pertoire actif.
CHKDSK         V�rifie un disque et affiche un rapport d'�tat.
CHKNTFS        Affiche ou modifie la v�rification du disque au d�marrage.
CLS            Efface l'�cran.
CMD            Ex�cute une nouvelle instance de l'interpr�teur de commandes de
               Windows.
COLOR          Modifie les couleurs du premier plan et de l'arri�re-plan de la
               console.
COMP           Compare les contenus de deux fichiers ou groupes de fichiers.
COMPACT        Modifie ou affiche la compression des fichiers sur une
               partition NTFS.
CONVERT        Convertit des volumes FAT en volumes NTFS. Vous ne pouvez pas
               convertir le lecteur en cours d'utilisation.
COPY           Copie un ou plusieurs fichiers.
DATE           Affiche ou d�finit la date.
DEL            Supprime un ou plusieurs fichiers.
DIR            Affiche la liste des fichiers et des sous-r�pertoires d'un
               r�pertoire.
DISKCOMP       Compare les contenus de deux disquettes.
DISKCOPY       Copie le contenu d'une disquette sur une autre.
DISKPART       Affiche ou configure les propri�t�s d'une partition de disque.
DOSKEY         Modifie les lignes de commande, rappelle des commandes Windows,
               et cr�e des macros.
DRIVERQUERY    Affiche l'�tat et les propri�t�s du pilote de p�riph�rique en
               cours d'utilisation.
ECHO           Affiche des messages ou active/d�sactive l'affichage des
               commandes.
ENDLOCAL       Stoppe la localisation des modifications d'environnement dans
               un fichier de commandes.
ERASE          Supprime un ou plusieurs fichiers.
EXIT           Quitte l'interpr�teur de commandes (CMD.EXE).
FC             Compare deux fichiers ou groupes de fichiers et affiche
               les diff�rences.
FIND           Recherche une cha�ne de caract�res dans un ou plusieurs
               fichiers.
FINDSTR        Cherche des cha�nes dans les fichiers.
FOR            Ex�cute une commande sur chaque fichier d'un ensemble de
               fichiers.
FORMAT         Formate un disque devant �tre utilis� avec Windows.
FSUTIL         Affiche ou configure les propri�t�s du syst�me de fichiers.
FTYPE          Affiche ou modifie les types de fichiers utilis�s dans les
               associations d'extensions.
GOTO           Indique l'ex�cution d'un fichier de commandes pour une ligne
               identifi�e par une �tiquette.
GPRESULT       Affiche les informations de strat�gie de groupe pour un
               ordinateur ou un utilisateur.
GRAFTABL       Permet � Windows d'afficher un jeu de caract�res en
               mode graphique.
HELP           Affiche des informations sur les commandes de Windows.
ICACLS         Afficher, modifier, sauvegarder ou restaurer les listes de
               contr�le d'acc�s pour les fichiers et les r�pertoires.
IF             Effectue un traitement conditionnel dans un fichier de
               commandes.
LABEL          Cr�e, modifie ou supprime le nom de volume d'un disque.
MD             Cr�e un r�pertoire.
MKDIR          Cr�e un r�pertoire.
MKLINK         Cr�er des liens symboliques et des liens physiques
MODE           Configure un p�riph�rique du syst�me.
MORE           Affiche la sortie �cran par �cran.
MOVE           D�place un ou plusieurs fichiers d'un r�pertoire
               � un autre.
OPENFILES      Affiche les fichiers partag�s ouverts � distance par les
               utilisateurs.
PATH           Affiche ou d�finit le chemin de recherche des fichiers
               ex�cutables.
PAUSE          Interrompt l'ex�cution d'un fichier de commandes et affiche un
               message.
POPD           Restaure la valeur pr�c�dente du r�pertoire actif enregistr�e
               par PUSHD.
PRINT          Imprime un fichier texte.
PROMPT         Modifie l'invite de commande de Windows.
PUSHD          Enregistre le r�pertoire actif puis le modifie.
RD             Supprime un r�pertoire.
RECOVER        R�cup�re l'information lisible d'un disque d�fectueux.
REM            Ins�re un commentaire dans un fichier de commandes ou
               CONFIG.SYS.
REN            Renomme un ou plusieurs fichiers.
RENAME         Renomme un ou plusieurs fichiers.
REPLACE        Remplace des fichiers.
RMDIR          Supprime un r�pertoire.
ROBOCOPY       Utilitaire avanc� pour copier les fichiers et les
               arborescences de r�pertoires
SET            Affiche, d�finit ou supprime des variables d'environnement
               Windows.
SETLOCAL       Commence la localisation des modifications d'environnement dans
               un fichier de commandes.
SC             Affiche ou configure les services (processus en arri�re-plan).
SCHTASKS       Planifie les commandes et les programmes � ex�cuter sur
               l'ordinateur.
SHIFT          Modifie la position des param�tres rempla�ables dans un fichier
               de commandes.
SHUTDOWN       Permet un arr�t local ou distant correct de l'ordinateur.
SORT           Trie les entr�es.
START          Ouvre une fen�tre s�par�e pour l'ex�cution d'un programme ou
               d'une commande sp�cifique.
SUBST          Associe un chemin d'acc�s � une lettre de lecteur.
SYSTEMINFO     Affiche les propri�t�s et la configuration sp�cifiques de
               l'ordinateur.
TASKLIST       Affiche toutes les t�ches en cours d'ex�cution, y compris les
               services.
TASKKILL       Termine ou interrompt un processus ou une application en cours
               d'ex�cution.
TIME           Affiche ou d�finit l'heure du syst�me.
TITLE          D�finit le titre de la fen�tre pour une session CMD.EXE.
TREE           Affiche le graphisme de la structure de r�pertoire d'un lecteur
               ou d'un chemin d'acc�s.
TYPE           Affiche le contenu d'un fichier texte.
VER            Affiche la version de Windows.
VERIFY         Demande � Windows de v�rifier si vos fichiers sont
               correctement �crits sur le disque.
VOL            Affiche le nom et le num�ro de s�rie d'un volume de disque.
XCOPY          Copie les fichiers et les arborescences de r�pertoires.
WMIC           Affiche les informations WMI dans l'interface de commande
               interactive.

Pour obtenir plus d'informations sur les outils, consultez la r�f�rence de
commande en ligne dans l'aide en ligne.
nil     exit    1

</pre>

</body></html> ]====],
["gsub"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>string.gsub() function</h1>


This function returns a copy of a string in which all occurences of a pattern have been replaced by a replacement string, a function or a table. As second value it returns the total number of matches that occured. The name <code>gsub</code> comes from global substitution.

<br><br>
As a second optional argument the number of maximum replacements is given.


<pre>

> a="replace" x="Das ist ein Text."
> print(x:gsub("Text",a))
Das ist ein replace.    1


> print(string.gsub("hello world","(%w+)","%1 %1"))
hello hello world world 2

> print(string.gsub("hello world","(%w+)","%1 %1",1))
hello hello world       1

> print(string.gsub("hello world","(%w+)","%1 %1",0))
hello world     0


> print(string.gsub("hello world from Lua","(%w+)%s*(%w+)","%2 %1"))
world hello Lua from    2


> print(string.gsub("username=$USERNAME, userprofile = $USERPROFILE","%$(%w+)",os.getenv))
username=b-kaiser, userprofile = C:\Users\b-kaiser      2

> print(x:gsub("((.-)=)","%1~%2~"):gsub("~(.-)~",function(s) return load("return " .. s)() end))
4+5=9   1
> x="4+5^2-math.cos(120)="
> print(x:gsub("((.-)=)","%1~%2~"):gsub("~(.-)~",function(s) return load("return " .. s)() end))
4+5^2-math.cos(120)=28.185819029473     1


> t={name="andere",wert="sollen",["Das"]="es sollte"}
> x="Der name ist ein wert mit Das habe ich mir gedacht"
> print(x:gsub("%w+",t))
Der andere ist ein sollen mit es sollte habe ich mir gedacht    11


</pre>




<hr>
<h2>20.2 &ndash; Patterns with more explainations</h2>

<p>You can make patterns more useful with <em>character classes</em>.
A character class is an item in a pattern that can match any
character in a specific set.
For instance, the class <code>%d</code> matches any digit.
Therefore, you can search for a date in the format <code>dd/mm/yyyy</code>
with the pattern '<code>%d%d/%d%d/%d%d%d%d</code>':
<pre>
    s = "Deadline is 30/05/1999, firm"
    date = "%d%d/%d%d/%d%d%d%d"
    print(string.sub(s, string.find(s, date)))   --> 30/05/1999
</pre>
The following table lists all character classes:
<table align="center" border=1>

<tr><td><code><i>x</i></code></td><td>character <i>x</i> itself except all <i>magic characters</i> <code>( ) . % + - * ? [ ] ^ $</code> </td></tr>



<tr><td><code>.</code></td><td>all characters</td></tr>


<tr><td><code>%a</code></td><td>letters</td></tr>
<tr><td><code>%A</code></td><td>not letters</td></tr>

<tr><td><code>%c</code></td><td>control characters</td></tr>
<tr><td><code>%C</code></td><td>not control characters</td></tr>


<tr><td><code>%d</code></td><td>digits</td></tr>
<tr><td><code>%D</code></td><td>not digits</td></tr>


<tr><td><code>%g</code></td><td>printable characters except space</td></tr>
<tr><td><code>%G</code></td><td>space</td></tr>

<tr><td><code>%l</code></td><td>lower case letters</td></tr>
<tr><td><code>%L</code></td><td>not lower case letters</td></tr>


<tr><td><code>%p</code></td><td>punctuation characters</td></tr>
<tr><td><code>%P</code></td><td>not punctuation characters</td></tr>


<tr><td><code>%s</code></td><td>space characters</td></tr>
<tr><td><code>%S</code></td><td>not space characters</td></tr>

<tr><td><code>%u</code></td><td>upper case letters</td></tr>
<tr><td><code>%U</code></td><td>upper case letters</td></tr>

<tr><td><code>%w</code></td><td>alphanumeric characters</td></tr>
<tr><td><code>%W</code></td><td>not alphanumeric characters</td></tr>

<tr><td><code>%x</code></td><td>hexadecimal digits</td></tr>
<tr><td><code>%X</code></td><td>not hexadecimal digits</td></tr>

<tr><td><code>%z</code></td><td>the character with representation 0</td></tr>
<tr><td><code>%Z</code></td><td>not the character with representation 0</td></tr>

<tr><td><code>[char-set]</code></td><td>the union of all characters in char-set as shown afterwards</td></tr>
 
<tr><td><code>[^char-set]</code></td><td>the complement of char-set</td></tr>

<tr><td> </td><td><b>The definitions of letter, space, and other character groups depend on the current locale.  In particular, the class <code>[a-z]</code> may not be equivalent to <code>%l</code>.</b></td></tr>
</table><p>


An upper case version of any of those classes represents
the complement of the class.
For instance, '<code>%A</code>' represents all non-letter characters:
<pre>
    print(string.gsub("hello, up-down!", "%A", "."))
      --> hello..up.down. 4
</pre>
(The <code>4</code> is not part of the result string.
It is the second result of <code>gsub</code>,
the total number of substitutions.
Other examples that print the result of <code>gsub</code> will
omit this count.)

<p>Some characters, called <em>magic characters</em>,
have special meanings when used in a pattern.
The magic characters are
<pre>
    ( ) . % + - * ? [ ] ^ $
</pre>
The character `<code>%</code>&acute; works as an escape for those magic characters.
So, '<code>%.</code>' matches a dot; '<code>%%</code>' matches the character `<code>%</code>&acute; itself.
You can use the escape `<code>%</code>&acute; not only for the magic characters,
but also for all other non-alphanumeric characters.
When in doubt, play safe and put an escape.

<p>For Lua, patterns are regular strings.
They have no special treatment
and follow the same rules as other strings.
Only inside the functions are they interpreted as patterns
and only then does the `<code>%</code>&acute; work as an escape.
Therefore, if you need to put a quote inside a pattern,
you must use the same techniques that you
use to put a quote inside other strings;
for instance, you can escape the quote with a `<code>\</code>&acute;,
which is the escape character for Lua.

<p>A <em>char-set</em> allows you to create your own character classes,
combining different classes and single characters
between square brackets.
For instance,
the char-set '<code>[%w_]</code>' matches both alphanumeric characters
and underscores,
the char-set '<code>[01]</code>' matches binary digits,
and the char-set '<code>[%[%]]</code>' matches square brackets.
To count the number of vowels in a text,
you can write
<pre>
    _, nvow = string.gsub(text, "[AEIOUaeiou]", "")
</pre>
You can also include character ranges in a char-set,
by writing the first and the last characters of the range
separated by a hyphen.
You will seldom need this facility,
because most useful ranges are already predefined;
for instance, '<code>[0-9]</code>' is simpler when written as '<code>%d</code>',
'<code>[0-9a-fA-F]</code>' is the same as '<code>%x</code>'.
However, if you need to find an octal digit,
then you may prefer '<code>[0-7]</code>',
instead of an explicit enumeration ('<code>[01234567]</code>').
You can get the complement of a char-set by starting it with `<code>^</code>&acute;:
'<code>[^0-7]</code>' finds any character that is not an octal digit
and '<code>[^\n]</code>' matches any character different from newline.
But remember that you can negate simple
classes with its upper case version:
'<code>%S</code>' is simpler than '<code>[^%s]</code>'.

<p>Character classes follow the current locale set for Lua.
Therefore, the class '<code>[a-z]</code>' can be different from '<code>%l</code>'.
In a proper locale,
the latter form includes letters such as `<code>&ccedil;</code>&acute; and `<code>&atilde;</code>&acute;.
You should always use the latter form,
unless you have a strong reason to do otherwise:
It is simpler, more portable, and slightly more efficient.

<p>You can make patterns still more useful with modifiers for
repetitions and optional parts.
Patterns in Lua offer four modifiers:
<table align="center" border=1>
<tr><td><code>+</code></td><td>1 or more repetitions</td></tr>
<tr><td><code>*</code></td><td>0 or more repetitions</td></tr>
<tr><td><code>-</code></td><td>also 0 or more repetitions</td></tr>
<tr><td><code>?</code></td><td>optional (0 or 1 occurrence)</td></tr>
</table><p>
The `<code>+</code>&acute; modifier matches one or more
characters of the original class.
It will always get the longest sequence that matches the pattern.
For instance, the pattern '<code>%a+</code>' means one or more letters,
or a word:
<pre>
    print(string.gsub("one, and two; and three", "%a+", "word"))
      --> word, word word; word word
</pre>
The pattern '<code>%d+</code>' matches one or more digits (an integer):
<pre>
    i, j = string.find("the number 1298 is even", "%d+")
    print(i,j)   --> 12  15
</pre>

<p>The modifier `<code>*</code>&acute; is similar to `<code>+</code>&acute;,
but it also accepts zero occurrences of characters of the class.
A typical use is to match optional spaces between parts of a pattern.
For instance, to match an empty parenthesis pair,
such as <code>()</code> or <code>( )</code>,
you use the pattern '<code>%(%s*%)</code>'.
(The pattern '<code>%s*</code>' matches zero or more spaces.
Parentheses have a special meaning in a pattern,
so we must escape them with a `<code>%</code>&acute;.)
As another example, the pattern '<code>[_%a][_%w]*</code>'
matches identifiers in a Lua program:
a sequence that starts with a letter or an underscore,
followed by zero or more underscores or alphanumeric characters.

<p>Like `<code>*</code>&acute;,
the modifier `<code>-</code>&acute; also matches zero or more occurrences
of characters of the original class.
However, instead of matching the longest sequence,
it matches the shortest one.
Sometimes, there is no difference between `<code>*</code>&acute; or `<code>-</code>&acute;,
but usually they present rather different results.
For instance, if you try to find an identifier with the
pattern '<code>[_%a][_%w]-</code>',
you will find only the first letter,
because the '<code>[_%w]-</code>' will always match the empty sequence.
On the other hand,
suppose you want to find comments in a C program.
Many people would first try '<code>/%*.*%*/</code>'
(that is, a <code>"/*"</code> followed by a sequence of any
characters followed by <code>"*/"</code>,
written with the appropriate escapes).
However, because the '<code>.*</code>' expands as far as it can,
the first <code>"/*"</code> in the program would close only
with the last <code>"*/"</code>:
<pre>
    test = "int x; /* x */  int y; /* y */"
    print(string.gsub(test, "/%*.*%*/", "&lt;COMMENT>"))
      --> int x; &lt;COMMENT>
</pre>
The pattern '<code>.-</code>', instead,
will expand the least amount necessary to find the first <code>"*/"</code>,
so that you get your desired result:
<pre>
    test = "int x; /* x */  int y; /* y */"
    print(string.gsub(test, "/%*.-%*/", "&lt;COMMENT>"))
        --> int x; &lt;COMMENT>  int y; &lt;COMMENT>
</pre>

<p>The last modifier, `<code>?</code>&acute;, matches an optional character.
As an example, suppose we want to find an integer in a text,
where the number may contain an optional sign.
The pattern '<code>[+-]?%d+</code>' does the job,
matching numerals like <code>"-12"</code>,
<code>"23"</code> and <code>"+1009"</code>.
The '<code>[+-]</code>' is a character class that matches
both a `<code>+</code>&acute; or a `<code>-</code>&acute; sign;
the following `<code>?</code>&acute; makes that sign optional.

<p>Unlike some other systems, in Lua a modifier can only be
applied to a character class;
there is no way to group patterns under a modifier.
For instance, there is no pattern that matches an optional
word (unless the word has only one letter).
Usually you can circumvent this limitation using some of the
advanced techniques that we will see later.

<p>If a pattern begins with a `<code>^</code>&acute;,
it will match only at the beginning of the subject string.
Similarly, if it ends with a `<code>$</code>&acute;,
it will match only at the end of the subject string.
These marks can be used both to restrict the patterns that you find
and to anchor patterns.
For instance, the test
<pre>
    if string.find(s, "^%d") then ...
</pre>
checks whether the string <code>s</code> starts with a digit
and the test
<pre>
    if string.find(s, "^[+-]?%d+$") then ...
</pre>
checks whether that string represents an integer number,
without other leading or trailing characters.

<p>Another item in a pattern is the '<code>%b</code>',
that matches balanced strings.
Such item is written as '<code>%b<em>xy</em></code>',
where <em>x</em> and <em>y</em> are any two distinct characters;
the <em>x</em> acts as an opening character
and the <em>y</em> as the closing one.
For instance, the pattern '<code>%b()</code>' matches
parts of the string that start with a
`<code>(</code>&acute; and finish at the respective `<code>)</code>&acute;:
<pre>
    print(string.gsub("a (enclosed (in) parentheses) line",
                      "%b()", ""))
      --> a  line
</pre>
Typically, this pattern is used as
'<code>%b()</code>', '<code>%b[]</code>', '<code>%b%{%}</code>', or '<code>%b&lt;></code>',
but you can use any characters as delimiters.

<hr>
<table width="100%" class="nav">
<tr>
<td width="90%" align="left">
<small>
  Copyright &copy; 2003&ndash;2004 Roberto Ierusalimschy.  All rights reserved.
</small>
</td>

</tr>
</table>

<h2>20.3 Captures (and Manual p.42)</h2>

"A pattern can contain sub-patterns enclosed in parentheses; they describe <i>captures</i>. When a match succeeds, the substrings of the subject string that match captures are stored (captured) for future use. Captures are numbered according to their left parentheses. For instance, in the pattern <code>"(a*(.)%w(%s*))"</code>, the part of the string matchin <code>"a*(.)%w(%s*)"</code> is stored as the first capture (and therefore has number 1); the character matching <code>"."</code> is captured with number 2, and the part matching <code>"%s*"</code> has number 3. As a special case, the empty capture <code>"()"</code> captures the current string position (a number). For instance, if we apply the pattern <code>"()aa()"</code> on the string <code>"flaaap"</code>, there will be two captures: 3 and 5." (Manual p. 42)




</body></html> ]====],
["rawequal"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>rawequal() function</h1>

This function is only for IT professionals to check whether two arguments are equal without invoking any metamehod. Metamehods are only for IT professionals.

</body></html> ]====],
["lines"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>io.lines() function </h1>

This function is useful to read files line by line:

<br>
<pre>
for line in io.lines("C:\\Temp\\test.txt") do
    print(line)
end --for line in io.lines("C:\\Temp\\test.txt") do
</pre>

The standard libraries provide several iterators, which allow us to iterate over the lines of a file (io.lines).

</body></html> ]====],
["asin"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.asin() function</h1>

This is the arc sinus function in Lua. It gives the inverse sinus function result of a value between -1 and 1. Other intervals have an indefinit result.
<pre>
> a=-1
> print(math.asin(a))
-1.5707963267949
> print(math.deg(math.asin(a)))
-90.0
> a=1
> print(math.asin(a))
1.5707963267949
> a=-2
> print(math.asin(a))
-1.#IND
</pre>

With <code>math.deg</code> the radiant is converted into degrees.

</body></html> ]====],
["random"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.random() function</h1>

This is the pseudo-random function in Lua. This function gives the result of the rand-function in C. There is no guarantee for its statistical properties.

When called without arguments, it returns a uniform pseudo-random real number in the range [0,1). When called with an integer number m, math.random returns a uniform pseudo-random integer in the range [1,m]. When called with two integer numbers m and n, math.random returns a uniform pseudo-random integer in the rangge [m,n].

<pre>
> print(math.random())
0.1495377166182
> print(math.random())
0.61705942729729
> print(math.random())
0.69934228450804

> print(math.random(6))
1
> print(math.random(6))
3
> print(math.random(6))
5
> print(math.random(6))
6
> print(math.random(6))
4
> print(math.random(6))
3
> print(math.random(6))
6
> print(math.random(6))
5
> print(math.random(6))
6
> print(math.random(6))
6
> print(math.random(6))
6
> print(math.random(6))
6
> print(math.random(6))
6
> print(math.random(6))
1
> print(math.random(6))
4
> print(math.random(6))
6
> print(math.random(6))
3
> print(math.random(6))
5
> print(math.random(6))
1
> print(math.random(6))
6
> print(math.random(6))
6
> print(math.random(6))
6


> print(math.random(1,100))
61
> print(math.random(1,100))
18
> print(math.random(1,100))
11
> print(math.random(1,100))
10
> print(math.random(1,100))
20
> print(math.random(1,100))
11
> print(math.random(1,100))
94
> print(math.random(1,100))
84
> print(math.random(1,100))
79
> print(math.random(1,100))
71

</pre>

</body></html> 

 ]====],
["debug"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>debug table or debug.debug() function</h1>

This table is only useful for advanced programming.

debug.debug() is a function but only for IT professionals.

</body></html> ]====],
["select"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>select() function</h1>

This function  selects all arguments beginning with the number in the first argument.


<pre>

> print(string.find("Hallo","ll"))
3       4
> print(select(1,string.find("Hallo","ll")))
3       4
> print(select(2,string.find("Hallo","ll")))
4
> a=select(1,string.find("Hallo","ll"))
> print(a)
3

</pre>

</body></html> ]====],
["date"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>os.date() function</h1>

The os.date function gives the system date in variaus formats. Used without arguments it is a standard formt. Used with a text format with special characters in a string it returns the date with the day and hour in this string. Used with the argument *t it returns a table with elements

<pre>
> print(os.date())
Mon Feb 28 09:48:44 2022
> print(os.date("*t"))
table: 000000A5AE496810

>  temp = os.date("*t", 906000490)
> print(temp.year)
1998
> print(temp.month)
9
> print(temp.day)
17
> print(temp.yday)
260
> print(temp.wday)
5
> print(temp.hour)
4
> print(temp.min)
48
> print(temp.sec)
10
> print(temp.isdst)
true

</pre>


<hr>
<h2>22.1 &ndash; Date and Time (Source: Programming in Lua : 22.1)</h2>

<p>Two functions, <code>time</code> and <code>date</code>,
do all date and time queries in Lua.

<p>The <code>time</code> function,
when called without arguments,
returns the current date and time,
coded as a number.
(In most systems,
that number is the number of seconds since some epoch.)
When called with a table,
it returns the number representing the
date and time described by the table.
Such <em>date tables</em> have the following significant fields:
<table align="center" border=1>
<tr><td><code>year</code></td><td>a full year</td></tr>
<tr><td><code>month</code></td><td>01-12</td></tr>
<tr><td><code>day</code></td><td>01-31</td></tr>
<tr><td><code>hour</code></td><td>00-23</td></tr>
<tr><td><code>min</code></td><td>00-59</td></tr>
<tr><td><code>sec</code></td><td>00-59</td></tr>
<tr><td><code>isdst</code></td><td>a boolean, <B>true</B> if daylight saving</td></tr>
</table>

<p>The first three fields are mandatory;
the others default to noon (12:00:00) when not provided.

In a Unix system (where the epoch is 00:00:00 UTC, January 1, 1970)
running in Rio de Janeiro (which is three hours west of Greenwich),
we have the following examples:
<pre>
    -- obs: 10800 = 3*60*60 (3 hours)
    print(os.time{year=1970, month=1, day=1, hour=0})
      --> 10800
    print(os.time{year=1970, month=1, day=1, hour=0, sec=1})
      --> 10801
    print(os.time{year=1970, month=1, day=1})
      --> 54000   (obs: 54000 = 10800 + 12*60*60)
</pre>

<p>The <code>date</code> function, despite its name,
is a kind of a reverse of the <code>time</code> function:
It converts a number representing the date and time
back to some higher-level representation.
Its first parameter is a <em>format string</em>,
describing the representation we want.
The second is the numeric date-time;
it defaults to the current date and time.

<p>To produce a date table,
we use the format string <code>"*t"</code>.
For instance, the following code
<pre>
    temp = os.date("*t", 906000490)
</pre>
produces the table
<pre>
    {year = 1998, month = 9, day = 16, yday = 259, wday = 4,
     hour = 23, min = 48, sec = 10, isdst = false}
</pre>
Notice that, besides the fields used by <code>os.time</code>,
the table created by <code>os.date</code> also gives the week day
(<code>wday</code>, 1 is Sunday)
and the year day (<code>yday</code>, 1 is January 1).

<p>For other format strings, <code>os.date</code> formats the date as a string,
which is a copy of the format string where specific tags are
replaced by information about time and date.
All tags are represented by a `<code>%</code>&acute; followed by a letter,
as in the next examples:
<pre>
    print(os.date("today is %A, in %B"))
      --> today is Tuesday, in May
    print(os.date("%x", 906000490))
      --> 09/16/1998
</pre>
All representations follow the current locale.
Therefore, in a locale for Brazil-Portuguese,
<code>%B</code> would result in <code>"setembro"</code>
and <code>%x</code> in <code>"16/09/98"</code>.

<p>The following table shows each tag, its meaning,
and its value for September 16, 1998 (a Wednesday),
at 23:48:10.
For numeric values, the table shows also their range of possible values:
<table align="center" border=1>
<tr><td><code>%a</code></td><td>abbreviated weekday name (e.g., <code>Wed</code>)</td></tr>
<tr><td><code>%A</code></td><td>full weekday name (e.g., <code>Wednesday</code>)</td></tr>
<tr><td><code>%b</code></td><td>abbreviated month name (e.g., <code>Sep</code>)</td></tr>
<tr><td><code>%B</code></td><td>full month name (e.g., <code>September</code>)</td></tr>
<tr><td><code>%c</code></td><td>date and time (e.g., <code>09/16/98 23:48:10</code>)</td></tr>
<tr><td><code>%d</code></td><td>day of the month (<code>16</code>) [01-31]</td></tr>
<tr><td><code>%H</code></td><td>hour, using a 24-hour clock (<code>23</code>) [00-23]</td></tr>
<tr><td><code>%I</code></td><td>hour, using a 12-hour clock (<code>11</code>) [01-12]</td></tr>
<tr><td><code>%M</code></td><td>minute (<code>48</code>) [00-59]</td></tr>
<tr><td><code>%m</code></td><td>month (<code>09</code>) [01-12]</td></tr>
<tr><td><code>%p</code></td><td>either <code>"am"</code> or <code>"pm"</code> (<code>pm</code>)</td></tr>
<tr><td><code>%S</code></td><td>second (<code>10</code>) [00-61]</td></tr>
<tr><td><code>%w</code></td><td>weekday (<code>3</code>) [0-6 = Sunday-Saturday]</td></tr>
<tr><td><code>%x</code></td><td>date (e.g., <code>09/16/98</code>)</td></tr>
<tr><td><code>%X</code></td><td>time (e.g., <code>23:48:10</code>)</td></tr>
<tr><td><code>%Y</code></td><td>full year (<code>1998</code>)</td></tr>
<tr><td><code>%y</code></td><td>two-digit year (<code>98</code>)  [00-99]</td></tr>
<tr><td><code>%%</code></td><td>the character `<code>%</code>&acute;</td></tr>
</table>

<p>If you call <code>date</code> without any arguments,
it uses the <code>%c</code> format, that is,
complete date and time information in a reasonable format.
Note that the representations for <code>%x</code>,
<code>%X</code>, and <code>%c</code> change according to the locale and the system.
If you want a fixed representation,
such as <code>mm/dd/yyyy</code>,
use an explicit format string, such as <code>"%m/%d/%Y"</code>.

<p>The <code>os.clock</code> function returns the number of seconds of
CPU time for the program.
Its typical use is to benchmark a piece of code:
<pre>
    local x = os.clock()
    local s = 0
    for i=1,100000 do s = s + i end
    print(string.format("elapsed time: %.2f\n", os.clock() - x))
</pre>

<hr>
<table width="100%" class="nav">
<tr>
<td width="90%" align="left">
<small>
  Copyright &copy; 2003&ndash;2004 Roberto Ierusalimschy.  All rights reserved.
</small>
</td>

</tr>
</table>


</body></html>


]====],
["sort"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>table.sort() function</h1>

This function sorts in a Lua table the elements with keys which are indices, i.e. from 1 to n in a sequence. Other keys remain unsorted. It is not possible to sort numbers and strings without defining the rules. The standard sort is to have all upper cases first then lower cases.

<br>

The rule sorting rules are defined by an anonymous function as a second argument.

<br>

"The sort algorithm is not stable; that is, elements considered equal by the given order may have their relative positions changed by the sort." (Manual p. 43)

<pre>

> aTable={123,345,"text"}
> table.sort(aTable)
attempt to compare string with number
stack traceback:
        [C]: in function 'table.sort'
        stdin:1: in main chunk
        [C]: in ?
> table.sort(aTable,function(a,b) return tostring(a)<tostring(b) end)
> for i,v in pairs(aTable) do print(i,v) end
1       123
2       345
3       text
> bTable={"nur","Text","in","einer","Lua-Tabelle"}
> table.sort(bTable)
> for i,v in pairs(bTable) do print(i,v) end
1       Lua-Tabelle
2       Text
3       einer
4       in
5       nur
> cTable={"eine","Tabelle","mit",index="Indizes",die="sortiert",werden="werden"}

> table.sort(bTable)
> table.sort(cTable)
> for i,v in pairs(cTable) do print(i,v) end
1       Tabelle
2       eine
3       mit
index   Indizes
werden  werden
die     sortiert
> cTable={"eine","Tabelle","mit",index="indizes",die="unsortiert",werden="werden
"}
> table.sort(cTable)
> for i,v in pairs(cTable) do print(i,v) end
1       Tabelle
2       eine
3       mit
index   indizes
werden  werden
die     unsortiert

</pre>

<hr>
<h2>19.3 &ndash; Sort</h2>

<p>Another useful function on arrays is <code>table.sort</code>,
which we have seen before.
It receives the array to be sorted,
plus an optional order function.
This order function receives two arguments and must return true if
the first argument should come first in the sorted array.
If this function is not provided,
<code>sort</code> uses the default less-than operation
(corresponding to the `<code>&lt;</code>&acute; operator).

<p>A common mistake is to try to order the indices of a table.
In a table, the indices form a set, and have no order whatsoever.
If you want to order them, you have to copy them to an array
and then sort the array.
Let us see an example.
Suppose that you read a source file
and build a table that gives, for each function name,
the line where that function is defined;
something like this:
<pre>
    lines = {
      luaH_set = 10,
      luaH_get = 24,
      luaH_present = 48,
    }
</pre>
Now you want to print these function names in alphabetical order.
If you traverse this table with <code>pairs</code>,
the names appear in an arbitrary order.
However, you cannot sort them directly,
because these names are keys of the table.
However, when you put these names into an array,
then you can sort them.
First, you must create an array with those names, then sort it,
and finally print the result:
<pre>
    a = {}
    for n in pairs(lines) do table.insert(a, n) end
    table.sort(a)
    for i,n in ipairs(a) do print(n) end
</pre>

<p>Note that, for Lua, arrays also have no order.
But we know how to count, so we get ordered values
as long as we access the array with ordered indices.
That is why you should always traverse arrays
with <code>ipairs</code>, rather than <code>pairs</code>.
The first imposes the key order 1, 2, ...,
whereas the latter uses the natural arbitrary order of the table.

<p>As a more advanced solution,
we can write an iterator that traverses a table
following the order of its keys.
An optional parameter <code>f</code> allows the specification of an
alternative order.
It first sorts the keys into an array,
and then iterates on the array.
At each step, it returns the key and value from the original table:
<pre>
    function pairsByKeys (t, f)
      local a = {}
      for n in pairs(t) do table.insert(a, n) end
      table.sort(a, f)
      local i = 0      -- iterator variable
      local iter = function ()   -- iterator function
        i = i + 1
        if a[i] == nil then return nil
        else return a[i], t[a[i]]
        end
      end
      return iter
    end
</pre>
With this function, it is easy to print those function names in
alphabetical order.
The loop
<pre>
    for name, line in pairsByKeys(lines) do
      print(name, line)
    end
</pre>
will print
<pre>
    luaH_get        24
    luaH_present    48
    luaH_set        10
</pre>

<hr>
<table width="100%" class="nav">
<tr>
<td width="90%" align="left">
<small>
  Copyright &copy; 2003&ndash;2004 Roberto Ierusalimschy.  All rights reserved.
</small>
</td>

</tr>
</table>



<hr>
<h1><a name="StringLib">20 &ndash; The String Library</a></h1>

<p>The power of a raw Lua interpreter to manipulate strings is quite limited.
A program can create string literals and concatenate them.
But it cannot extract a substring, check its size,
or examine its contents.
The full power to manipulate strings in Lua
comes from its string library.

<p>Some functions in the string library are quite simple:
<code>string.len(s)</code>
returns the length of a string <code>s</code>.
<code>string.rep(s, n)</code>
returns the string <code>s</code> repeated <code>n</code> times.
You can create a string with 1M bytes (for tests, for instance)
with <code>string.rep("a", 2^20)</code>.
<code>string.lower(s)</code>
returns a copy of <code>s</code> with the
upper-case letters converted to lower case;
all other characters in the string are not changed
(<code>string.upper</code> converts to upper case).
As a typical use, if you want to sort an
array of strings regardless of case,
you may write something like
<pre>
    table.sort(a, function (a, b)
      return string.lower(a) &lt; string.lower(b)
    end)
</pre>



<hr>
<h2>21.1 &ndash; The Simple I/O Model</h2>



However, to iterate on a whole file line by line,
we do better to use the <code>io.lines</code> iterator.
For instance,
we can write a complete program to sort the lines of a file as follows:
<pre>
    local lines = {}
    -- read the lines in table 'lines'
    for line in io.lines() do
      table.insert(lines, line)
    end
    -- sort
    table.sort(lines)
    -- write all the lines
    for i, l in ipairs(lines) do io.write(l, "\n") end
</pre>
This program sorts a file with 4.5 MB (32K lines)
in 1.8 seconds (on a Pentium 333MHz),
against 0.6 seconds spent by the system <code>sort</code> program,
which is written in C and highly optimized.




<hr>
<h1><a name="firstclass">6 &ndash; More about Functions</a></h1>

<p>Functions in Lua are first-class values
with proper lexical scoping.

<p>What does it mean for functions to be "first-class values"?
It means that, in Lua, a function is a value
with the same rights as conventional values like
numbers and strings.
Functions can be stored in variables (both global and local) and
in tables, can be passed as arguments,
and can be returned by other functions.

<p>What does it mean for functions to have "lexical scoping"?
It means that functions can access variables of its enclosing functions.
(It also means that Lua contains the lambda calculus properly.)
As we will see in this chapter,
this apparently innocuous property brings great power to the language,
because it allows us to apply in Lua
many powerful programming techniques
from the functional-language world.
Even if you have no interest at all in functional programming,
it is worth learning a
little about how to explore those techniques,
because they can make your programs smaller and simpler.

<p>A somewhat difficult notion in Lua is that functions,
like all other values, are anonymous;
they do not have names.
When we talk about a function name, say <code>print</code>,
we are actually talking about a variable that holds that function.
Like any other variable holding any other value,
we can manipulate such variables in many ways.
The following example, although a little silly,
shows the point:
<pre>
    a = {p = print}
    a.p("Hello World") --> Hello World
    print = math.sin  -- `print' now refers to the sine function
    a.p(print(1))     --> 0.841470
    sin = a.p         -- `sin' now refers to the print function
    sin(10, 20)       --> 10      20
</pre>
Later we will see more useful applications for this facility.

<p>If functions are values,
are there any expressions that create functions?
Yes.
In fact, the usual way to write a function in Lua,
like
<pre>
    function foo (x) return 2*x end
</pre>
is just an instance of what we call <em>syntactic sugar</em>;
in other words, it is just a pretty way to write
<pre>
    foo = function (x) return 2*x end
</pre>
That is, a function definition is in fact a statement
(an assignment, more specifically)
that assigns a value of type <code>"function"</code> to a variable.
We can see the expression <code>function (x) ... end</code>
as a function constructor,
just as <code>{}</code> is a table constructor.
We call the result of such function constructors an
<em>anonymous function</em>.
Although we usually assign functions to global names,
giving them something like a name,
there are several occasions when functions remain anonymous.
Let us see some examples.

<p>The table library provides a function <code>table.sort</code>,
which receives a table and sorts its elements.
Such a function must allow unlimited variations in the sort order:
ascending or descending, numeric or alphabetical,
tables sorted by a key, and so on.
Instead of trying to provide all kinds of options,
<code>sort</code> provides a single optional parameter,
which is the <em>order function</em>:
a function that receives two elements
and returns whether the first must come before
the second in the sort.
For instance, suppose we have a table of records such as
<pre>
     network = {
       {name = "grauna",  IP = "210.26.30.34"},
       {name = "arraial", IP = "210.26.30.23"},
       {name = "lua",     IP = "210.26.23.12"},
       {name = "derain",  IP = "210.26.23.20"},
     }
</pre>
If we want to sort the table by the field <code>name</code>,
in reverse alphabetical order,
we just write
<pre>
    table.sort(network, function (a,b)
      return (a.name > b.name)
    end)
</pre>
See how handy the anonymous function is in that statement.

<p>A function that gets another function as an argument,
such as <code>sort</code>,
is what we call a <em>higher-order function</em>.
Higher-order functions are a powerful programming mechanism
and the use of anonymous functions
to create their function arguments is a great source of flexibility.
But remember that
higher-order functions have no special rights;
they are a simple consequence of the ability of Lua to handle
functions as first-class values.




<hr>
<h2><a name="closures">6.1 &ndash; Closures</a></h2>

<p>When a function is written enclosed in another function,
it has full access to local variables from the enclosing function;
this feature is called <em>lexical scoping</em>.
Although that may sound obvious, it is not.
Lexical scoping, plus first-class functions,
is a powerful concept in a programming language,
but few languages support that concept.

<p>Let us start with a simple example.
Suppose you have a list of student names
and a table that associates names to grades;
you want to sort the list of names,
according to their grades (higher grades first).
You can do this task as follows:

<pre>
    names = {"Peter", "Paul", "Mary"}
    grades = {Mary = 10, Paul = 7, Peter = 8}
    table.sort(names, function (n1, n2)
      return grades[n1] > grades[n2]    -- compare the grades
    end)
</pre>
Now, suppose you want to create a function to do this task:
<pre>
    function sortbygrade (names, grades)
      table.sort(names, function (n1, n2)
        return grades[n1] > grades[n2]    -- compare the grades
      end)
    end
</pre>
The interesting point in the example is that
the anonymous function given to <code>sort</code>
accesses the parameter <code>grades</code>,
which is local to the enclosing function <code>sortbygrade</code>.
Inside this anonymous function,
<code>grades</code> is neither a global variable nor a local variable.
We call it an <em>external local variable</em>,
or an <em>upvalue</em>.
(The term "upvalue" is a little misleading,
because <code>grades</code> is a variable, not a value.
However, this term has historical roots in Lua
and it is shorter than "external local variable".)





</body></html> ]====],
["_"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>_</h1>

You should avoid identifiers starting with an underscore followed by one or more uppercase letters (e.g., _VERSION); they are reserved for special uses in Lua. Usually, I reserve the identifier _ (a single underscore) for a dummy variable. 

</body></html> ]====],
["difftime"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>os.difftime() function</h1>

This function returns the difference of two times as numbers. In POSIX, Windows and some other systems, this value is exacty the same result as with second time - first time.

<pre>
>  temp = os.date("*t", 906000490)
> print(os.difftime(os.time(),os.time(temp)),os.time()-os.time(temp))
740047832.0     740047832

</pre>

</body></html> ]====],
["exit"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>os.exit() function</h1>

This function is used to exit an interactive mode of Lua or a script. The <code>os.exit</code> function terminates the execution of a program.

To exit the interactive mode and the interpreter,
just type <em>end-of-file</em>
(<code>ctrl-D</code> in Unix, <code>ctrl-Z</code> in DOS/Windows),
or call the <code>exit</code> function,
from the Operating System library
(you have to type <code>os.exit()&lt;enter></code>).

<pre>
> os.exit()

</pre>


</body></html> ]====],
["move"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>table.move() function</h1>

This function is only for IT professionals. It moves elements of a table as first argument from an intervall as second and third argument to a position as fourth argument in this table or in another table as optional fifth argument.



</body></html> ]====],
["time"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>os.time() function</h1>


The <code>os.time</code> function returns a number that
represents the current time,
usually as the number of seconds since some epoch.

<pre>
> print(os.time())
1646066367
</pre>

With the table elements as argument you can build time of a date in the past or in the future in the given range of the installation. With month, day, hour, minutes and seconds not in the natural interval you can calculate a date, for instance is day=0 the last day of the previous month. This is especially useful for the las of february.

<pre>
> print(os.time{year=2010, month=1, day=1, hour=0})
1262300400
> print(os.time{year=2010, month=1, day=-121, hour=0})
1251756000
> print(os.time{year=2010, month=16, day=1, hour=0})
1301608800

> print(os.date("%d.%m.%Y",os.time{year=2010, month=3, day=0, hour=0}))
28.02.2010
> print(os.date("%d.%m.%Y",os.time{year=2012, month=3, day=0, hour=0}))
29.02.2012


</pre>



<br><br>
You can set a seed for the pseudo-random generator with the
<code>randomseed</code> function;
its only numeric argument is the seed.
Usually, when a program starts,
it initializes the generator with a fixed seed.
That means that, every time you run your program,
it generates the same sequence of pseudo-random numbers.
For debugging, that is a nice property;
but in a game, you will have the same scenario over and over.
A common trick to solve this problem is to use the current time
as a seed:

<pre>
 math.randomseed(os.time())
</pre>

<hr>
<h2>22.1 &ndash; Date and Time (Source: Programming in Lua : 22.1)</h2>

<p>Two functions, <code>time</code> and <code>date</code>,
do all date and time queries in Lua.

<p>The <code>time</code> function,
when called without arguments,
returns the current date and time,
coded as a number.
(In most systems,
that number is the number of seconds since some epoch.)
When called with a table,
it returns the number representing the
date and time described by the table.
Such <em>date tables</em> have the following significant fields:
<table align="center" border=1>
<tr><td><code>year</code></td><td>a full year</td></tr>
<tr><td><code>month</code></td><td>01-12</td></tr>
<tr><td><code>day</code></td><td>01-31</td></tr>
<tr><td><code>hour</code></td><td>00-23</td></tr>
<tr><td><code>min</code></td><td>00-59</td></tr>
<tr><td><code>sec</code></td><td>00-59</td></tr>
<tr><td><code>isdst</code></td><td>a boolean, <B>true</B> if daylight saving</td></tr>
</table>

<p>The first three fields are mandatory;
the others default to noon (12:00:00) when not provided.

In a Unix system (where the epoch is 00:00:00 UTC, January 1, 1970)
running in Rio de Janeiro (which is three hours west of Greenwich),
we have the following examples:
<pre>
    -- obs: 10800 = 3*60*60 (3 hours)
    print(os.time{year=1970, month=1, day=1, hour=0})
      --> 10800
    print(os.time{year=1970, month=1, day=1, hour=0, sec=1})
      --> 10801
    print(os.time{year=1970, month=1, day=1})
      --> 54000   (obs: 54000 = 10800 + 12*60*60)
</pre>

<p>The <code>date</code> function, despite its name,
is a kind of a reverse of the <code>time</code> function:
It converts a number representing the date and time
back to some higher-level representation.
Its first parameter is a <em>format string</em>,
describing the representation we want.
The second is the numeric date-time;
it defaults to the current date and time.

<p>To produce a date table,
we use the format string <code>"*t"</code>.
For instance, the following code
<pre>
    temp = os.date("*t", 906000490)
</pre>
produces the table
<pre>
    {year = 1998, month = 9, day = 16, yday = 259, wday = 4,
     hour = 23, min = 48, sec = 10, isdst = false}
</pre>
Notice that, besides the fields used by <code>os.time</code>,
the table created by <code>os.date</code> also gives the week day
(<code>wday</code>, 1 is Sunday)
and the year day (<code>yday</code>, 1 is January 1).

<p>For other format strings, <code>os.date</code> formats the date as a string,
which is a copy of the format string where specific tags are
replaced by information about time and date.
All tags are represented by a `<code>%</code>&acute; followed by a letter,
as in the next examples:
<pre>
    print(os.date("today is %A, in %B"))
      --> today is Tuesday, in May
    print(os.date("%x", 906000490))
      --> 09/16/1998
</pre>
All representations follow the current locale.
Therefore, in a locale for Brazil-Portuguese,
<code>%B</code> would result in <code>"setembro"</code>
and <code>%x</code> in <code>"16/09/98"</code>.

<p>The following table shows each tag, its meaning,
and its value for September 16, 1998 (a Wednesday),
at 23:48:10.
For numeric values, the table shows also their range of possible values:
<table align="center" border=1>
<tr><td><code>%a</code></td><td>abbreviated weekday name (e.g., <code>Wed</code>)</td></tr>
<tr><td><code>%A</code></td><td>full weekday name (e.g., <code>Wednesday</code>)</td></tr>
<tr><td><code>%b</code></td><td>abbreviated month name (e.g., <code>Sep</code>)</td></tr>
<tr><td><code>%B</code></td><td>full month name (e.g., <code>September</code>)</td></tr>
<tr><td><code>%c</code></td><td>date and time (e.g., <code>09/16/98 23:48:10</code>)</td></tr>
<tr><td><code>%d</code></td><td>day of the month (<code>16</code>) [01-31]</td></tr>
<tr><td><code>%H</code></td><td>hour, using a 24-hour clock (<code>23</code>) [00-23]</td></tr>
<tr><td><code>%I</code></td><td>hour, using a 12-hour clock (<code>11</code>) [01-12]</td></tr>
<tr><td><code>%M</code></td><td>minute (<code>48</code>) [00-59]</td></tr>
<tr><td><code>%m</code></td><td>month (<code>09</code>) [01-12]</td></tr>
<tr><td><code>%p</code></td><td>either <code>"am"</code> or <code>"pm"</code> (<code>pm</code>)</td></tr>
<tr><td><code>%S</code></td><td>second (<code>10</code>) [00-61]</td></tr>
<tr><td><code>%w</code></td><td>weekday (<code>3</code>) [0-6 = Sunday-Saturday]</td></tr>
<tr><td><code>%x</code></td><td>date (e.g., <code>09/16/98</code>)</td></tr>
<tr><td><code>%X</code></td><td>time (e.g., <code>23:48:10</code>)</td></tr>
<tr><td><code>%Y</code></td><td>full year (<code>1998</code>)</td></tr>
<tr><td><code>%y</code></td><td>two-digit year (<code>98</code>)  [00-99]</td></tr>
<tr><td><code>%%</code></td><td>the character `<code>%</code>&acute;</td></tr>
</table>

<p>If you call <code>date</code> without any arguments,
it uses the <code>%c</code> format, that is,
complete date and time information in a reasonable format.
Note that the representations for <code>%x</code>,
<code>%X</code>, and <code>%c</code> change according to the locale and the system.
If you want a fixed representation,
such as <code>mm/dd/yyyy</code>,
use an explicit format string, such as <code>"%m/%d/%Y"</code>.

<p>The <code>os.clock</code> function returns the number of seconds of
CPU time for the program.
Its typical use is to benchmark a piece of code:
<pre>
    local x = os.clock()
    local s = 0
    for i=1,100000 do s = s + i end
    print(string.format("elapsed time: %.2f\n", os.clock() - x))
</pre>

<hr>
<table width="100%" class="nav">
<tr>
<td width="90%" align="left">
<small>
  Copyright &copy; 2003&ndash;2004 Roberto Ierusalimschy.  All rights reserved.
</small>
</td>
<td width="10%" align="right"><a href="22.2.html"><img src="right.png" alt="Next"></a></td>
</tr>
</table>



</body></html> ]====],
["upper"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>string.upper() function</h1>

This function "receives a string and returns a copy of this string with all lowercase letters changed to uppercase. All other characters are left unchanged. The definition of what an lowercase letter is depends on the current locale." (Manual p. 41)

<pre>

> print(string.upper("Das ist ein Text mit Ma�nahmen."))
DAS IST EIN TEXT MIT MA�NAHMEN.

</pre>


</body></html> ]====],
["collectgarbage"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>collectgarbage() function</h1>

This function cleans the memory of the Lua session. Normally Lua does the work and you do not need it.
<br>
The use is.
<br>

<pre> collectgarbage() </pre>

</body></html> ]====],
["log10"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.log10() function</h1>

This is the log function with base 10 in Lua. This function is the logarithm of the base 10.
<pre>
> print(math.log10(3))
0.47712125471966
> print(math.log10(-5))
-nan(ind)
> print(math.log10(10))
1.0
> print(math.log10(3.26))
0.51321760006794
> print(math.log10(0))
-inf

</pre>

</body></html> 

]====],
["error"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>error() function</h1>

This function ist normally not useful for not IT professionals, but is described nevertheless because of its simplicity.

The error function can be used to display a user defined error message, for instance:
<br>
<pre>
> if a==0 then print("a") else error("soso") end
stdin:1: soso
stack traceback:
        [C]: in function 'error'
        stdin:1: in main chunk
        [C]: in ?
> a=0
> if a==0 then print("a") else error("soso") end
a
</pre>

</body></html> ]====],
["atan"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.atan() function</h1>

This is the arc tan function in Lua. It gives the inverse tan function.
<pre>
> a=-100
> print(math.atan(a))
-1.5607966601082
> print(math.deg(math.atan(a)))
-89.427061302317
> a=12
> print(math.atan(a))
1.4876550949065
> a=-2
> print(math.atan(a))
-1.1071487177941
</pre>

With <code>math.deg</code> the radiant is converted into degrees.

</body></html> ]====],
["sinh"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.sinh() function</h1>

This is the hyperbolic sine function in Lua.
<pre>
>  a=-10.23
> print(math.sinh(a))
-13861.255015992
>  a=12.2332
> print(math.sin(a))
-0.32704093004026


</pre>

</body></html> ]====],
["tmpname"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>os.tmpname() function</h1>

This function returns a temporary filename that can be used in a Lua script. This file can be used to store temporary information. Normally it should be for IT professionals and other programmers can use a normal file name and delete the file at the end of the process.

<pre>
> print(os.tmpname())
C:\Users\xxx-username\AppData\Local\Temp\s4jg.0

</pre>

</body></html> ]====],
["max"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.max() function</h1>

This is the maximum function in Lua. This function gives the maximum value among its arguments.
<pre>
> print(math.max(1,2))
2
> print(math.max(1,2,23,2,42,3,234,234,3))
234

</pre>

</body></html> 

 ]====],
["pcall"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>pcall() function</h1>

This function calls an input function in its first argument with the input function arguments in its second, third and so on arguments. The input function is called in protected mode. "This means that any error inside <code> f </code> is not propagated; instead, <code> pcall </code> catches the error and returns a status code. Its first result is the status code (a boolean), which is true if the call succeeds without errors. in such case, <code> pcall</code> also returns all results from the call, after this first result. In case of any error, <code> pcall</code> returns <code>false</code> plus the error message." (Manual page 37.)

<pre>

> pcall(function () print("soso") end)
soso
true

> a=function() print("sowas") end
> pcall(a)
sowas
true

> a=function(b) print("sowas" .. b) end
> pcall(a,"soso")
sowassoso
true

> result1,errormessage=pcall(a,"soso")
sowassoso
> print(result1,,errormessage)
true    nil

> result1,errormessage=pcall(a,nil)
> print(result1,errormessage)
false   stdin:1: attempt to concatenate a nil value (local 'b')



</pre>


</body></html> ]====],
["pi"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.pi constant</h1>

This is the constant pi in Lua.
<pre>
> print(math.pi)
3.1415926535898

</pre>

</body></html> 
]====],
["setmetatable"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>setmetatable() function</h1>

This function is for IT professionals. It sets or removes the metatable to a given table that changes the propriarities of the table. 

</body></html> ]====],
["cpath"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>package.cpath variable</h1>

This variable is only for IT professionals.


</body></html> ]====],
["utf8"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>utf8 table</h1>

This table contains functions for the treatment of utf8 and is only for IT professionals.

</body></html> ]====],
["getenv"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>os.getenv() function</h1>

The getenv function returns the value of the process environment variable or <code> nil </code> if the variable is not defined.

<pre>

> os.getenv("COMPUTERNAME")
PC-NAME
> os.getenv("USERNAME")
xyz-username
> os.getenv("USERPROFILE")
C:\Users\xyz-username
> os.getenv("PUBLIC")
C:\Users\Public
> os.getenv("HOMEDRIVE")
C:
> os.getenv("HOMEPATH")
\Users\xyz-username
> os.getenv("SystemDrive")
C:
> os.getenv("SystemRoot")
C:\Windows
> os.getenv("windir")
C:\Windows
> os.getenv("LUA_DEV")
C:\Program Files (x86)\Lua\5.1
> os.getenv("LUA_PATH")
;;C:\Program Files (x86)\Lua\5.1\lua\?.luac
> os.getenv("OS")
Windows_Version

</pre>

 All the process environment variable can be seen with the command <code> set </code> in the console or with os.execute('set') in the Lua console or Lua script.


<pre>


> os.execute('set')
ALLUSERSPROFILE=C:\ProgramData
APPDATA=C:\Users\xyz-username\AppData\Roaming
CommonProgramFiles=C:\Program Files\Common Files
CommonProgramFiles(x86)=C:\Program Files (x86)\Common Files
CommonProgramW6432=C:\Program Files\Common Files
COMPUTERNAME=PC-NAME
ComSpec=C:\Windows\system32\cmd.exe
DBCONFIG=C:\Adabas\sql
DBROOT=C:\Adabas
DBWORK=C:\Adabas\sql
FP_NO_HOST_CHECK=NO
HOMEDRIVE=C:
HOMEPATH=\Users\xyz-username
LOCALAPPDATA=C:\Users\xyz-username\AppData\Local
LOGONSERVER=\\PC-NAME
LUA_DEV=C:\Program Files (x86)\Lua\5.1
LUA_PATH=;;C:\Program Files (x86)\Lua\5.1\lua\?.luac
NUMBER_OF_PROCESSORS=2
OS=Windows_Version
Path=C:\ProgramData\Oracle\Java\javapath;C:\Windows\system32;C:\Windows;C:\Windo
ws\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Program Files (x
86)\ATI Technologies\ATI.ACE\Core-Static;C:\Program Files (x86)\Windows Live\Sha
red;C:\Program Files (x86)\MiKTeX 2.9\miktex\bin\;C:\Program Files (x86)\Lua\5.1
;C:\Program Files (x86)\Lua\5.1\clibs;C:\Dwimperl\perl\bin;C:\Dwimperl\perl\site
\bin;C:\Dwimperl\c\bin;C:\Users\xyz-username\AppData\Local\Programs\Python\Python38\
Scripts\;C:\Users\xyz-username\AppData\Local\Programs\Python\Python38\;C:\Program Fi
les (x86)\gretl;C:\Adabas\bin;C:\Adabas\pgm
PATHEXT=.PY;.SCM;.COM;.EXE;.BAT;.CMD;.VBS;.VBE;.JS;.JSE;.WSF;.WSH;.MSC;.wlua;.le
xe
PROCESSOR_ARCHITECTURE=AMD64
PROCESSOR_IDENTIFIER=AMD64 Family 22 Model 0 Stepping 1, AuthenticAMD
PROCESSOR_LEVEL=22
PROCESSOR_REVISION=0001
ProgramData=C:\ProgramData
ProgramFiles=C:\Program Files
ProgramFiles(x86)=C:\Program Files (x86)
ProgramW6432=C:\Program Files
PROMPT=$P$G
PSModulePath=C:\Windows\system32\WindowsPowerShell\v1.0\Modules\
PUBLIC=C:\Users\Public
SESSIONNAME=Console
SystemDrive=C:
SystemRoot=C:\Windows
TEMP=C:\Users\xyz-username\AppData\Local\Temp
TMP=C:\Users\xyz-username\AppData\Local\Temp
USERDOMAIN=pc-NAME
USERDOMAIN_ROAMINGPROFILE=pc-NAME
USERNAME=xyz-username
USERPROFILE=C:\Users\xyz-username
windir=C:\Windows
true    exit    0

</pre>


</body></html> ]====],
["gmatch"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>string.gmatch() function</h1>

This function returns an iterator over a string with all patterns or all captures from the pattern as argument.

<pre>

> s="Hello world from Lua"
> for word in s:gmatch("%a+") do print(word) end
Hello
world
from
Lua
> t={}
> s="from=world, to=Lua"
> for k,v in string.gmatch(s,"(%w+)=(%w+)") do t[k]=v end
> for k,v in pairs(t) do print(k,v) end
to      Lua
from    world
> for character in s:gmatch(".") do print(character) end
f
r
o
m
=
w
o
r
l
d
,

t
o
=
L
u
a


</pre>



<hr>
<h2>20.2 &ndash; Patterns with more explainations</h2>

<p>You can make patterns more useful with <em>character classes</em>.
A character class is an item in a pattern that can match any
character in a specific set.
For instance, the class <code>%d</code> matches any digit.
Therefore, you can search for a date in the format <code>dd/mm/yyyy</code>
with the pattern '<code>%d%d/%d%d/%d%d%d%d</code>':
<pre>
    s = "Deadline is 30/05/1999, firm"
    date = "%d%d/%d%d/%d%d%d%d"
    print(string.sub(s, string.find(s, date)))   --> 30/05/1999
</pre>
The following table lists all character classes:
<table align="center" border=1>

<tr><td><code><i>x</i></code></td><td>character <i>x</i> itself except all <i>magic characters</i> <code>( ) . % + - * ? [ ] ^ $</code> </td></tr>



<tr><td><code>.</code></td><td>all characters</td></tr>


<tr><td><code>%a</code></td><td>letters</td></tr>
<tr><td><code>%A</code></td><td>not letters</td></tr>

<tr><td><code>%c</code></td><td>control characters</td></tr>
<tr><td><code>%C</code></td><td>not control characters</td></tr>


<tr><td><code>%d</code></td><td>digits</td></tr>
<tr><td><code>%D</code></td><td>not digits</td></tr>


<tr><td><code>%g</code></td><td>printable characters except space</td></tr>
<tr><td><code>%G</code></td><td>space</td></tr>

<tr><td><code>%l</code></td><td>lower case letters</td></tr>
<tr><td><code>%L</code></td><td>not lower case letters</td></tr>


<tr><td><code>%p</code></td><td>punctuation characters</td></tr>
<tr><td><code>%P</code></td><td>not punctuation characters</td></tr>


<tr><td><code>%s</code></td><td>space characters</td></tr>
<tr><td><code>%S</code></td><td>not space characters</td></tr>

<tr><td><code>%u</code></td><td>upper case letters</td></tr>
<tr><td><code>%U</code></td><td>upper case letters</td></tr>

<tr><td><code>%w</code></td><td>alphanumeric characters</td></tr>
<tr><td><code>%W</code></td><td>not alphanumeric characters</td></tr>

<tr><td><code>%x</code></td><td>hexadecimal digits</td></tr>
<tr><td><code>%X</code></td><td>not hexadecimal digits</td></tr>

<tr><td><code>%z</code></td><td>the character with representation 0</td></tr>
<tr><td><code>%Z</code></td><td>not the character with representation 0</td></tr>

<tr><td><code>[char-set]</code></td><td>the union of all characters in char-set as shown afterwards</td></tr>
 
<tr><td><code>[^char-set]</code></td><td>the complement of char-set</td></tr>

<tr><td> </td><td><b>The definitions of letter, space, and other character groups depend on the current locale.  In particular, the class <code>[a-z]</code> may not be equivalent to <code>%l</code>.</b></td></tr>
</table><p>


An upper case version of any of those classes represents
the complement of the class.
For instance, '<code>%A</code>' represents all non-letter characters:
<pre>
    print(string.gsub("hello, up-down!", "%A", "."))
      --> hello..up.down. 4
</pre>
(The <code>4</code> is not part of the result string.
It is the second result of <code>gsub</code>,
the total number of substitutions.
Other examples that print the result of <code>gsub</code> will
omit this count.)

<p>Some characters, called <em>magic characters</em>,
have special meanings when used in a pattern.
The magic characters are
<pre>
    ( ) . % + - * ? [ ] ^ $
</pre>
The character `<code>%</code>&acute; works as an escape for those magic characters.
So, '<code>%.</code>' matches a dot; '<code>%%</code>' matches the character `<code>%</code>&acute; itself.
You can use the escape `<code>%</code>&acute; not only for the magic characters,
but also for all other non-alphanumeric characters.
When in doubt, play safe and put an escape.

<p>For Lua, patterns are regular strings.
They have no special treatment
and follow the same rules as other strings.
Only inside the functions are they interpreted as patterns
and only then does the `<code>%</code>&acute; work as an escape.
Therefore, if you need to put a quote inside a pattern,
you must use the same techniques that you
use to put a quote inside other strings;
for instance, you can escape the quote with a `<code>\</code>&acute;,
which is the escape character for Lua.

<p>A <em>char-set</em> allows you to create your own character classes,
combining different classes and single characters
between square brackets.
For instance,
the char-set '<code>[%w_]</code>' matches both alphanumeric characters
and underscores,
the char-set '<code>[01]</code>' matches binary digits,
and the char-set '<code>[%[%]]</code>' matches square brackets.
To count the number of vowels in a text,
you can write
<pre>
    _, nvow = string.gsub(text, "[AEIOUaeiou]", "")
</pre>
You can also include character ranges in a char-set,
by writing the first and the last characters of the range
separated by a hyphen.
You will seldom need this facility,
because most useful ranges are already predefined;
for instance, '<code>[0-9]</code>' is simpler when written as '<code>%d</code>',
'<code>[0-9a-fA-F]</code>' is the same as '<code>%x</code>'.
However, if you need to find an octal digit,
then you may prefer '<code>[0-7]</code>',
instead of an explicit enumeration ('<code>[01234567]</code>').
You can get the complement of a char-set by starting it with `<code>^</code>&acute;:
'<code>[^0-7]</code>' finds any character that is not an octal digit
and '<code>[^\n]</code>' matches any character different from newline.
But remember that you can negate simple
classes with its upper case version:
'<code>%S</code>' is simpler than '<code>[^%s]</code>'.

<p>Character classes follow the current locale set for Lua.
Therefore, the class '<code>[a-z]</code>' can be different from '<code>%l</code>'.
In a proper locale,
the latter form includes letters such as `<code>&ccedil;</code>&acute; and `<code>&atilde;</code>&acute;.
You should always use the latter form,
unless you have a strong reason to do otherwise:
It is simpler, more portable, and slightly more efficient.

<p>You can make patterns still more useful with modifiers for
repetitions and optional parts.
Patterns in Lua offer four modifiers:
<table align="center" border=1>
<tr><td><code>+</code></td><td>1 or more repetitions</td></tr>
<tr><td><code>*</code></td><td>0 or more repetitions</td></tr>
<tr><td><code>-</code></td><td>also 0 or more repetitions</td></tr>
<tr><td><code>?</code></td><td>optional (0 or 1 occurrence)</td></tr>
</table><p>
The `<code>+</code>&acute; modifier matches one or more
characters of the original class.
It will always get the longest sequence that matches the pattern.
For instance, the pattern '<code>%a+</code>' means one or more letters,
or a word:
<pre>
    print(string.gsub("one, and two; and three", "%a+", "word"))
      --> word, word word; word word
</pre>
The pattern '<code>%d+</code>' matches one or more digits (an integer):
<pre>
    i, j = string.find("the number 1298 is even", "%d+")
    print(i,j)   --> 12  15
</pre>

<p>The modifier `<code>*</code>&acute; is similar to `<code>+</code>&acute;,
but it also accepts zero occurrences of characters of the class.
A typical use is to match optional spaces between parts of a pattern.
For instance, to match an empty parenthesis pair,
such as <code>()</code> or <code>( )</code>,
you use the pattern '<code>%(%s*%)</code>'.
(The pattern '<code>%s*</code>' matches zero or more spaces.
Parentheses have a special meaning in a pattern,
so we must escape them with a `<code>%</code>&acute;.)
As another example, the pattern '<code>[_%a][_%w]*</code>'
matches identifiers in a Lua program:
a sequence that starts with a letter or an underscore,
followed by zero or more underscores or alphanumeric characters.

<p>Like `<code>*</code>&acute;,
the modifier `<code>-</code>&acute; also matches zero or more occurrences
of characters of the original class.
However, instead of matching the longest sequence,
it matches the shortest one.
Sometimes, there is no difference between `<code>*</code>&acute; or `<code>-</code>&acute;,
but usually they present rather different results.
For instance, if you try to find an identifier with the
pattern '<code>[_%a][_%w]-</code>',
you will find only the first letter,
because the '<code>[_%w]-</code>' will always match the empty sequence.
On the other hand,
suppose you want to find comments in a C program.
Many people would first try '<code>/%*.*%*/</code>'
(that is, a <code>"/*"</code> followed by a sequence of any
characters followed by <code>"*/"</code>,
written with the appropriate escapes).
However, because the '<code>.*</code>' expands as far as it can,
the first <code>"/*"</code> in the program would close only
with the last <code>"*/"</code>:
<pre>
    test = "int x; /* x */  int y; /* y */"
    print(string.gsub(test, "/%*.*%*/", "&lt;COMMENT>"))
      --> int x; &lt;COMMENT>
</pre>
The pattern '<code>.-</code>', instead,
will expand the least amount necessary to find the first <code>"*/"</code>,
so that you get your desired result:
<pre>
    test = "int x; /* x */  int y; /* y */"
    print(string.gsub(test, "/%*.-%*/", "&lt;COMMENT>"))
        --> int x; &lt;COMMENT>  int y; &lt;COMMENT>
</pre>

<p>The last modifier, `<code>?</code>&acute;, matches an optional character.
As an example, suppose we want to find an integer in a text,
where the number may contain an optional sign.
The pattern '<code>[+-]?%d+</code>' does the job,
matching numerals like <code>"-12"</code>,
<code>"23"</code> and <code>"+1009"</code>.
The '<code>[+-]</code>' is a character class that matches
both a `<code>+</code>&acute; or a `<code>-</code>&acute; sign;
the following `<code>?</code>&acute; makes that sign optional.

<p>Unlike some other systems, in Lua a modifier can only be
applied to a character class;
there is no way to group patterns under a modifier.
For instance, there is no pattern that matches an optional
word (unless the word has only one letter).
Usually you can circumvent this limitation using some of the
advanced techniques that we will see later.

<p>If a pattern begins with a `<code>^</code>&acute;,
it will match only at the beginning of the subject string.
Similarly, if it ends with a `<code>$</code>&acute;,
it will match only at the end of the subject string.
These marks can be used both to restrict the patterns that you find
and to anchor patterns.
For instance, the test
<pre>
    if string.find(s, "^%d") then ...
</pre>
checks whether the string <code>s</code> starts with a digit
and the test
<pre>
    if string.find(s, "^[+-]?%d+$") then ...
</pre>
checks whether that string represents an integer number,
without other leading or trailing characters.

<p>Another item in a pattern is the '<code>%b</code>',
that matches balanced strings.
Such item is written as '<code>%b<em>xy</em></code>',
where <em>x</em> and <em>y</em> are any two distinct characters;
the <em>x</em> acts as an opening character
and the <em>y</em> as the closing one.
For instance, the pattern '<code>%b()</code>' matches
parts of the string that start with a
`<code>(</code>&acute; and finish at the respective `<code>)</code>&acute;:
<pre>
    print(string.gsub("a (enclosed (in) parentheses) line",
                      "%b()", ""))
      --> a  line
</pre>
Typically, this pattern is used as
'<code>%b()</code>', '<code>%b[]</code>', '<code>%b%{%}</code>', or '<code>%b&lt;></code>',
but you can use any characters as delimiters.

<hr>
<table width="100%" class="nav">
<tr>
<td width="90%" align="left">
<small>
  Copyright &copy; 2003&ndash;2004 Roberto Ierusalimschy.  All rights reserved.
</small>
</td>

</tr>
</table>

<h2>20.3 Captures (and Manual p.42)</h2>

"A pattern can contain sub-patterns enclosed in parentheses; they describe <i>captures</i>. When a match succeeds, the substrings of the subject string that match captures are stored (captured) for future use. Captures are numbered according to their left parentheses. For instance, in the pattern <code>"(a*(.)%w(%s*))"</code>, the part of the string matchin <code>"a*(.)%w(%s*)"</code> is stored as the first capture (and therefore has number 1); the character matching <code>"."</code> is captured with number 2, and the part matching <code>"%s*"</code> has number 3. As a special case, the empty capture <code>"()"</code> captures the current string position (a number). For instance, if we apply the pattern <code>"()aa()"</code> on the string <code>"flaaap"</code>, there will be two captures: 3 and 5." (Manual p. 42)




</body></html> ]====],
["popen"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>io.popen() function</h1>

This function is very useful to get informations out of the system. Nevertheless it is system dependent which syntax can be implemented in the first argument.
<br>
<br>

A list of all files in C:\Temp is established and read as follows in Windows:
<br>
<pre>
p=io.popen('dir "C:\\Temp\\test*.txt" /b/o/s')
for fileText in p:lines() do print(fileText) end
</pre>
<br>
<br>

A list of all files in /home/pi/temp is established with another command in Linux:
<br>
<pre>
p=io.popen('ls /home/pi/temp/test*.txt')
for fileText in p:lines() do print(fileText) end
</pre>

<br>
<br>
The io.popen function is the same as os.execute except that the result is not displayed in the standard output but redirected to a file that can be read by io.lines function.

</body></html> ]====],
["ceil"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.ceil() function</h1>

This is the ceil function in Lua. It gives the smallest integer number greater or equal to the number in the argument.
<pre>
> a=-10.23
> print(math.ceil(a))
-10
> a=12.2332
> print(math.ceil(a))
13

</pre>

</body></html> ]====],
["tan"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.tan() function</h1>

This is the tangent function in Lua. It gives the result of an argument in radians.
<pre>
> a=-10.23
> print(math.tan(a))
-1.0404550266508
> a=12.2332
> print(math.tan(a))
-0.34607133217607
> a=3.14
> print(math.tan(a))
-0.0015926549364072

</pre>

</body></html> ]====],
["acos"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.acos() function</h1>

This is the arc cosinus function in Lua. It gives the inverse cosinus function result of a value between -1 and 1. Other intervals have an indefinit result.
<pre>
> a=-1
> print(math.acos(a))
3.1415926535898
> print(math.deg(math.acos(a)))
180.0
> a=1
> print(math.acos(a))
0.0
> a=-2
> print(math.acos(a))
-1.#IND
</pre>

With <code>math.deg</code> the radiant is converted into degrees.

</body></html> 
]====],
["string"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>string table</h1>

This table contains the functions for string manipulation. "When indexing a string in Lua, the first character is at position 1 (not at 0, as in C). Indices are allowed to be negatie and are interpreted as indexing backwards, from the end of the string. Thus, the last character is at position -1, and so on. ... The string library assumes one-byte character encodings." (Manual p. 40) Therefore UTF-8 must be treated with a own library (<code>utf8</code>).
<br><br>

The string library can be used in a object-oriented style. "For instance, <code>string.byte(s,i)</code> can be written as <code>s:byte(i)</code>." This is also called "syntactic sugar" (Chapter 16. Object-Oriented Programming).




<hr>
<h2>2.4 &ndash; Strings</h2>

<p>Strings have the usual meaning:
a sequence of characters.
Lua is eight-bit clean
and so strings may contain characters with any numeric value,
including embedded zeros.
That means that you can store any binary data into a string.
Strings in Lua are immutable values.
You cannot change a character inside a string,
as you may in C;
instead, you create a new string with the desired modifications,
as in the next example:
<pre>
    a = "one string"
    b = string.gsub(a, "one", "another")  -- change string parts
    print(a)       --> one string
    print(b)       --> another string
</pre>

<p>Strings in Lua are subject to automatic memory management,
like all Lua objects.
That means that you do not have to worry about allocation and
deallocation of strings; Lua handles this for you.
A string may contain a single letter or an entire book.
Lua handles long strings quite efficiently.
Programs that manipulate strings with 100K or 1M characters
are not unusual in Lua.

<p>We can delimit literal strings by
matching single or double quotes:
<pre>
    a = "a line"
    b = 'another line'
</pre>
As a matter of style,
you should use always the same kind of quotes
(single or double) in a program,
unless the string itself has quotes;
then you use the other quote,
or escape those quotes with backslashes.
Strings in Lua can contain the following C-like escape sequences:
<table align="center" border=1>
<tr><td><code>\a</code></td><td>bell</td></tr>
<tr><td><code>\b</code></td><td>back space</td></tr>
<tr><td><code>\f</code></td><td>form feed</td></tr>
<tr><td><code>\n</code></td><td>newline</td></tr>
<tr><td><code>\r</code></td><td>carriage return</td></tr>
<tr><td><code>\t</code></td><td>horizontal tab</td></tr>
<tr><td><code>\v</code></td><td>vertical tab</td></tr>
<tr><td><code>\\</code></td><td>backslash</td></tr>
<tr><td><code>\"</code></td><td>double quote</td></tr>
<tr><td><code>\'</code></td><td>single quote</td></tr>
<tr><td><code>\[</code></td><td>left square bracket</td></tr>
<tr><td><code>\]</code></td><td>right square bracket</td></tr>
</table>



<hr>
<h1><a name="StringLib">20 &ndash; The String Library</a></h1>

<p>The power of a raw Lua interpreter to manipulate strings is quite limited.
A program can create string literals and concatenate them.
But it cannot extract a substring, check its size,
or examine its contents.
The full power to manipulate strings in Lua
comes from its string library.

<p>Some functions in the string library are quite simple:
<code>string.len(s)</code>
returns the length of a string <code>s</code>.
<code>string.rep(s, n)</code>
returns the string <code>s</code> repeated <code>n</code> times.
You can create a string with 1M bytes (for tests, for instance)
with <code>string.rep("a", 2^20)</code>.
<code>string.lower(s)</code>
returns a copy of <code>s</code> with the
upper-case letters converted to lower case;
all other characters in the string are not changed
(<code>string.upper</code> converts to upper case).
As a typical use, if you want to sort an
array of strings regardless of case,
you may write something like
<pre>
    table.sort(a, function (a, b)
      return string.lower(a) &lt; string.lower(b)
    end)
</pre>


</body></html> ]====],
["tonumber"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>tonumber() function</h1>

This function converts number written as strings in number with the type number. The first argument <code>e</code> is the string to be converted. The optional second argument <code>base</code> is the  base in a range from 2 to 36 for the representation of numbers and should be used only by IT professionals who knows very well the use of binary or hexadecimal numbers. 

<br>

"When called with no <code>base</code>, <code>tonumber</code> tries to convert its argument to a number. If the argument is already a number or a string convertible to a number ..., then <code>tonumber</code> returns this number; otherwise, it returns <code>nil</code>." (Manual p.38) 


<pre>

> a=1
> print(tonumber(a))
1
> a=" 32"
> print(tonumber(a))
32
> a="1 5 2 2"
> print(tonumber(a))
nil
> a=" 32 things"
> print(tonumber(a))
nil


</pre>



<hr>
<h2>2.5 &ndash; Tables</h2>



<p>Because we can index a table with any type,
when indexing a table
we have the same subtleties that arise in equality.
Although we can index a table both with the
number <code>0</code> and with the string <code>"0"</code>,
these two values are different (according to equality)
and therefore denote different positions in a table.
By the same token, the strings <code>"+1"</code>, <code>"01"</code>,
and <code>"1"</code> all denote different positions.
When in doubt about the actual types of your indices,
use an explicit conversion to be sure:
<pre>
    i = 10; j = "10"; k = "+10"
    a = {}
    a[i] = "one value"
    a[j] = "another value"
    a[k] = "yet another value"
    print(a[j])            --> another value
    print(a[k])            --> yet another value
    print(a[tonumber(j)])  --> one value
    print(a[tonumber(k)])  --> one value
</pre>
You can introduce subtle bugs in your program
if you do not pay attention to this point.

<hr>
<table width="100%" class="nav">
<tr>
<td width="90%" align="left">
<small>
  Copyright &copy; 2003&ndash;2004 Roberto Ierusalimschy.  All rights reserved.
</small>
</td>

</table>


</body></html>




</body></html> ]====],
["cos"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.cos() function</h1>

This is the cosine function in Lua. It gives the result in radians.
<pre>
> a=-10.23
> print(math.cos(a))
-0.6929511652561
> a=12.2332
> print(math.cos(a))
0.94501017458988

</pre>

</body></html> ]====],
["tanh"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.tanh() function</h1>

This is the hyperbolic tangent function in Lua.
<pre>
> a=-10.23
> print(math.tanh(a))
-0.99999999739765
> a=12.2332
> print(math.tanh(a))
0.99999999995264


</pre>

</body></html> ]====],
["math"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math table</h1>

The math table contains all the functions needed for mathematical operations. This is a very useful table for non IT professionals treating with numbers and values but some functions of this table are not needed by non IT professionals. 

</body></html> ]====],
["path"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>package.path variable</h1>


This variable is only for IT professionals.

</body></html> ]====],
["stderr"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>io.stderr() function</h1>

This function is the file for the standard error messages. This is for IT professionals.

</body></html> ]====],
["stdout"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>io.stdout() function</h1>

This function is the file for the standard output. This is for IT professionals.


</body></html> ]====],
["abs"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.abs() function</h1>

This is the absolute function in Lua. It gives the absolut value of a signed value.
<pre>
> a=-2
> print(math.abs(a))
2
</pre>

</body></html> ]====],
["tointeger"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.tointeger() function</h1>

This function converts a float number into an integer number in Lua.
<pre>
> print(math.tointeger(1.0))
1
> print(math.tointeger(231.2340))
nil
> print(math.tointeger(231.0))
231

</pre>

</body></html> ]====],
["rad"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.rad() function</h1>

This is the radian function in Lua. It converts degrees to radians.
<pre>
> a=-89.954373835539
> print(math.rad(a))
-1.57
> a=179.90874767108
> print(math.rad(a))
3.14

</pre>

</body></html> ]====],
["deg"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.deg() function</h1>

This is the degree function in Lua. It converts radians to degrees.
<pre>
> a=-1.57
> print(math.deg(a))
-89.954373835539
> a=3.14
> print(math.deg(a))
179.90874767108

</pre>

</body></html> ]====],
["rep"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>string.rep() function</h1>

This function returns a string with a concatenation of as much copies as the number as second argument. The optional third argument is the potential separator. By default there is no separator.

<pre>

> print(string.rep("a",3))
aaa
> print(string.rep("b",3,"|"))
b|b|b

</pre>

This can especially be used with the function match and gmatch.

<pre>

> pattern=string.rep(".?",4)

> ("Text"):match(pattern)
Text
> ("Texte"):match(pattern)
Text
> ("Tex"):match(pattern)
Tex
> ("Te"):match(pattern)
Te
> for fixedWidth in ("Das ist ein Text, der zu lang ist."):gmatch(pattern) do 
>> print(fixedWidth) end
Das
ist
ein
Text
, de
r zu
 lan
g is
t.

</pre>


</body></html> ]====],
["pairs"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>pairs() function</h1>

This function is only used in generic for loops through table keys (inclusive all indices). To read all the keys k and corresponding values v use the function pairs. 

<pre>
    -- print the indices i and corresponding values v
> a={Key1=15,1234,["a key as text"]=234,234}
> a[4]="4 as a key"
>  for k,v in pairs(a) do print(k,v) end
1       1234
2       234
4       4 as a key
Key1    15
a key as text   234

</pre>

Despite its apparent simplicity, the generic for is powerful. With proper iterators, we can traverse almost anything, and do it in a readable fashion. The standard libraries provide several iterators, which allow us to iterate over the pairs in a table (here: <code>pairs</code>). 

</body></html> ]====],
["arg"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>arg table </h1>

arg is used to give the name of the script executed and the parameters before and after the script name.
<br>
<pre>print(arg[0])</pre>
<br>

This prints the name of the script file.
<br>

<pre>print(arg[-1])</pre>
<br>

This prints the first arguments write in the console before the Lua script.
<br>

If you write 
<br>
<pre>lua -i test.lua</pre>
<br>
it is -i.
<br>

</body></html> ]====],
["next"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.next() function</h1>

This is the function for the next elementn after the second argument in a Lua table. With a for loop you can iterate through a Lua table. It is equivalent with the syntax <code> for k,v in pairs(t) do print(k,v) end </code>


<pre>


> t={123,231,23,23,123,test="sregeg","awsld�kfn�"}
> for k,v in next,t do print(k,v) end
1       123
2       231
3       23
4       23
5       123
6       awsld�kfn�
test    sregeg
> print(next(t))
1       123
> print(next(t,1))
2       231
> print(next(t,2))
3       23
> print(next(t,3))
4       23
> print(next(t,4))
5       123
> print(next(t,5))
6       awsld�kfn�
> print(next(t,6))
test    sregeg
> print(next(t,test))
1       123

</pre>

</body></html> 

</body></html> ]====],
["load"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>load() function</h1>

This function executes Lua code, but is only for IT professionals.

</body></html> ]====],
["setlocale"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>os.setlocale() function</h1>

This function is only for IT professionals. 
<br><br>
The <code>os.setlocale</code> function sets the current
locale used by a Lua program.
Locales define behavior that is sensitive to
cultural or linguistic differences.

</body></html> ]====],
["fmod"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.fmod() function</h1>

This is the remainder of division of 

<br clear="all" /><table border="0" width="100%"><tr><td>
<table align="center" cellspacing="0"  cellpadding="2"><tr><td nowrap="nowrap" align="center">
</td><td nowrap="nowrap" align="center">
<i>x</i>
<div class="hrcomp"><hr noshade="noshade" size="1"/></div><i>y</i><br /></td><td nowrap="nowrap" align="center">
</td></tr></table>


 function in Lua that rounds the quotient towards zero.
<pre>
> print(math.fmod(13.34,4.234))
0.638
> print(math.fmod(13,4.234))
0.298
> print(math.fmod(13,4))
1
> print(math.fmod(13.2,4))
1.2
> print(math.fmod(-13.2,4))
-1.2

</pre>

</body></html> 

</body></html> ]====],
["coroutine"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>coroutine table </h1>

This table is only needed by IT professionals to build complex programms.

</body></html> ]====],
["open"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>io.open() function</h1>

The io.open function is used to open a file to read or write. To read has one mode read mode "r", to write has two modes write the whole file "w" or append to an existing file "a".
<br>

<pre>
inputfile=io.open("C:\\temp\\test.txt","r")
Text=inputfile:read("*a")
inputfile:close()

outputfile=io.open("C:\\temp\\test1.txt","w")
outputfile:write(Text)
outputfile:close()

outputfile=io.open("C:\\temp\\test1.txt","a")
outputfile:write(Text)
outputfile:close()
</pre>
<br>

<br>
It exists also an additional mode "b" to treat binary files. This is only useful for IT professionals.

<br>
<br>
The read function reads strings from the current input file. Its arguments control what is read: 
<br>
"*all" reads the whole file 
<br>
"*a" reads the whole file 
<br>
"*line" reads the next line 
<br>
"*number" reads a number 
<br>
num reads a string with up to num characters 
<br>
The call io.read("*all") reads the whole current input file, starting at its current position. If we are at the end of file, or if the file is empty, the call returns an empty string. 

</body></html> ]====],
["type"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>type() function</h1>

This function "returns the type of its only argument, coded as a string. The possible results of this function are <code>"nil"</code> (a string, not the value <code>nil</code>, <code>"number"</code>,  <code>"string"</code>, code>"boolean"</code>, <code>"table"</code>, <code>"function"</code>, <code>"thread"</code>, and <code>"userdata"</code>." (Manual p. 38)

<pre>
>     print(type(10.4*3))         --> number
number
>     print(type(print))          --> function
function
>     print(type(true))           --> boolean
boolean
>     a = 10 print(type(a))   --> number
number
>     a = "a string!!"    print(type(a))   --> string
string
> print(type(notDefinedVariable))
nil
</pre>


<h1>io.type() function</h1>

This function gives the result, wether a file name is a file or a closed file:
<br>
<br>
<pre>
> testfile=io.open("C:\\temp\\test.txt")
> io.type(testfile)
file
> testfile:close()
true
> io.type(testfile)
closed file
</pre>

<h1>math.type() function</h1>

This function gives the result, wether a number is a float or an integer:
<pre>
> print(math.tointeger(1.0))
1
> print(math.tointeger(231.2340))
nil
> print(math.tointeger(231.0))
231

</pre>



<hr>
<h1><a name="TypesSec">2 &ndash; Types and Values</a></h1>

<p>Lua is a dynamically typed language.
There are no type definitions in the language;
each value carries its own type.

<p>There are eight basic types in Lua:
<em>nil</em>, <em>boolean</em>, <em>number</em>, <em>string</em>, <em>userdata</em>,
<em>function</em>, <em>thread</em>, and <em>table</em>.
The <code>type</code> function gives
the type name of a given value:
<pre>
    print(type("Hello world"))  --> string
    print(type(10.4*3))         --> number
    print(type(print))          --> function
    print(type(type))           --> function
    print(type(true))           --> boolean
    print(type(nil))            --> nil
    print(type(type(X)))        --> string
</pre>
The last example will result in <code>"string"</code> no matter the value of <code>X</code>,
because the result of <code>type</code> is always a string.

<p>Variables have no predefined types;
any variable may contain values of any type:
<pre>
    print(type(a))   --> nil   (`a' is not initialized)
    a = 10
    print(type(a))   --> number
    a = "a string!!"
    print(type(a))   --> string
    a = print        -- yes, this is valid!
    a(type(a))       --> function
</pre>
Notice the last two lines:
Functions are first-class values in Lua;
so, we can manipulate them like any other value.
(More about that in <a href="6.html#firstclass">Chapter 6</a>.)

<p>Usually,
when you use a single variable for different types,
the result is messy code.
However, sometimes the judicious use of this facility
is helpful,
for instance in the use of <B>nil</B> to differentiate a normal
return value from an exceptional condition.

<hr>
<table width="100%" class="nav">
<tr>
<td width="90%" align="left">
<small>
  Copyright &copy; 2003&ndash;2004 Roberto Ierusalimschy.  All rights reserved.
</small>
</td>

</table>





</body></html> ]====],
["assert"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>assert() function</h1>

assert is useful to give a better error message if wanted.
<br>
Here is an example for the use of it:

<pre>
> s="awrqwr" assert(load(s))()
stdin:1: [string "awrqwr"]:1: syntax error near <eof>
stack traceback:
        [C]: in function 'assert'
        stdin:1: in main chunk
        [C]: in ?
> s="awrqwr" load(s)()
stdin:1: attempt to call a nil value
stack traceback:
        stdin:1: in main chunk
        [C]: in ?

</pre>

The error message without assert is "attempt to call a nil value". With assert you get the error message '[string "awrqwr"]: 2: syntax error near <eof>'

</body></html> ]====],
["format"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>string.format() function</h1>

This function is for IT professionals because the format string follows the same rules as the C function <code>sprintf</code> which is very complex and can be limited by the underlying C implementation. The function returns a formatted version of its variable.

</body></html> ]====],
["remove"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>os.remove() function</h1>


The <code>os.remove</code> function removes (deletes) a file.


<h1>table.remove() function</h1>


This function has the first argument <code>list</code> and the second optional argument <code>pos</code>. It "removes from <code>list</code> the element at position <code>pos</code>, shifting down the elements <code>list[pos+1],list[pos+2], ..., list[#list]</code> and erasing element <code>list[#list]</code>. (It r)eturns the value of the removed element. The default value for <code>pos</code> is <code>#list</code>, so that a call <code>table.remove(t)</code> removes the last element of list <code>t</code>." (Manual p. 43)

<pre>
> aTable={234,23,"Text",[12]=34,n=3}
> for i,v in pairs(aTable) do print(i,v) end
1       234
2       23
3       Text
12      34
n       3
> table.remove(aTable)
Text
> table.remove(aTable,1)
234
> for i,v in pairs(aTable) do print(i,v) end
1       23
12      34
n       3
> aTable.n=nil
> for i,v in pairs(aTable) do print(i,v) end
1       23
12      34

</pre>

</body></html> ]====],
["xpcall"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>xpcall() function</h1>

"This function is similar to <code>pcall</code>, except that it sets a new message handler as the second argument." (Manual p. 38) The message handler must be a function. As it is too complicated for non IT professionals it is considered to be only for IT professionals.

</body></html> ]====],
["randomseed"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.randomseed() function</h1>

This is the pseudo-random function in Lua that produces equal sequences of pseudo-random numbers. 

If you do not want to have always the same sequence you can choose a randomseed with os.time: math.randomseed(os.time()).

<pre>
> math.randomseed(1)
1       0
> print(math.random(1,100))
30
> print(math.random(1,100))
34
> print(math.random(1,100))
45
> print(math.random(1,100))
87
> print(math.random(1,100))
94
> print(math.random(1,100))
60
> print(math.random(1,100))
94
> print(math.random(1,100))
24


> math.randomseed(1)
1       0
> print(math.random(1,100))
30
> print(math.random(1,100))
34
> print(math.random(1,100))
45
> print(math.random(1,100))
87
> print(math.random(1,100))
94
> print(math.random(1,100))
60
> print(math.random(1,100))
94
> print(math.random(1,100))
24



> math.randomseed(os.time())
1644960318      0
> print(math.random(1,100))
88

> math.randomseed(os.time())
1644960341      0
> print(math.random(1,100))
26

> math.randomseed(os.time())
1644960345      0
> print(math.random(1,100))
80


</pre>

</body></html> 




]====],
["sub"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>string.sub() function</h1>

This function returns a substring of the argument from the start position of the second argument to the end or to the end position of the third argument. The second argument can be negative, the third argument also. Then the position is calculated from the end of the string. If there is not an interval representing the substring, the substring is empty. If a negative index is lower than 1 it is corrected to 1. If the second argument is greater than the length of the string it is corrected to the length.

<pre>

> print(string.sub("This is a Text.",2))
his is a Text.
> print(string.sub("This is a Text.",2,5))
his
> print(string.sub("This is a Text.",2,6))
his i
> print(string.sub("This is a Text.",-2,6))

> print(string.sub("This is a Text.",-2,-6))

> print(string.sub("This is a Text.",-6,-2))
 Text
> print(string.sub("This is a Text.",6,-2))
is a Text
> print(string.sub("This is a Text.",-6,12))
 Te
> print(string.sub("This is a Text.",-6))
 Text.


</pre>

</body></html> ]====],
["warn"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>warn() function</h1>

This function is only for IT professionals returning a warning with a message composed by the concatenation of all its string arguments.

</body></html> ]====],
["char"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>string.char() function</h1>

The <code>string.char</code> function converts the internal numeric representations of a character to a character. The function string.char gets zero or more integers, converts each one to a character, and returns a string concatenating all those characters.

<pre>

> print(string.char(151,100,153,154,155,56,57,58,59,50,21))
�d���89:;2�

</pre>


</body></html> ]====],
["require"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>require() function</h1>

This function loads the module or library given in its argument. For the IUP-Lua framework the most functionalities can be loaded by loading the module or library <code>"iuplua"</code>. For the work wirh Microsoft Office files the LuaCOM library is loaded with the argument <code>"luacom"</code>. The Lua file system library is loaded with <code> "lfs"</code>


<pre>
> require("iuplua")           --require iuplua for GUIs
table: 000000540CFB6B50 C:\Lua\iuplua54.dll
> require("iuplua_scintilla") --for Scintilla-editor
true    C:\Lua\iuplua_scintilla54.dll
> require("iupluaweb")        --require iupluaweb for webbrowser
true    C:\Lua\iupluaweb54.dll
> require("iupluagl") --library for video camera
true    C:\Lua\iupluagl54.dll
> require("iuplua_plot")      --for plots in MDI
true    C:\Lua\iuplua_plot54.dll
> require("iupluacontrols")   --for matrix and matrixex in MDI
true    C:\Lua\iupluacontrols54.dll


> require("luacom")           --require treatment of office files
true    C:\Lua\luacom.dll

> require("lfs") --for Lua file system
table: 000000540F004150 C:\Lua\lfs.dll

> require("imlua") --for images
table: 0000003430577520 C:\Lua\imlua54.dll
> require("imlua_process") --for rotation
table: 0000003430577520 C:\Lua\imlua_process54.dll
> require("imlua_avi") --format .AVI for saving video
table: 0000003430577520 C:\Lua\imlua_avi54.dll
> require("imlua_wmv") --format .WMV for saving video
table: 0000003430577520 C:\Lua\imlua_wmv54.dll
> require("imlua_capture") --library for video camera
table: 0000003430577520 C:\Lua\imlua_capture54.dll


> require("cdlua") --for images
table: 0000003432683370 C:\Lua\cdlua54.dll
> require("cdluapdf") --for pdf and powerpoint
table: 0000003432683370 C:\Lua\cdluapdf54.dll
> require("cdluaim") --for images
true    C:\Lua\cdluaim54.dll

> require("iupluacd") --for iup canvas
table: 0000003432683370 C:\Lua\iupluacd54.dll

> require("luagl") --library for video camera
table: 00000034326A7630 C:\Lua\luagl.dll

</pre>


<pre>
local js = require("js") --require for fengari script
</pre>


<hr>
<h2><a name="require">8.1 &ndash; The <code>require</code> Function</a></h2>

<p>Lua offers a higher-level function to load and run libraries,
called <code>require</code>.
Roughly, <code>require</code> does the same job as <code>dofile</code>,
but with two important differences.
First, <code>require</code> searches for the file in a path;
second, <code>require</code> controls whether a file has already been run
to avoid duplicating the work.
Because of these features,
<code>require</code> is the preferred function in Lua for loading libraries.


</body></html> ]====],
["getmetatable"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>getmetatable () function</h1>

This function is useful for IT professionals. The mechanics of metatables is not necessary for non IT professionals and too complex so that there is here no description.

</body></html> ]====],
["frexp"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>math.frexp() function</h1>

This is the frexp function in Lua. This function returnis <i>m</i> and <i>e</i> such that the argument  <i>x</i>=<i>m</i>2<sup><i>e</i></sup>. <i>e</i> is an integer and <i>m</i> is in the range [0.5,1) or zero when <i>x</i> is zero.
<pre>
> print(math.frexp(13.34,4.234))
0.83375 4
> print(math.frexp(13.34))
0.83375 4
> print(math.frexp(13.342334))
0.833895875     4
> print(math.frexp(13.342334212))
0.83389588825   4
> print(math.frexp(134343.342334212))
0.51247918065724        18
> print(math.frexp(1343243.342334212))
0.64050833813391        21
> print(math.frexp(13432323243.342334212))
0.78186411662856        34
> print(math.frexp(1))
0.5     1
> print(math.frexp(2))
0.5     2
> print(math.frexp(3))
0.75    2
> print(math.frexp(4))
0.5     3
> print(math.frexp(5))
0.625   3

</pre>

</body></html> 

</body></html> ]====],
["_VERSION"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>_VERSION</h1>

_VERSION is the version of Lua, e.g. Lua 5.4 

<br>
<br>
<pre>print(_VERSION)</pre>
<br>
<br>

You can use it for checks
<br>
<br>
<pre>if _VERSION=="Lua 5.4" then do print("Lua 5.4") else print("other version") end</pre>

</body></html> ]====],
["tostring"]=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>tostring() function</h1>

This function converts any value into strings with defined format. It "receives a value of any typ and converts it to a string in a reasonable format." (Manual p. 38)

<br>

For IT professionals the conversion how numbers are converted is controlled by <code>string.format</code> and metatables are used with <code>"__tostring"</code>, but these two things are not for non IT professionals.

<pre>

> print(tostring(a))
 32 things
> aTable={231,123,2}
> print(tostring(aTable))
table: 0000008D1C796C50
> print(tostring(notDefinedVariable))
nil
> print(notDefinedVariable .. " concatenated")
stdin:1: attempt to concatenate a nil value (global 'notDefinedVariable')
stack traceback:
        stdin:1: in main chunk
        [C]: in ?
> print(tostring(notDefinedVariable) .. " concatenated")
nil concatenated
> print(table.sort)
function: 000007FABCBE3A20
> print(tostring(table.sort(aTable)))
stdin:1: bad argument #1 to 'tostring' (value expected)
stack traceback:
        [C]: in function 'tostring'
        stdin:1: in main chunk
        [C]: in ?

</pre>



<hr>
<h2>2.4 &ndash; Strings</h2>


<p>To convert a number to a string,
you can call the function <code>tostring</code>
or concatenate the number with the empty string:
<pre>
    print(tostring(10) == "10")   --> true
    print(10 .. "" == "10")       --> true
</pre>
Such conversions are always valid.

<hr>
<table width="100%" class="nav">
<tr>
<td width="90%" align="left">
<small>
  Copyright &copy; 2003&ndash;2004 Roberto Ierusalimschy.  All rights reserved.
</small>

</tr>
</table>


</body></html>



</body></html> ]====],
}--TextHTMLtable<!--



----[====[This programm has webpages within the Lua script which can contain a tree in html

--1. basic data

--1.1.1 libraries
require("iuplua")           --require iuplua for GUIs
require("iupluaweb")        --require iupluaweb for webbrowser
--iup.SetGlobal("UTF8MODE","NO")

--1.1.2 initalize clipboard
clipboard=iup.clipboard{}

--1.2 color section
--1.2.1 color of the console associated with the graphical user interface if started with lua54.exe and not wlua54.exe
os.execute('color 71')

--1.2.2 Beckmann und Partner colors
color_red_bpc="135 31 28"
color_light_color_grey_bpc="196 197 199"
color_grey_bpc="162 163 165"
color_blue_bpc="18 32 86"

--1.2.3 color definitions
color_background=color_light_color_grey_bpc
color_buttons=color_blue_bpc -- works only for flat buttons, "18 32 86" is the blue of BPC
color_button_text="255 255 255"
color_background_tree="246 246 246"

--1.3 path of the graphical user interface and filename of this script
path=arg[0]:match("(.*)\\")
--test with: print(path)
thisfilename=arg[0]:match("\\([^\\]+)$")
--test with: print(arg[0])
--test with: print(thisfilename)



--2. global data definition
aktuelleSeite=1


--3. functions
--3.1 simplified version of table.move for Lua 5.1 and Lua 5.2 that is enough for using of table.move here
if _VERSION=='Lua 5.1' or _VERSION=='Lua 5.2' then
	function table.move(a,f,e,t)
	for i=f,e do
		local j=i-f
		a[t+j]=a[i]
	end --for i=f,e do
	return a 
	end --function table.move(a,f,e,t)
end --if _VERSION=='Lua 5.1' then

--3.2 function escaping magic characters
function string.escape_forbidden_char(insertstring) --this function takes a string and returns the same string with escaped characters
	return insertstring:gsub("\\", "\\\\"):gsub("\"", "\\\""):gsub("\'", "\\\'"):gsub("\n", "\\n"):gsub("\r", "\\n")
end --function string.escape_forbidden_char(insertstring)

--3.3 function which saves the current iup htmlTexts as a Lua table
function save_html_to_lua(htmlTexts, outputfile_path)
	--read the programm of the file itself, commentSymbol is used to have another pattern here as searched
	inputfile=io.open(path .. "\\" .. thisfilename,"r")
	commentSymbol,inputTextProgramm=inputfile:read("*a"):match("lua_tree_output={.*}%-%-lua_tree_output.*TextHTMLtable={.*}(%-%-)TextHTMLtable<!%-%-(.*)")
	inputfile:close()
	--build the new htmlTexts
	local output_htmlTexts_text="TextHTMLtable={" --the output string
	local outputfile=io.output(outputfile_path) --a output file
	--save the tree
	local output_tree_text="lua_tree_output=" --the output string
	local outputfile=io.output(outputfile_path) --a output file
	for i=0,tree.count - 1 do --loop for all nodes
		if tree["KIND" .. i ]=="BRANCH" then --consider cases, if actual node is a branch
			if (i > 0 and (tonumber(tree["DEPTH" .. i ]) > tonumber(tree["DEPTH" .. i-1 ]) ) ) or i==0 then --consider cases if depth increases
				output_tree_text = output_tree_text .. '{ branchname="' .. string.escape_forbidden_char(tree["TITLE" .. i ]) .. '", \n' -- we open a new branch
				--save state
				if tree["STATE" .. i ]=="COLLAPSED" then
					output_tree_text = output_tree_text .. 'state="COLLAPSED",\n'
				end --if tree["STATE" .. i ]=="COLLAPSED" then
			elseif i > 0 and tonumber(tree["DEPTH" .. i ]) < tonumber(tree["DEPTH" .. i-1 ]) then --if depth decreases
				if tree["KIND" .. i-1 ] == "BRANCH" then --depending if the predecessor node was a branch we need to close one bracket more
					for j=1, tonumber(tree["DEPTH" .. i-1 ])- tonumber(tree["DEPTH" .. i ]) +1 do
						output_tree_text = output_tree_text .. '},\n'
					end --for j=1, tonumber(tree["DEPTH" .. i-1 ])- tonumber(tree["DEPTH" .. i ]) +1 do
					output_tree_text = output_tree_text .. '{ branchname="' .. string.escape_forbidden_char(tree["TITLE" .. i ]) .. '", \n' --and we open the new branch
					--save state
					if tree["STATE" .. i ]=="COLLAPSED" then
						output_tree_text = output_tree_text .. 'state="COLLAPSED",\n'
					end --if tree["STATE" .. i ]=="COLLAPSED" then
				else
					for j=1, tonumber(tree["DEPTH" .. i-1 ])- tonumber(tree["DEPTH" .. i ]) do -- or if the predecessor node was a leaf
						output_tree_text = output_tree_text .. '},\n'
					end --for j=1, tonumber(tree["DEPTH" .. i-1 ])- tonumber(tree["DEPTH" .. i ]) do
					output_tree_text = output_tree_text .. '{ branchname="' .. string.escape_forbidden_char(tree["TITLE" .. i ]) .. '", \n' --and we open the new branch
					--save state
					if tree["STATE" .. i ]=="COLLAPSED" then
						output_tree_text = output_tree_text .. 'state="COLLAPSED",\n'
					end --if tree["STATE" .. i ]=="COLLAPSED" then
				end --if tree["KIND" .. i-1 ] == "BRANCH" then
			elseif i > 0 and tonumber(tree["DEPTH" .. i ]) == tonumber(tree["DEPTH" .. i-1 ]) then --or if depth stays the same
				if tree["KIND" .. i-1 ] == "BRANCH" then --again consider if the predecessor node was a branch
					output_tree_text = output_tree_text .. '},\n{ branchname="' .. string.escape_forbidden_char(tree["TITLE" .. i ]) .. '", \n'
					--save state
					if tree["STATE" .. i ]=="COLLAPSED" then
						output_tree_text = output_tree_text .. 'state="COLLAPSED",\n'
					end --if tree["STATE" .. i ]=="COLLAPSED" then
				else --or a leaf
					output_tree_text = output_tree_text .. '\n{ branchname="' .. string.escape_forbidden_char(tree["TITLE" .. i ]) .. '", \n'
					--save state
					if tree["STATE" .. i ]=="COLLAPSED" then
						output_tree_text = output_tree_text .. 'state="COLLAPSED",\n'
					end --if tree["STATE" .. i ]=="COLLAPSED" then
				end --if tree["KIND" .. i-1 ] == "BRANCH" then
			end --if (i > 0 and (tonumber(tree["DEPTH" .. i ]) > tonumber(tree["DEPTH" .. i-1 ]) ) ) or i==0 then
		elseif tree["KIND" .. i ]=="LEAF" then --or if actual node is a leaf
			if (i > 0 and tonumber(tree["DEPTH" .. i ]) > tonumber(tree["DEPTH" .. i-1 ]) )  or i==0 then
				output_tree_text = output_tree_text .. ' "' .. string.escape_forbidden_char(tree["TITLE" .. i ]) .. '",' --we add the leaf
			elseif i > 0 and tonumber(tree["DEPTH" .. i ]) < tonumber(tree["DEPTH" .. i-1 ]) then
				if tree["KIND" .. i-1 ] == "LEAF" then --in the same manner as above, depending if the predecessor node was a leaf or branch, we have to close a different number of brackets
					for j=1, tonumber(tree["DEPTH" .. i-1 ])- tonumber(tree["DEPTH" .. i ]) do
						output_tree_text = output_tree_text .. '},\n'
					end --for j=1, tonumber(tree["DEPTH" .. i-1 ])- tonumber(tree["DEPTH" .. i ]) do
					output_tree_text = output_tree_text .. ' "' .. string.escape_forbidden_char(tree["TITLE" .. i ]) .. '",' --and in each case we add the new leaf
				else
					for j=1, tonumber(tree["DEPTH" .. i-1 ])- tonumber(tree["DEPTH" .. i ]) +1 do
						output_tree_text = output_tree_text .. '},\n'
					end --for j=1, tonumber(tree["DEPTH" .. i-1 ])- tonumber(tree["DEPTH" .. i ]) +1 do
					output_tree_text = output_tree_text .. ' "' .. string.escape_forbidden_char(tree["TITLE" .. i ]) .. '",'
				end --if tree["KIND" .. i-1 ] == "LEAF" then
			elseif i > 0 and tonumber(tree["DEPTH" .. i ]) == tonumber(tree["DEPTH" .. i-1 ]) then
				if tree["KIND" .. i-1 ] == "LEAF" then
					output_tree_text = output_tree_text .. ' "' .. string.escape_forbidden_char(tree["TITLE" .. i ]) .. '", \n'
				else
					output_tree_text = output_tree_text .. '},\n "' .. string.escape_forbidden_char(tree["TITLE" .. i ]) .. '", \n'
				end --if tree["KIND" .. i-1 ] == "LEAF" then
			end --if (i > 0 and tonumber(tree["DEPTH" .. i ]) > tonumber(tree["DEPTH" .. i-1 ]) )  or i==0 then
		end --if tree["KIND" .. i ]=="BRANCH" then
	end --for i=0,tree.count - 1 do
	for j=1, tonumber(tree["DEPTH" .. tree.count-1]) do
		output_tree_text = output_tree_text .. "}" --close as many brackets as needed
	end --for j=1, tonumber(tree["DEPTH" .. tree.count-1]) do
	if tree["KIND" .. tree.count-1]=="BRANCH" then
		output_tree_text = output_tree_text .. "}" -- we need to close one more bracket if last node was a branch
	end --if tree["KIND" .. tree.count-1]=="BRANCH" then
	--output_tree_text=string.escape_forbidden_char(output_tree_text)
	outputfile:write(output_tree_text .. "--lua_tree_output\n\n\n\n") --write everything into the outputfile
	--save the html pages
	for k,v in pairs(TextHTMLtable) do 
		if type(k)=="number" then
		output_htmlTexts_text=output_htmlTexts_text .. "\n[====[" .. v .. "]====],"
		else
		output_htmlTexts_text=output_htmlTexts_text .. '\n["' .. k .. '"]=[====[' .. v .. "]====],"
		end --if type(k)=="number" then
	end --for k,v in pairs(TextHTMLtable) do 

	output_htmlTexts_text=output_htmlTexts_text .. "\n}"
	outputfile:write(output_htmlTexts_text .. "--TextHTMLtable<!--") --write everything into the outputfile
	--write the programm for the data in itself
	outputfile:write(inputTextProgramm)
	outputfile:close()
end --function save_html_to_lua(htmlTexts, outputfile_path)


--4. dialogs
--4.1 rename dialog
--ok button
ok = iup.flatbutton{title = "OK",size="EIGHTH", BGCOLOR=color_buttons, FGCOLOR=color_button_text}
function ok:flat_action()
	tree.title = text.value
	return iup.CLOSE
end --function ok:flat_action()

--cancel button
cancel = iup.flatbutton{title = "Abbrechen",size="EIGHTH", BGCOLOR=color_buttons, FGCOLOR=color_button_text}
function cancel:flat_action()
	return iup.CLOSE
end --function cancel:flat_action()

text = iup.multiline{size="120x50",border="YES",expand="YES",wordwrap="YES"} --textfield
label1 = iup.label{title="Name:"}--label for textfield

--open the dialog for renaming branch/leaf
dlg_rename = iup.dialog{
	iup.vbox{label1, text, iup.hbox{ok,cancel}}; 
	title="Knoten bearbeiten",
	size="QUARTER",
	startfocus=text,
	}

--4.1 rename dialog end

--4.2 change page dialog
--ok_change_page button
ok_change_page = iup.flatbutton{title = "Seite ver�ndern",size="EIGHTH", BGCOLOR=color_buttons, FGCOLOR=color_button_text}
function ok_change_page:flat_action()
	webbrowser1.HTML= text1.value
	if tonumber(textbox1.value) then
		TextHTMLtable[aktuelleSeite]= text1.value
	else
		TextHTMLtable[textbox1.value]= text1.value
	end --if tonumber(textbox1.value) then
	return iup.CLOSE
end --function ok_change_page:flat_action()

--cancel_change_page button
cancel_change_page = iup.flatbutton{title = "Abbrechen",size="EIGHTH", BGCOLOR=color_buttons, FGCOLOR=color_button_text}
function cancel_change_page:flat_action()
	return iup.CLOSE
end --function cancel_change_page:flat_action()

--search searchtext.value in textfield1
search_in_text = iup.flatbutton{title = "Suche in der Seite",size="EIGHTH", BGCOLOR=color_buttons, FGCOLOR=color_button_text} 
searchPosition=1
function search_in_text:flat_action()
	from,to=text1.value:find(textbox2.value,searchPosition)
	searchPosition=to
	if from==nil then 
		searchPosition=1 
		iup.Message("Suchtext in der Seite nicht gefunden","Suchtext in der Seite nicht gefunden")
	else
		text1.SELECTIONPOS=from-1 .. ":" .. to
	end --if from==nil then 
end --	function search_in_text:flat_action()

text1 = iup.multiline{size="120x50",border="YES",expand="YES",wordwrap="YES"} --textfield
label1 = iup.label{title="Blattinhalt:"}--label for textfield

--open the dialog for renaming page
dlg_change_page = iup.dialog{
	iup.vbox{label1, text1, iup.hbox{ok_change_page,search_in_text,cancel_change_page}}; 
	title="Seite bearbeiten",
	size="400x350",
	startfocus=text1,
	}

--4.2 change page dialog end

--4.3 search dialog
searchtext = iup.multiline{border="YES",expand="YES", SELECTION="ALL",wordwrap="YES"} --textfield for search

--search in downward direction
searchdown    = iup.flatbutton{title = "Abw�rts",size="EIGHTH", BGCOLOR=color_buttons, FGCOLOR=color_button_text} 
function searchdown:flat_action()
	local help=false
	--downward search
	if checkboxforcasesensitive.value=="ON"  then
		for i=tree.value + 1, tree.count-1 do
			if tree["title" .. i]:match(searchtext.value)~= nil then
				tree.value= i
				help=true
				break
			end --if tree["title" .. i]:match(searchtext.value)~= nil then
		end --for i=tree.value + 1, tree.count-1 do
	else
		for i=tree.value + 1, tree.count-1 do
			if tree["title" .. i]:lower():match(searchtext.value:lower())~= nil then
				tree.value= i
				help=true
				break
			end --if tree["title" .. i]:lower():match(searchtext.value:lower())~= nil then
		end --for i=tree.value + 1, tree.count-1 do
	end --if checkboxforcasesensitive.value=="ON" then
	if help==false then
		iup.Message("Suche","Ende des Baumes erreicht.")
		tree.value=0 --starting again from the top
		iup.NextField(maindlg)
		iup.NextField(dlg_search)
	end --if help==false then
end --function searchdown:flat_action()

--search to mark without going to the any node
searchmark    = iup.flatbutton{title = "Markieren",size="EIGHTH", BGCOLOR=color_buttons, FGCOLOR=color_button_text} 
function searchmark:flat_action()
	--unmark all nodes
	for i=0, tree.count - 1 do
			tree["color" .. i]="0 0 0"
	end --for i=0, tree.count - 1 do
	--unmark all nodes end
	--mark all nodes
	for i=0, tree.count - 1 do
		if tree["title" .. i]:upper():match(searchtext.value:upper())~= nil then
			iup.TreeSetAncestorsAttributes(tree,i,{color="255 0 0",})
			iup.TreeSetNodeAttributes(tree,i,{color="0 0 250",})
			iup.TreeSetDescendantsAttributes(tree,i,{color="90 195 0"})
		end --if tree["title" .. i]:upper():match(searchtext.value:upper())~= nil then
	end --for i=0, tree.count - 1 do
	--mark all nodes end
	for i=0, tree.count - 1 do
	end --for i=0, tree.count - 1 do
end --function searchmark:flat_action()

--unmark without leaving the search-window
unmark    = iup.flatbutton{title = "Entmarkieren",size="EIGHTH", BGCOLOR=color_buttons, FGCOLOR=color_button_text} 
function unmark:flat_action()
--unmark all nodes
for i=0, tree.count - 1 do
	tree["color" .. i]="0 0 0"
end --for i=0, tree.count - 1 do
--unmark all nodes end
end --function unmark:flat_action()

--search in upward direction
searchup   = iup.flatbutton{title = "Aufw�rts",size="EIGHTH", BGCOLOR=color_buttons, FGCOLOR=color_button_text} 
function searchup:flat_action()
	local help=false
	--upward search
	if checkboxforcasesensitive.value=="ON" then
		for i=tree.value - 1, 0, -1 do
			if tree["title" .. i]:match(searchtext.value)~= nil then
				tree.value= i
				help=true
				break
			end --if tree["title" .. i]:match(searchtext.value)~= nil then
		end --for i=tree.value - 1, 0, -1 do
	else
		for i=tree.value - 1, 0, -1 do
			if tree["title" .. i]:lower():match(searchtext.value:lower())~= nil then
				tree.value= i
				help=true
				break
			end --if tree["title" .. i]:lower():match(searchtext.value:lower())~= nil then
		end --for i=tree.value - 1, 0, -1 do
	end --if checkboxforcasesensitive.value=="ON" then
	if help==false then
		iup.Message("Suche","Anfang des Baumes erreicht.")
		tree.value=tree.count-1 --starting again from the bottom
		iup.NextField(maindlg)
		iup.NextField(dlg_search)
	end --if help==false then
end --	function searchup:flat_action()

checkboxforcasesensitive = iup.toggle{title="Gro�-/Kleinschreibung", value="OFF"} --checkbox for casesensitiv search
search_label=iup.label{title="Suchfeld:"} --label for textfield

--put above together in a search dialog
dlg_search =iup.dialog{
			iup.vbox{iup.hbox{search_label,searchtext,}, 

			iup.label{title="Sonderzeichen: %. f�r ., %- f�r -, %+ f�r +, %% f�r %, %[ f�r [, %] f�r ], %( f�r (, %) f�r ), %^ f�r ^, %$ f�r $, %? f�r ?",},
			iup.hbox{searchmark,unmark,}, 
			iup.label{title="rot: �bergeordnete Knoten",fgcolor = "255 0 0", },
			iup.label{title="blau: gleicher Knoten",fgcolor = "0 0 255", },
			iup.label{title="gr�n: untergeordnete Knoten",fgcolor = "90 195 0", },
			iup.hbox{searchdown, searchup,checkboxforcasesensitive,},

			}; 
		title="Suchen",
		size="420x100",
		startfocus=searchtext
		}

--4.3 search dialog end

--5. context menus (menus for right mouse click)

--5.1 menu of tree
--5.1.1 copy node of tree
startcopy = iup.item {title = "Knoten kopieren"}
function startcopy:action() --copy node
	 clipboard.text = tree['title']
end --function startcopy:action()

--5.1.2 rename node and rename action for other needs of tree
renamenode = iup.item {title = "Knoten bearbeiten"}
function renamenode:action()
	text.value = tree['title']
	dlg_rename:popup(iup.CENTER, iup.CENTER) --popup rename dialog
	iup.SetFocus(tree)
end --function renamenode:action()

--5.1.3 add branch to tree
addbranch = iup.item {title = "Ast hinzuf�gen"}
function addbranch:action()
	tree.addbranch = ""
	tree.value=tree.value+1
	renamenode:action()
end --function addbranch:action()

--5.1.3.1 add branch to tree by insertbranch
addbranchbottom = iup.item {title = "Ast darunter hinzuf�gen"}
function addbranchbottom:action()
	tree["insertbranch" .. tree.value] = ""
	for i=tree.value+1,tree.count-1 do
		if tree["depth" .. i]==tree["depth" .. tree.value] then
			tree.value=i
			renamenode:action()
			break
		end --if tree["depth" .. tree.value+1]==tree["depth" .. tree.value] then
	end --for i=tree.value+1,tree.count-1 do
end --function addbranchbottom:action()

--5.1.3.2 add leaf to tree by insertleaf
addleafbottom = iup.item {title = "Blatt darunter hinzuf�gen"}
function addleafbottom:action()
	tree["insertleaf" .. tree.value] = ""
	for i=tree.value+1,tree.count-1 do
		if tree["depth" .. i]==tree["depth" .. tree.value] then
			tree.value=i
			renamenode:action()
			break
		end --if tree["depth" .. tree.value+1]==tree["depth" .. tree.value] then
	end --for i=tree.value+1,tree.count-1 do
end --function addleafbottom:action()

--5.1.4 add branch of tree from clipboard
addbranch_fromclipboard = iup.item {title = "Ast aus Zwischenablage"}
function addbranch_fromclipboard:action()
	tree.addbranch = clipboard.text
	tree.value=tree.value+1
end --function addbranch_fromclipboard:action()

--5.1.4.1 add branch to tree by insertbranch from clipboard
addbranch_fromclipboardbottom = iup.item {title = "Ast darunter aus Zwischenablage"}
function addbranch_fromclipboardbottom:action()
	tree["insertbranch" .. tree.value] = clipboard.text
	for i=tree.value+1,tree.count-1 do
	if tree["depth" .. i]==tree["depth" .. tree.value] then
		tree.value=i
		break
	end --if tree["depth" .. tree.value+1]==tree["depth" .. tree.value] then
	end --for i=tree.value+1,tree.count-1 do
end --function addbranch_fromclipboardbottom:action()

--5.1.4.2 add leaf to tree by insertleaf from clipboard
addleaf_fromclipboardbottom = iup.item {title = "Blatt darunter aus Zwischenablage"}
function addleaf_fromclipboardbottom:action()
	tree["insertleaf" .. tree.value] = clipboard.text
	for i=tree.value+1,tree.count-1 do
	if tree["depth" .. i]==tree["depth" .. tree.value] then
		tree.value=i
		break
	end --if tree["depth" .. tree.value+1]==tree["depth" .. tree.value] then
	end --for i=tree.value+1,tree.count-1 do
end --function addleaf_fromclipboardbottom:action()

--5.1.5 add leaf of tree
addleaf = iup.item {title = "Blatt hinzuf�gen"}
function addleaf:action()
	tree.addleaf = ""
	tree.value=tree.value+1
	renamenode:action()
end --function addleaf:action()

--5.1.6 add leaf of tree from clipboard
addleaf_fromclipboard = iup.item {title = "Blatt aus Zwischenablage"}
function addleaf_fromclipboard:action()
	tree.addleaf = clipboard.text
	tree.value=tree.value+1
end --function addleaf_fromclipboard:action()

--5.1.7 copy a version of the file selected in the tree and give it the next version number
startversion = iup.item {title = "Version Archivieren"}
function startversion:action()
	--get the version of the file
	if tree['title']:match(".:\\.*%.[^\\]+") then
		Version=0
		p=io.popen('dir "' .. tree['title']:gsub("(%.+)","_Version*%1") .. '" /b/o')
		for Datei in p:lines() do 
			--test with: iup.Message("Version",Datei) 
			if Datei:match("_Version(%d+)") then Version_alt=Version Version=tonumber(Datei:match("_Version(%d+)")) if Version<Version_alt then Version=Version_alt end end
			--test with: iup.Message("Version",Version) 
		end --for Datei in p:lines() do 
		--test with: iup.Message(Version,Version+1)
		Version=Version+1
		iup.Message("Archivieren der Version:",tree['title']:gsub("(%.+)","_Version" .. Version .. "%1"))
		os.execute('copy "' .. tree['title'] .. '" "' .. tree['title']:gsub("(%.+)","_Version" .. Version .. "%1") .. '"')
	end --if tree['title']:match(".:\\.*%.[^\\]+") then
end --function startversion:action()

--5.1.8 menu for building new page
menu_new_page = iup.item {title = "Neue Seite"}
function menu_new_page:action()
local newText=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>]====] .. tree['title'] .. [====[</h1>

</body></html> ]====]
	if TextHTMLtable[tree['title']]==nil then
		webbrowser1.HTML=newText
		TextHTMLtable[tree['title']]= newText
	end --if TextHTMLtable[tree['title']]==nil then
	if tonumber(tree['title']) then 
		actualPage=math.tointeger(tonumber(tree['title'])) 
		webbrowser1.HTML=TextHTMLtable[actualPage]
		textbox1.value=tree['title']
		actualPage=tonumber(tree['title'])
	else
		webbrowser1.HTML=TextHTMLtable[tree['title']]
		textbox1.value=tree['title']
	end --if tonumber(tree['title']) then 
end --function menu_new_page:action()


--5.1.9 menu for going to webbrowser page
menu_goto_page=iup.item {title="Gehe zu Seite vom Knoten", size="65x20", BGCOLOR=color_buttons, FGCOLOR=color_button_text}
function menu_goto_page:action()
	if tonumber(tree['title']) then 
		actualPage=math.tointeger(tonumber(tree['title'])) 
		webbrowser1.HTML=TextHTMLtable[actualPage]
		textbox1.value=tree['title']
		actualPage=tonumber(tree['title'])
	else
		--test with: iup.Message("Text",tostring(TextHTMLtable[textbox1.value]))
		if TextHTMLtable[tree['title']] then
			webbrowser1.HTML=TextHTMLtable[tree['title']]
			textbox1.value=tree['title']
		else
			textbox1.value=tree['title'] .. " hat keine Webpage"
			webbrowser1.HTML=tree['title'] .. " hat keine Webpage"
		end --if TextHTMLtable[tree['title']] then
	end --if tonumber(tree['title']) then 
end --function menu_goto_page:flat_action()

--5.1.10 start the file or repository of the node of tree
startnode = iup.item {title = "Starten"}
function startnode:action() 
	if tree['title']:match("^.:\\.*%.[^\\ ]+$") or tree['title']:match("^.:\\.*[^\\]+$") or tree['title']:match("^.:\\$") or tree['title']:match("^[^ ]*//[^ ]+$") then os.execute('start "D" "' .. tree['title'] .. '"') end
end --function startnode:action()

--5.1.11 start the url in webbrowser
startnode_url = iup.item {title = "Starten URL"}
function startnode_url:action() 
	if tree['title']:match("http") then
		webbrowser1.value=tree['title']
	end --if tree['title']:match("http") then
end --function startnode_url:action()

--5.1.12 put the menu items together in the menu for tree
menu = iup.menu{
		startcopy,
		renamenode, 
		addbranch, 
		addbranchbottom, 
		addbranch_fromclipboard, 
		addbranch_fromclipboardbottom, 
		addleaf,
		addleafbottom,
		addleaf_fromclipboard,
		addleaf_fromclipboardbottom,
		startversion,
		menu_new_page, 
		menu_goto_page, 
		startnode_url, 
		startnode, 
		}
--5.1 menu of tree end


--5. context menus (menus for right mouse click) end

--6 buttons
--6.1 logo image definition and button with logo
img_logo = iup.image{
  { 4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4 }, 
  { 4,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,4,4,4 }, 
  { 4,1,1,1,1,1,1,1,1,1,3,3,1,1,3,3,3,1,1,1,1,1,3,1,1,1,3,1,1,1,1,4,4,4 }, 
  { 4,1,1,1,1,1,1,1,1,1,3,3,1,1,3,1,1,3,1,1,1,1,3,1,1,3,1,1,1,1,1,4,4,4 }, 
  { 4,1,1,1,1,3,3,3,3,1,1,1,1,1,3,1,1,3,1,1,1,1,3,1,3,1,1,1,1,1,1,4,4,4 }, 
  { 4,1,1,1,3,3,3,4,4,3,1,1,1,1,3,3,3,3,1,1,1,1,3,3,1,1,1,1,1,1,1,4,4,4 }, 
  { 4,1,1,3,3,3,3,4,4,3,3,1,1,1,3,1,1,1,3,1,1,1,3,1,3,1,1,1,1,1,1,4,4,4 }, 
  { 4,1,1,3,3,3,3,3,3,3,3,1,1,1,3,1,1,1,3,1,1,1,3,1,1,3,1,1,1,1,1,4,4,4 }, 
  { 4,1,1,3,3,3,3,3,3,3,3,1,1,1,3,3,3,3,1,1,3,1,3,1,1,1,3,1,3,1,1,4,4,4 }, 
  { 4,1,1,1,3,3,3,3,3,3,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,4,4,4 }, 
  { 4,1,1,1,1,3,3,3,3,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,4,4,4 }, 
  { 4,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,3,1,1,1,1,1,1,1,1,1,4,4,4 }, 
  { 4,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,3,1,3,1,3,1,1,1,1,1,1,1,4,4,4 }, 
  { 4,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,3,1,1,3,1,3,1,1,1,1,1,1,4,4,4 }, 
  { 4,1,1,1,1,1,1,1,1,1,1,1,1,1,4,1,1,1,1,1,3,1,3,3,1,1,1,1,1,1,1,4,4,4 }, 
  { 4,1,1,1,1,1,1,1,1,1,1,1,1,4,4,4,4,1,1,3,3,1,3,1,3,1,1,1,1,1,1,4,4,4 }, 
  { 4,1,1,1,1,1,1,1,1,1,1,4,4,4,4,4,4,4,1,1,3,3,1,3,1,1,1,1,1,1,1,4,4,4 }, 
  { 4,1,1,1,1,1,1,1,1,4,4,4,4,4,3,3,4,4,4,4,1,3,3,1,1,1,1,1,1,1,4,4,4,4 },
  { 4,1,1,1,1,1,1,1,4,4,4,4,3,3,3,3,3,3,4,4,4,3,1,1,1,1,1,1,1,1,1,4,4,4 },
  { 4,1,1,1,1,1,4,4,4,4,4,3,3,3,3,3,3,3,3,3,4,3,4,1,1,1,1,1,1,1,1,4,4,4 },
  { 4,1,1,1,1,4,4,4,4,4,3,3,3,3,3,3,3,3,3,3,3,3,4,4,4,1,1,1,1,1,1,4,4,4 },
  { 4,1,1,4,4,4,4,4,4,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,4,4,1,1,1,1,1,4,4,4 }, 
  { 4,4,4,4,4,4,4,4,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,4,4,1,1,1,4,4,4 }, 
  { 4,4,4,4,4,4,4,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,4,1,1,4,4,4 }, 
  { 4,4,4,4,4,4,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,1,4,4,4 }, 
  { 4,4,4,4,4,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,4,4,4 }, 
  { 4,4,4,4,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,4,4 },  
  { 4,4,4,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,4 },  
  { 4,4,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3 },  
  { 4,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,4,4 },  
  { 3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,4,4,4,4,4,4,4,4,4,4 },  
  { 3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4 },  
  { 3,3,3,3,3,3,3,3,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4 },  
  { 4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4 }  
  ; colors = { color_grey_bpc, color_light_color_grey_bpc, color_blue_bpc, "255 255 255" }
}
button_logo=iup.button{image=img_logo,title="", size="23x20"}
function button_logo:action()
	iup.Message("Beckmann & Partner CONSULT","BERATUNGSMANUFAKTUR\nMeisenstra�e 79\n33607 Bielefeld\nDr. Bruno Kaiser\nLizenz Open Source")
end --function button_logo:flat_action()

--6.2 button for saving TextHTMLtable and the programm of the graphical user interface
button_save_lua_table=iup.flatbutton{title="Datei speichern", size="75x20", BGCOLOR=color_buttons, FGCOLOR=color_button_text}
function button_save_lua_table:flat_action()
	save_html_to_lua(TextHTMLtable, path .. "\\" .. thisfilename)
end --function button_save_lua_table:flat_action()

--6.3.1 button for search in tree
button_search=iup.flatbutton{title="Suchen\n(Strg+F)", size="55x20", BGCOLOR=color_buttons, FGCOLOR=color_button_text}
function button_search:flat_action()
	searchtext.value=tree.title
	searchtext.SELECTION="ALL"
	dlg_search:popup(iup.ANYWHERE, iup.ANYWHERE)
end --function button_search:flat_action()

--6.3.2 button for going to first page
button_go_to_first_page = iup.flatbutton{title = "Startseite",size="55x20", BGCOLOR=color_buttons, FGCOLOR=color_button_text}
function button_go_to_first_page:flat_action()
	webbrowser1.HTML=TextHTMLtable[1]
	aktuelleSeite=1
	textbox1.value=aktuelleSeite
end --function button_go_to_first_page:action()

--6.4 button for going one page back
button_go_back = iup.flatbutton{title = "Eine Seite zur�ck",size="75x20", BGCOLOR=color_buttons, FGCOLOR=color_button_text}
function button_go_back:flat_action()
	if aktuelleSeite>1 then aktuelleSeite=aktuelleSeite-1 end
	webbrowser1.HTML=TextHTMLtable[aktuelleSeite]
	textbox1.value=aktuelleSeite
end --function button_go_back:action()

--6.5 button for going to the page and edit the page
button_edit_page = iup.flatbutton{title = "Editieren der Seite:",size="75x20", BGCOLOR=color_buttons, FGCOLOR=color_button_text}
function button_edit_page:flat_action()
	if tonumber(textbox1.value) then
		aktuelleSeite=math.tointeger(tonumber(textbox1.value))
		TextErsatz=TextHTMLtable[aktuelleSeite]
		webbrowser1.HTML=TextErsatz
	else
		TextErsatz=TextHTMLtable[textbox1.value]
		webbrowser1.HTML=TextErsatz
	end --if tonumber(textbox1.value) then
	text1.value=TextErsatz
	dlg_change_page:popup(iup.CENTER, iup.CENTER) --popup rename dialog
end --function button_edit_page:action()

--6.6 button for going to the page
button_go_to_page = iup.flatbutton{title = "Gehe zu Seite:",size="75x20", BGCOLOR=color_buttons, FGCOLOR=color_button_text}
function button_go_to_page:flat_action()
	if tonumber(textbox1.value) then
		aktuelleSeite=math.tointeger(tonumber(textbox1.value))
		TextErsatz=TextHTMLtable[aktuelleSeite]
		webbrowser1.HTML=TextErsatz
	else
		TextErsatz=TextHTMLtable[aktuelleSeite]
		webbrowser1.HTML=TextErsatz
	end --if tonumber(textbox1.value) then
end --function button_go_to_page:action()

--6.7 button for deleting the page
button_delete = iup.flatbutton{title = "L�schen der Seite",size="75x20", BGCOLOR=color_buttons, FGCOLOR=color_button_text}
function button_delete:flat_action()
	LoeschAlarm=iup.Alarm("Soll die Seite " .. tonumber(textbox1.value) .. " wirklich gel�scht werden?","Soll die Seite " .. tonumber(textbox1.value) .. " wirklich gel�scht werden?","L�schen","Nicht L�schen")
	if LoeschAlarm==1 then 
		if tonumber(textbox1.value) and tonumber(textbox1.value)<=#TextHTMLtable then
			aktuelleSeite=math.tointeger(tonumber(textbox1.value))
			table.move(TextHTMLtable,aktuelleSeite+1,#TextHTMLtable,aktuelleSeite)--move following elements to begin with index from aktuelleSeite
			TextHTMLtable[#TextHTMLtable]=nil --delete last element
			--test with: iup.Message(aktuelleSeite, tostring(math.floor(aktuelleSeite/2)*2==aktuelleSeite))
			webbrowser1.HTML="Seite gel�scht"
		else
			iup.Message("Keine Seite zum L�schen","Keine Seite zum L�schen")
		end --if tonumber(textbox1.value) and tonumber(textbox1.value)<=#TextHTMLtable then
	end --if LoeschAlarm==1 then 
end --function button_delete:flat_action()

--6.8 button for saving TextHTMLtable as html file
button_save_as_html=iup.flatbutton{title="Als html speichern", size="75x20", BGCOLOR=color_buttons, FGCOLOR=color_button_text}
function button_save_as_html:flat_action()
	local outputfile1=io.open(path .. "\\" .. thisfilename:gsub("%.lua$",".html"),"w")
	for i,v in ipairs(TextHTMLtable) do
		outputfile1:write(v .. "\n")
	end --for i,v in ipairs(TextHTMLtable) do
	for i=0,tree.count-1 do
		if TextHTMLtable[tree["title" .. i]] then
			outputfile1:write(TextHTMLtable[tree["title" .. i]] .. "\n")
		end --if tree["title" .. i]  then
	end --for i=tree.value+1,tree.count-1 do
	outputfile1:close()
end --function button_save_as_html:flat_action()

--6.9 button for search in TextHTMLtable
button_search_in_pages=iup.flatbutton{title="Suche in Seiten", size="75x20", BGCOLOR=color_buttons, FGCOLOR=color_button_text}
function button_search_in_pages:flat_action()
	if tonumber(textbox1.value) then
		aktuelleSeite=math.tointeger(tonumber(textbox1.value))
		if aktuelleSeite<=#TextHTMLtable then
			for i=aktuelleSeite+1,#TextHTMLtable do
				if TextHTMLtable[i]:gsub("<[^>]+>",""):lower():match(textbox2.value:lower()) then
					textbox1.value=i
					aktuelleSeite=math.tointeger(tonumber(textbox1.value))
					webbrowser1.HTML=TextHTMLtable[aktuelleSeite]
					break 
				end --if TextHTMLtable[i]:gsub("<[^>]+>",""):lower():match(textbox2.value:lower()) then
			end --for i=aktuelleSeite,#TextHTMLtable do
		end --if aktuelleSeite<=#TextHTMLtable then
	else
		for k,v in pairs(TextHTMLtable) do
			if TextHTMLtable[k]:gsub("<[^>]+>",""):lower():match(textbox2.value:lower()) then
				textbox1.value=k
				aktuelleSeite=textbox1.value
				webbrowser1.HTML=TextHTMLtable[aktuelleSeite]
				break 
			end --if TextHTMLtable[i]:gsub("<[^>]+>",""):lower():match(textbox2.value:lower()) then
		end --for k,v in pairs(TextHTMLtable) do
	end --if tonumber(textbox1.value) then
end --function button_search_in_pages:flat_action()


--6.10 button for going to the next page
button_go_forward = iup.flatbutton{title = "Eine Seite vor",size="75x20", BGCOLOR=color_buttons, FGCOLOR=color_button_text}
function button_go_forward:flat_action()
	if aktuelleSeite<#TextHTMLtable then aktuelleSeite=aktuelleSeite+1 end
	webbrowser1.HTML=TextHTMLtable[aktuelleSeite]
	textbox1.value=aktuelleSeite
end --function button_go_forward:action()

--6.11 button for building new page
button_new_page = iup.flatbutton{title = "Neue Seite",size="45x20", BGCOLOR=color_buttons, FGCOLOR=color_button_text}
function button_new_page:flat_action()
	aktuelleSeite=#TextHTMLtable+1
	textbox1.value=aktuelleSeite
local newText=[====[<!DOCTYPE html> <head></head><html> <body>
<h1>Neue Seite </h1>

</body></html> ]====]
	webbrowser1.HTML=newText
	TextHTMLtable[aktuelleSeite]= newText
end --function button_new_page:action()

--6.12 button with second logo
button_logo2=iup.button{image=img_logo,title="", size="23x20"}
function button_logo2:action()
	iup.Message("Beckmann & Partner CONSULT","BERATUNGSMANUFAKTUR\nMeisenstra�e 79\n33607 Bielefeld\nDr. Bruno Kaiser\nLizenz Open Source")
end --function button_logo:flat_action()

--7 Main Dialog

--7.1 textboxes
textbox1 = iup.text{value="1",size="20x20",WORDWRAP="NO",alignment="ACENTER"}
textbox2 = iup.multiline{value="",size="90x20",WORDWRAP="YES"}

--7.2 webbrowser
webbrowser1=iup.webbrowser{HTML=TextHTMLtable[1],MAXSIZE="900x750"}

--7.3 load tree from self file
actualtree=lua_tree_output
--build tree
tree=iup.tree{
map_cb=function(self)
self:AddNodes(actualtree)
end, --function(self)
SIZE="10x200",
showrename="YES",--F2 key active
markmode="SINGLE",--for Drag & Drop SINGLE not MULTIPLE
showdragdrop="YES",
}
--set colors of tree
tree.BGCOLOR=color_background_tree --set the background color of the tree
-- Callback of the right mouse button click
function tree:rightclick_cb(id)
	tree.value = id
	menu:popup(iup.MOUSEPOS,iup.MOUSEPOS) --popup the defined menue
end --function tree:rightclick_cb(id)
-- Callback called when a node will be doubleclicked
function tree:executeleaf_cb(id)
	if tree['title' .. id]:match("^.:\\.*%.[^\\ ]+$") or tree['title' .. id]:match("^.:\\.*[^\\]+$") or tree['title' .. id]:match("^.:\\$") or tree['title' .. id]:match("^[^ ]*//[^ ]+$") then os.execute('start "d" "' .. tree['title' .. id] .. '"') end
end --function tree:executeleaf_cb(id)
-- Callback for pressed keys
function tree:k_any(c)
	if c == iup.K_DEL then
		-- do a totalchildcount of marked node. Then pop the table entries, which correspond to them.
		for j=0,tree.totalchildcount do
			--table.remove(attributes, tree.value+1)
		end --for j=0,tree.totalchildcount do
		tree.delnode = "MARKED"
	elseif c == iup.K_cP then -- added output of current table to a text file
		printtree()
	elseif c == iup.K_cF then
			searchtext.value=tree.title
			searchtext.SELECTION="ALL"
			dlg_search:popup(iup.ANYWHERE, iup.ANYWHERE)
	elseif c == iup.K_Menu then
		menu:popup(iup.MOUSEPOS,iup.MOUSEPOS) --popup the defined menue
	end --if c == iup.K_DEL then
end --function tree:k_any(c)

--7.3.1 statistics about the tree
numberOfBranches=0
numberOfLeafs=0
BranchsTable={}
LeafsTable={}
function readTreeRecursiveStatistics(TreeTable)
if TreeTable.branchname then numberOfBranches=numberOfBranches+1 BranchsTable[TreeTable.branchname]=true end
for i,v in ipairs(TreeTable) do
if type(v)=="table" then 
	readTreeRecursiveStatistics(v)
else 
	numberOfLeafs=numberOfLeafs+1 LeafsTable[v]=true
end --if type(v)=="table" then 
end --for i,v in ipairs(TreeTable) do
end --function readTreeRecursiveStatistics()
readTreeRecursiveStatistics(actualtree)
print("Anzahl Branches: " .. numberOfBranches)
print("Anzahl Leafs: " .. numberOfLeafs)

--7.3.2 statistics about the pages
numberOfPages=0
numberOfLeafPages=0
numberOfBranchPages=0
numberOfLostPages=0
numberOfHiddenPages=0
for k,v in pairs(TextHTMLtable) do
numberOfPages=numberOfPages+1 
if tonumber(k) then k=tostring(k) end
if LeafsTable[k] then numberOfLeafPages=numberOfLeafPages+1 end
if BranchsTable[k] then numberOfBranchPages=numberOfBranchPages+1 end
if LeafsTable[k]==nil and BranchsTable[k]==nil and tonumber(k) then 
numberOfHiddenPages=numberOfHiddenPages+1 print("Seite versteckt: " .. k)
elseif LeafsTable[k]==nil and BranchsTable[k]==nil and tonumber(k)==nil then 
numberOfLostPages=numberOfLostPages+1 print("Seite verloren: " .. k)
end --if LeafsTable[k]==nil and BranchsTable[k]==nil then
end --for k,v in pairs(TextHTMLtable) do 
print("Anzahl Seiten: " .. numberOfPages)
print("Anzahl Seiten von Branches: " .. numberOfBranchPages)
print("Anzahl Seiten von Leafs: " .. numberOfLeafPages)
print("Anzahl Seiten versteckter Seiten: " .. numberOfHiddenPages)
print("Anzahl Seiten verlorener Seiten: " .. numberOfLostPages)

--7.4 building the dialog and put buttons, trees and preview together
maindlg = iup.dialog {
	iup.vbox{
		iup.hbox{
			button_logo,
			button_save_lua_table,
			button_search,
			button_go_to_first_page,
			button_go_back,
			button_edit_page,
			button_go_to_page,
			textbox1,
			button_delete,
			iup.fill{},
			button_save_as_html,
			button_search_in_pages,
			textbox2,
			button_go_forward,
			button_new_page,
			button_logo2,
		}, --iup.hbox{
		iup.hbox{iup.frame{title="Manuelle Zuordnung als Baum",tree,},webbrowser1,},
	}, --iup.vbox{
	icon = img_logo,
	title = path .. " Documentation Tree",
	size="FULLxFULL" ;
	gap="3",
	alignment="ARIGHT",
	margin="5x5" 
}--maindlg = iup.dialog {

--7.5 show the dialog
maindlg:showxy(iup.CENTER,iup.CENTER) 

--7.6 Main Loop
if (iup.MainLoopLevel()==0) then iup.MainLoop() end

--]====]
